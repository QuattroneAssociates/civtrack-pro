
import React, { useState } from 'react';
import { supabase } from '../src/lib/supabase';
import { LogIn, UserPlus, AlertCircle, Loader2, Building2, KeyRound } from 'lucide-react';
import { motion } from 'motion/react';

export const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [token, setToken] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [role, setRole] = useState('Engineer');
  const [step, setStep] = useState<'email' | 'otp'>('email');
  const [message, setMessage] = useState<string | null>(null);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setMessage(null);

    try {
      if (isSignUp) {
        // For sign up, we first need to create the user, then send the OTP
        // Note: With OTP, sign up and sign in are often the same flow, but we want to capture metadata
        const { error } = await supabase.auth.signInWithOtp({
          email,
          options: {
            data: {
              full_name: name,
              role: role,
            },
          },
        });
        if (error) throw error;
      } else {
        const { error } = await supabase.auth.signInWithOtp({
          email,
        });
        if (error) throw error;
      }
      
      setStep('otp');
      setMessage('A 6-digit PIN has been sent to your email.');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const { error } = await supabase.auth.verifyOtp({
        email,
        token,
        type: 'email',
      });
      if (error) throw error;
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-600/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-600/10 blur-[120px] rounded-full" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-zinc-900/50 backdrop-blur-xl border border-white/10 p-8 rounded-3xl shadow-2xl relative z-10"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-4 shadow-lg shadow-blue-600/20">
            <Building2 className="text-white" size={32} />
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">CivTrack Pro</h1>
          <p className="text-zinc-400 text-sm mt-1">Engineering Project Management</p>
        </div>

        <form onSubmit={step === 'email' ? handleSendOtp : handleVerifyOtp} className="space-y-4">
          {step === 'email' ? (
            <>
              {isSignUp && (
                <>
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-1.5 ml-1">Full Name</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-white placeholder:text-zinc-600 focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-1.5 ml-1">Role</label>
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value)}
                      className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all appearance-none"
                    >
                      <option>Application Owner</option>
                      <option>Administrator Full Access</option>
                      <option>Administrator</option>
                      <option>Project Manager</option>
                      <option>CAD</option>
                      <option>EI</option>
                      <option>Engineer</option>
                      <option>Associate Engineer</option>
                      <option>Planner</option>
                      <option>Designer</option>
                      <option>Office Manager</option>
                    </select>
                  </div>
                </>
              )}

              <div>
                <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-1.5 ml-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-white placeholder:text-zinc-600 focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all"
                  placeholder="name@quattrone.com"
                />
              </div>
            </>
          ) : (
            <div>
              <label className="block text-[10px] font-black uppercase tracking-widest text-zinc-500 mb-1.5 ml-1">Enter 6-Digit PIN</label>
              <input
                type="text"
                required
                value={token}
                onChange={(e) => setToken(e.target.value)}
                className="w-full bg-black/40 border border-white/5 rounded-xl px-4 py-3 text-white placeholder:text-zinc-600 focus:outline-none focus:ring-2 focus:ring-blue-600/50 transition-all text-center tracking-[0.5em] font-mono text-lg"
                placeholder="••••••"
                maxLength={6}
              />
              <button
                type="button"
                onClick={() => setStep('email')}
                className="text-xs text-blue-500 hover:text-blue-400 mt-2 ml-1"
              >
                Use a different email
              </button>
            </div>
          )}

          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-center gap-3 text-rose-500 text-xs">
              <AlertCircle size={16} />
              <p>{error}</p>
            </div>
          )}

          {message && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center gap-3 text-emerald-500 text-xs">
              <AlertCircle size={16} />
              <p>{message}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 disabled:opacity-50 disabled:cursor-not-allowed mt-2"
          >
            {loading ? (
              <Loader2 className="animate-spin" size={20} />
            ) : step === 'otp' ? (
              <>
                <KeyRound size={20} />
                Verify PIN
              </>
            ) : isSignUp ? (
              <>
                <UserPlus size={20} />
                Send PIN to Create Account
              </>
            ) : (
              <>
                <LogIn size={20} />
                Send PIN to Sign In
              </>
            )}
          </button>
        </form>

        {step === 'email' && (
          <div className="mt-6 text-center">
            <button
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-zinc-400 hover:text-white text-xs font-medium transition-colors"
            >
              {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
};
