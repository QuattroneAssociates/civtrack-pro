
import React, { useMemo, useState } from 'react';
import { Project, Permit, ProjectStatus, User } from '../types';

import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { 
  BarChart3, PieChart as PieChartIcon, Table as TableIcon, 
  TrendingUp, Users, Wallet, Landmark, ChevronRight, ArrowLeft 
} from 'lucide-react';

interface ReportsProps {
  projects: Project[];
  permits: Permit[];
  users: User[];
}

type ReportType = 'overview' | 'workload' | 'pipeline' | 'financial' | 'agencies';

const COLORS = ['#000066', '#A68F5B', '#4f46e5', '#10b981', '#f59e0b', '#e11d48', '#8b5cf6'];

const Reports: React.FC<ReportsProps> = ({ projects, permits, users }) => {
  const [activeReport, setActiveReport] = useState<ReportType>('overview');

  // 1. Workload Data (Projects per Manager - Active, Construction, On Hold)
  const workloadData = useMemo(() => {
    const data = users.map(user => {
      const userProjects = projects.filter(p => 
        p.project_manager_id === user.id || 
        p.project_manager_id === user.name ||
        p.project_manager_name === user.name
      );
      const active = userProjects.filter(p => p.status === ProjectStatus.ACTIVE || p.status === ProjectStatus.ACTIVE_PRIORITY).length;
      const construction = userProjects.filter(p => p.status === ProjectStatus.CONSTRUCTION).length;
      const onHold = userProjects.filter(p => p.status === ProjectStatus.ON_HOLD).length;
      
      return {
        name: (user.name || '').split(' ')[0], // Short name for chart
        fullName: user.name,
        active,
        construction,
        onHold,
        totalRelevant: active + construction + onHold
      };
    })
    .filter(d => d.totalRelevant > 0)
    .sort((a, b) => b.totalRelevant - a.totalRelevant);
    
    return data;
  }, [projects]);

  // 2. Pipeline Data (Status Distribution)
  const pipelineData = useMemo(() => {
    return Object.values(ProjectStatus).map(status => ({
      name: status,
      value: projects.filter(p => p.status === status).length
    })).filter(d => d.value > 0);
  }, [projects]);

  // 3. Agency Data (Top Agencies - ACTIVE PROJECTS ONLY)
  const agencyData = useMemo(() => {
    const counts: Record<string, number> = {};
    projects
      .filter(p => 
        (p.status === ProjectStatus.ACTIVE || p.status === ProjectStatus.ACTIVE_PRIORITY) && 
        p.agency && p.agency.trim() !== ''
      )
      .forEach(p => {
        counts[p.agency] = (counts[p.agency] || 0) + 1;
      });
      
    return Object.entries(counts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 7);
  }, [projects]);

  // 4. Financial - Unpaid Fees Report
  const unpaidFees = useMemo(() => {
    return permits
      .filter(p => p.application_status === 'Fees Posted - Unpaid')
      .map(p => ({
        permit: p,
        project: projects.find(proj => proj.id === p.project_id || proj.number === p.project_id)
      }))
      .filter(item => item.project);
  }, [permits, projects]);

  return (
    <div className="max-w-[1400px] mx-auto space-y-8 animate-in fade-in duration-700 pb-20">
      <div className="flex items-center justify-between px-2">
        <div className="flex items-center gap-4">
          {activeReport !== 'overview' && (
            <button 
              onClick={() => setActiveReport('overview')}
              className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-[#000066] transition-all"
            >
              <ArrowLeft size={20} />
            </button>
          )}
          <div className="space-y-1">
            <h1 className="text-3xl font-black text-slate-800 tracking-tight uppercase">Reporting Center</h1>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Operational Intelligence & Insights</p>
          </div>
        </div>
        <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl border border-indigo-100">
           <BarChart3 size={24} />
        </div>
      </div>

      {activeReport === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <ReportCard 
            title="Workload Distribution" 
            subtitle="Active, Construction & On Hold" 
            icon={<Users size={24} />} 
            color="blue"
            onClick={() => setActiveReport('workload')}
          />
          <ReportCard 
            title="Project Pipeline" 
            subtitle="Portfolio Status Breakdown" 
            icon={<TrendingUp size={24} />} 
            color="amber"
            onClick={() => setActiveReport('pipeline')}
          />
          <ReportCard 
            title="Agency Activity" 
            subtitle="Distribution of work by region" 
            icon={<Landmark size={24} />} 
            color="indigo"
            onClick={() => setActiveReport('agencies')}
          />
          <ReportCard 
            title="Fee Tracking (AR)" 
            subtitle="Permits with unpaid fees" 
            icon={<Wallet size={24} />} 
            color="rose"
            onClick={() => setActiveReport('financial')}
          />
        </div>
      )}

      {activeReport === 'workload' && (
        <ReportContainer title="Personnel Workload Report" onBack={() => setActiveReport('overview')}>
          <div className="h-[500px] w-full mt-8">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={workloadData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 800, fill: '#64748b' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 800, fill: '#64748b' }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1)', fontSize: '11px', fontWeight: 'bold' }}
                  cursor={{ fill: '#f8fafc' }}
                />
                <Legend iconType="circle" wrapperStyle={{ paddingTop: '20px', fontSize: '10px', fontWeight: 'black', textTransform: 'uppercase' }} />
                <Bar dataKey="active" name="Active" fill="#000066" radius={[4, 4, 0, 0]} />
                <Bar dataKey="construction" name="Construction" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="onHold" name="On Hold" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ReportContainer>
      )}

      {activeReport === 'pipeline' && (
        <ReportContainer title="Portfolio Pipeline Status" onBack={() => setActiveReport('overview')}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pipelineData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={140}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pipelineData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1)', fontSize: '11px', fontWeight: 'bold' }}
                  />
                  <Legend iconType="circle" layout="vertical" align="right" verticalAlign="middle" wrapperStyle={{ fontSize: '10px', fontWeight: 'black', textTransform: 'uppercase' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-4">
              <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 border-b border-slate-100 pb-2">Status Counts</h4>
              {pipelineData.map((d, i) => (
                <div key={d.name} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                    <span className="text-sm font-bold text-slate-700">{d.name}</span>
                  </div>
                  <span className="text-sm font-black text-[#000066]">{d.value}</span>
                </div>
              ))}
            </div>
          </div>
        </ReportContainer>
      )}

      {activeReport === 'agencies' && (
        <ReportContainer title="Regional Agency Activity" onBack={() => setActiveReport('overview')}>
          <div className="h-[500px] w-full mt-8">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={agencyData} layout="vertical" margin={{ top: 20, right: 30, left: 100, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 800, fill: '#64748b' }} />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 800, fill: '#64748b' }} width={140} />
                <Tooltip 
                  contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1)', fontSize: '11px', fontWeight: 'bold' }}
                />
                <Bar dataKey="value" name="Active Projects" fill="#A68F5B" radius={[0, 6, 6, 0]} barSize={24} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ReportContainer>
      )}

      {activeReport === 'financial' && (
        <ReportContainer title="Pending Fee Payments (AR)" onBack={() => setActiveReport('overview')}>
          <div className="bg-white rounded-[2rem] border border-slate-200 overflow-hidden shadow-sm">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-[10px] font-black uppercase tracking-widest text-slate-400">
                <tr>
                  <th className="px-8 py-5">Project Name</th>
                  <th className="px-8 py-5">Permit Type</th>
                  <th className="px-8 py-5">Agency</th>
                  <th className="px-8 py-5 text-right">Reference #</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {unpaidFees.length > 0 ? unpaidFees.map((item, i) => (
                  <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-8 py-5">
                      <p className="text-sm font-black text-[#000066] uppercase">{item.project?.name}</p>
                    </td>
                    <td className="px-8 py-5 text-sm font-bold text-slate-600">{item.permit.type}</td>
                    <td className="px-8 py-5 text-xs font-black text-slate-400 uppercase">{item.project?.agency}</td>
                    <td className="px-8 py-5 text-right">
                      <span className="bg-slate-100 px-2 py-0.5 rounded text-[10px] font-mono font-bold text-slate-500">{item.permit.number || 'TBD'}</span>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={4} className="px-8 py-20 text-center text-slate-300 italic font-bold">No unpaid fees recorded.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </ReportContainer>
      )}
    </div>
  );
};

const ReportCard: React.FC<{ 
  title: string, 
  subtitle: string, 
  icon: React.ReactNode, 
  color: 'blue' | 'amber' | 'rose' | 'indigo',
  onClick: () => void 
}> = ({ title, subtitle, icon, color, onClick }) => {
  const colors = {
    blue: 'bg-blue-50 text-blue-600 border-blue-100 hover:border-blue-300',
    amber: 'bg-amber-50 text-amber-600 border-amber-100 hover:border-amber-300',
    rose: 'bg-rose-50 text-rose-600 border-rose-100 hover:border-rose-300',
    indigo: 'bg-indigo-50 text-indigo-600 border-indigo-100 hover:border-indigo-300'
  };

  return (
    <button 
      onClick={onClick}
      className={`p-8 rounded-[2.5rem] border transition-all text-left group flex flex-col justify-between h-64 bg-white shadow-sm hover:shadow-xl ${colors[color]}`}
    >
      <div className="p-4 bg-white rounded-2xl shadow-sm w-fit border border-inherit">{icon}</div>
      <div className="space-y-2">
        <h3 className="text-xl font-black text-slate-800 leading-tight uppercase tracking-tight">{title}</h3>
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1 group-hover:text-slate-600">
          {subtitle} <ChevronRight size={10} />
        </p>
      </div>
    </button>
  );
};

const ReportContainer: React.FC<{ title: string, onBack: () => void, children: React.ReactNode }> = ({ title, onBack, children }) => (
  <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-xl animate-in zoom-in-95 duration-300">
    <div className="flex items-center justify-between mb-10 border-b border-slate-50 pb-6">
      <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">{title}</h2>
      <button 
        onClick={onBack}
        className="px-6 py-2 bg-slate-50 text-slate-400 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-100 hover:text-slate-600 transition-all border border-slate-100"
      >
        Back to Gallery
      </button>
    </div>
    {children}
  </div>
);

export default Reports;
