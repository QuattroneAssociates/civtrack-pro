
import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { Task, Project, User } from '../types';
import { CheckSquare, Calendar, User as UserIcon, SearchX, Filter, Briefcase, PlusCircle, CheckCircle2, Archive, ListTodo, LayoutGrid, MessageSquare, Tag } from 'lucide-react';
import SearchableSelect from '../SearchableSelect';
import { TaskModal } from '../src/components/TaskModal';

interface TasksListProps {
  tasks: Task[];
  projects: Project[];
  users: User[];
  onUpdateTasks?: (tasks: Task[]) => void;
  searchQuery?: string;
  currentUser: User;
}

type ViewMode = 'active' | 'archived' | 'board';

const TasksList: React.FC<TasksListProps> = ({ tasks, projects, users, onUpdateTasks, searchQuery = '', currentUser }) => {
  const canSeeAll = ['Application Owner', 'Project Manager'].includes(currentUser.role);
  const [assigneeFilter, setAssigneeFilter] = useState<string>(canSeeAll ? 'All' : currentUser.name);
  const [viewMode, setViewMode] = useState<ViewMode>('board');
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const handleToggleTask = (id: string) => {
    if (!onUpdateTasks) return;
    onUpdateTasks(tasks.map(t => 
      t.id === id ? { ...t, status: t.status === 'Completed' ? 'Pending' : 'Completed' } : t
    ));
  };

  const handleUpdateSingleTask = (updatedTask: Task) => {
    if (!onUpdateTasks) return;
    onUpdateTasks(tasks.map(t => t.id === updatedTask.id ? updatedTask : t));
    setSelectedTask(updatedTask);
  };

  // Calculate counts based on the current assignee filter
  const { activeCount, archivedCount } = useMemo(() => {
    let baseTasks = [...tasks];
    if (assigneeFilter && assigneeFilter !== 'All') {
      const searchName = assigneeFilter.toLowerCase();
      baseTasks = baseTasks.filter(t => {
        const assigned = (t.assigned_to || '').toLowerCase();
        return assigned === searchName || assigned.includes(searchName) || searchName.includes(assigned);
      });
    }
    return {
      activeCount: baseTasks.filter(t => t.status !== 'Completed').length,
      archivedCount: baseTasks.filter(t => t.status === 'Completed').length
    };
  }, [tasks, assigneeFilter]);

  const filteredTasks = useMemo(() => {
    let filtered = [...tasks];

    // Status Filter (Active vs Archived vs Board)
    if (viewMode === 'active' || viewMode === 'board') {
      filtered = filtered.filter(t => t.status !== 'Completed');
    } else {
      filtered = filtered.filter(t => t.status === 'Completed');
    }

    // Global Search Filter
    if (searchQuery && searchQuery.trim()) {
      const words = searchQuery.toLowerCase().trim().split(/\s+/).filter(Boolean);
      filtered = filtered.filter(t => {
        const pid = (t.project_id || '').toString().trim();
        const project = projects.find(p => p.id === pid || p.number.trim() === pid);
        const searchableText = [
          t.name,
          t.project_name || '',
          t.assigned_to,
          project?.number || '',
          project?.address || '',
          project?.client_name || '',
          project?.strap_number || ''
        ].join(' ').toLowerCase();
        
        return words.every(word => searchableText.includes(word));
      });
    }

    // Assignee Filter
    if (assigneeFilter && assigneeFilter !== 'All') {
      const searchName = assigneeFilter.toLowerCase();
      filtered = filtered.filter(t => {
        const assigned = (t.assigned_to || '').toLowerCase();
        return assigned === searchName || assigned.includes(searchName) || searchName.includes(assigned);
      });
    }

    return filtered;
  }, [tasks, searchQuery, assigneeFilter, viewMode]);

  const assigneeOptions = useMemo(() => [
    { id: 'All', label: 'All Personnel' },
    ...users.map(u => ({ id: u.name, label: u.name }))
  ], [users]);

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '-';
    if (dateStr.includes('/')) return dateStr;
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[1]}/${parts[2]}/${parts[0]}`;
    return dateStr;
  };

  const renderTaskCard = (task: Task) => {
    const pid = (task.project_id || '').toString().trim();
    const matchedProject = projects.find(p => p.id === pid || p.number.trim() === pid);
    const displayProjectName = matchedProject?.name || task.project_name || 'View Project';
    const isUnassigned = pid === '00000000-0000-0000-0000-000000000000';

    return (
      <div 
        key={task.id} 
        onClick={() => setSelectedTask(task)}
        draggable
        onDragStart={(e) => {
          e.dataTransfer.setData('taskId', task.id);
        }}
        className={`bg-white p-4 rounded-3xl border transition-all hover:shadow-md cursor-pointer flex flex-col gap-4 ${task.is_important ? 'border-amber-200 shadow-amber-50 shadow-sm' : 'border-slate-200'}`}
      >
        <div className="flex items-start justify-between gap-2">
          <h4 className={`text-sm font-black leading-tight ${task.status === 'Completed' ? 'text-slate-400 line-through font-bold' : 'text-slate-800'}`}>
            {task.name}
          </h4>
          <button 
            onClick={(e) => { e.stopPropagation(); handleToggleTask(task.id); }}
            className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 border-2 transition-all ${
              task.status === 'Completed' 
                ? 'bg-emerald-50 border-emerald-500 text-emerald-600' 
                : 'bg-slate-50 border-transparent text-slate-400 hover:border-blue-300 hover:text-blue-500'
            }`}
          >
            {task.status === 'Completed' ? <CheckCircle2 size={14} /> : <CheckSquare size={14} />}
          </button>
        </div>

        <div className="flex flex-wrap gap-1">
          {task.is_important && (
            <span className="px-1.5 py-0.5 bg-amber-50 text-amber-700 text-[8px] font-black uppercase tracking-widest rounded border border-amber-100">Critical</span>
          )}
          {(task.tags || []).slice(0, 2).map(tag => (
            <span key={tag} className="px-1.5 py-0.5 bg-blue-50 text-blue-700 text-[8px] font-black uppercase tracking-widest rounded border border-blue-100">#{tag}</span>
          ))}
          {(task.tags || []).length > 2 && (
            <span className="px-1.5 py-0.5 bg-slate-50 text-slate-500 text-[8px] font-black uppercase tracking-widest rounded border border-slate-200">+{task.tags!.length - 2}</span>
          )}
        </div>

        <div className="flex flex-col gap-2 mt-auto pt-2 border-t border-slate-50">
          <span className="flex items-center gap-1.5 text-[9px] font-black text-slate-500 uppercase truncate">
            <Briefcase size={10} /> {displayProjectName}
          </span>
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-[9px] font-bold text-slate-400 uppercase">
              <UserIcon size={10} className="text-slate-300" /> {task.assigned_to || 'Unassigned'}
            </span>
            <div className="flex items-center gap-2 text-[9px] font-bold text-slate-400 uppercase">
              {(task.comments?.length || 0) > 0 && (
                <span className="flex items-center gap-1"><MessageSquare size={10} /> {task.comments!.length}</span>
              )}
              <span className="flex items-center gap-1"><Calendar size={10} /> {formatDate(task.due_date)}</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderBoardColumn = (title: string, status: string, columnTasks: Task[]) => (
    <div 
      className="flex flex-col bg-slate-50/50 rounded-[2.5rem] border border-slate-100 p-4 flex-1 min-w-[250px]"
      onDragOver={(e) => {
        e.preventDefault();
      }}
      onDrop={(e) => {
        e.preventDefault();
        const taskId = e.dataTransfer.getData('taskId');
        if (taskId) {
          const updatedTasks = tasks.map(t => 
            t.id === taskId ? { ...t, status } : t
          );
          onUpdateTasks(updatedTasks);
        }
      }}
    >
      <div className="flex items-center justify-between mb-4 px-2">
        <h3 className="text-xs font-black uppercase tracking-widest text-slate-800">{title}</h3>
        <span className="px-2 py-0.5 bg-white border border-slate-200 rounded-lg text-[10px] font-black text-slate-500 shadow-sm">{columnTasks.length}</span>
      </div>
      <div className="flex flex-col gap-3 flex-1 overflow-y-auto no-scrollbar pb-4">
        {columnTasks.map(renderTaskCard)}
        {columnTasks.length === 0 && (
          <div className="flex-1 flex items-center justify-center border-2 border-dashed border-slate-200 rounded-3xl p-6 text-center">
            <p className="text-[10px] font-bold text-slate-400 uppercase">No tasks</p>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-6 animate-in slide-in-from-right-4 duration-500 h-full flex flex-col">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm shrink-0">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
            {viewMode === 'board' ? <LayoutGrid size={24} /> : viewMode === 'active' ? <ListTodo size={24} /> : <Archive size={24} className="text-slate-400" />}
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">
              {viewMode === 'board' ? 'Task Board' : viewMode === 'active' ? 'Master Task List' : 'Task Archive'}
            </h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
              {viewMode === 'board' ? 'Visual workflow tracking' : viewMode === 'active' ? 'Cross-project tracking' : 'Historical completed records'}
            </p>
          </div>
        </div>

        {/* Filters & Tabs */}
        <div className="flex flex-col sm:flex-row items-center gap-6 w-full lg:w-auto">
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button 
              onClick={() => setViewMode('board')}
              className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${viewMode === 'board' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Board <span className="px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded-md">{activeCount}</span>
            </button>
            <button 
              onClick={() => setViewMode('active')}
              className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${viewMode === 'active' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              List <span className="px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded-md">{activeCount}</span>
            </button>
            <button 
              onClick={() => setViewMode('archived')}
              className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-2 ${viewMode === 'archived' ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Archive <span className="px-1.5 py-0.5 bg-slate-200 text-slate-600 rounded-md">{archivedCount}</span>
            </button>
          </div>
          {canSeeAll && (
            <div className="w-full sm:w-64">
              <SearchableSelect
                options={assigneeOptions}
                value={assigneeFilter}
                onChange={setAssigneeFilter}
                placeholder="Filter by Personnel"
              />
            </div>
          )}
        </div>
      </div>

      {viewMode === 'board' ? (
        <div className="flex-1 overflow-x-auto pb-4 no-scrollbar">
          <div className="flex gap-6 h-full min-h-[500px]">
            {renderBoardColumn('To Do', 'Pending', filteredTasks.filter(t => t.status === 'Pending' || !t.status))}
            {renderBoardColumn('In Progress', 'In Progress', filteredTasks.filter(t => t.status === 'In Progress'))}
            {renderBoardColumn('Under Review', 'Under Review', filteredTasks.filter(t => t.status === 'Under Review'))}
            {renderBoardColumn('Completed', 'Completed', tasks.filter(t => t.status === 'Completed' && (assigneeFilter === 'All' || t.assigned_to === assigneeFilter)))}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
        {filteredTasks.length > 0 ? filteredTasks.sort((a, b) => Number(b.is_important) - Number(a.is_important)).map(task => (
          <div key={task.id} className={`bg-white p-6 rounded-[2rem] border transition-all hover:shadow-md group flex flex-col md:flex-row md:items-center gap-6 ${viewMode === 'archived' ? 'opacity-70 border-slate-100' : task.is_important ? 'border-amber-200 shadow-amber-50 shadow-sm' : 'border-slate-200'}`}>
            <button 
              onClick={() => handleToggleTask(task.id)}
              className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 border-2 transition-all ${
                task.status === 'Completed' 
                  ? 'bg-emerald-50 border-emerald-500 text-emerald-600' 
                  : 'bg-slate-50 border-transparent text-slate-400 group-hover:border-blue-300 group-hover:text-blue-500'
              }`}
            >
              {task.status === 'Completed' ? <CheckCircle2 size={24} /> : <CheckSquare size={24} />}
            </button>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-3 mb-1">
                <h4 className={`text-lg font-black truncate ${task.status === 'Completed' ? 'text-slate-400 line-through font-bold' : 'text-slate-800'}`}>
                  {task.name}
                </h4>
                {task.is_important && viewMode === 'active' && (
                  <span className="px-2 py-0.5 bg-amber-50 text-amber-700 text-[9px] font-black uppercase tracking-widest rounded-lg border border-amber-100">Critical</span>
                )}
                {task.status === 'Completed' && (
                  <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[9px] font-black uppercase tracking-widest rounded-lg border border-emerald-100">Completed</span>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-x-6 gap-y-2">
                {(() => {
                  const pid = (task.project_id || '').toString().trim();
                  const matchedProject = projects.find(p => p.id === pid || p.number.trim() === pid);
                  const linkPath = matchedProject ? `/project/${matchedProject.id}` : `/project/${pid}`;
                  const displayProjectName = matchedProject?.name || task.project_name || 'View Project';
                  
                  if (pid === '00000000-0000-0000-0000-000000000000') {
                    return (
                      <div className="flex flex-col gap-1">
                        <span className="flex items-center gap-2 text-[10px] font-black text-slate-500 uppercase">
                          <Briefcase size={12} /> {displayProjectName}
                        </span>
                      </div>
                    );
                  }

                  return (
                    <div className="flex flex-col gap-1">
                      <Link to={linkPath} className="flex items-center gap-2 text-[10px] font-black text-blue-600 uppercase hover:underline transition-all">
                        <Briefcase size={12} /> {displayProjectName}
                      </Link>
                      {matchedProject && (
                        <div className="flex items-center gap-3 ml-5">
                          <span className="text-[9px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                            #{matchedProject.number}
                          </span>
                          {matchedProject.address && (
                            <span className="text-[9px] font-medium text-slate-400 truncate max-w-[200px] uppercase">
                              {matchedProject.address}
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })()}
                <span className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase">
                  <UserIcon size={12} className="text-slate-300" /> {task.assigned_to || 'Unassigned'}
                </span>
                <span className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase">
                  <Calendar size={12} className="text-slate-300" /> {formatDate(task.due_date) || 'No Due Date'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              {(() => {
                const pid = (task.project_id || '').toString().trim();
                if (pid === '00000000-0000-0000-0000-000000000000') return null;
                
                const matchedProject = projects.find(p => p.id === pid || p.number.trim() === pid);
                const linkPath = matchedProject ? `/project/${matchedProject.id}` : `/project/${pid}`;
                
                return (
                  <Link 
                    to={linkPath} 
                    className="p-3 bg-slate-50 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-2xl transition-all flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
                  >
                    Project File <PlusCircle size={18} />
                  </Link>
                );
              })()}
            </div>
          </div>
        )) : (
          <div className="py-32 text-center bg-white rounded-[2rem] border-2 border-dashed border-slate-200">
            {viewMode === 'active' ? (
              <>
                <SearchX size={64} className="mx-auto mb-6 text-slate-200" />
                <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">No Active Tasks</h3>
                <p className="text-sm font-bold text-slate-400 uppercase mt-1">Great job! All assigned items are cleared.</p>
              </>
            ) : (
              <>
                <Archive size={64} className="mx-auto mb-6 text-slate-200" />
                <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Archive Empty</h3>
                <p className="text-sm font-bold text-slate-400 uppercase mt-1">Completed tasks will appear here for historical reference.</p>
              </>
            )}
            <button 
              onClick={() => { setAssigneeFilter('All'); setViewMode('board'); }}
              className="mt-6 px-6 py-2 bg-[#0c0054] text-white rounded-xl text-xs font-black uppercase tracking-widest hover:bg-blue-900 transition-all shadow-lg shadow-blue-900/10"
            >
              Reset View
            </button>
          </div>
        )}
      </div>
      )}

      {selectedTask && (
        <TaskModal 
          task={selectedTask} 
          currentUser={currentUser} 
          onClose={() => setSelectedTask(null)} 
          onUpdate={handleUpdateSingleTask} 
        />
      )}
    </div>
  );
};

export default TasksList;
