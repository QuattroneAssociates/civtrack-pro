
import React, { useMemo, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Project, ProjectStatus, Permit, Task, DashboardPrefs, User
} from '../types';
import { 
  ArrowUpRight, CheckCircle2, 
  ChevronRight, AlertTriangle, Wallet, LayoutGrid, Target, Settings2, X, Eye, EyeOff
} from 'lucide-react';

interface DashboardProps {
  projects: Project[];
  permits: Permit[];
  tasks: Task[];
  searchQuery?: string;
  onDeleteProject?: (id: string) => void;
  currentUser: User;
  dismissedAlerts?: string[];
  onDismiss?: (key: string) => void;
}

const PREFS_KEY = 'civtrack_dashboard_prefs_v2';

const defaultPrefs: DashboardPrefs = {
  show_metric_active_projects: true,
  show_metric_unpaid_fees: true,
  show_metric_critical_tasks: true,
  show_metric_radar_alerts: true,
  show_deadline_radar: true,
  show_recent_submissions: true
};

import { parseDateSafe, formatDate } from '../src/utils/dateUtils';

export const StatusBadge: React.FC<{ status: ProjectStatus }> = ({ status }) => {
  const styles: Record<ProjectStatus, string> = {
    [ProjectStatus.ACTIVE]: 'bg-blue-50 text-blue-700 border-blue-100',
    [ProjectStatus.ACTIVE_PRIORITY]: 'bg-rose-50 text-rose-700 border-rose-100 animate-pulse',
    [ProjectStatus.CLOSED]: 'bg-slate-100 text-slate-600 border-slate-200',
    [ProjectStatus.CONSTRUCTION]: 'bg-emerald-50 text-emerald-700 border-emerald-100',
    [ProjectStatus.ON_HOLD]: 'bg-amber-50 text-amber-700 border-amber-200',
    [ProjectStatus.PROPOSAL]: 'bg-purple-50 text-purple-700 border-purple-200',
    [ProjectStatus.CO_ISSUED]: 'bg-indigo-50 text-indigo-700 border-indigo-200',
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest border shadow-sm ${styles[status] || 'bg-slate-50 text-slate-500'}`}>
      {status}
    </span>
  );
};

const Dashboard: React.FC<DashboardProps> = ({ 
  projects, permits, tasks, searchQuery = '', currentUser, 
  dismissedAlerts = [], onDismiss 
}) => {
  const [prefs, setPrefs] = useState<DashboardPrefs>(() => {
    const saved = localStorage.getItem(PREFS_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return { ...defaultPrefs, ...parsed };
      } catch (e) {
        return defaultPrefs;
      }
    }
    return defaultPrefs;
  });
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Persist preferences to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  }, [prefs]);

  // Updated logic: Only show how many active and in construction projects there are. 
  // Don't include on hold, proposal, closed, or co-issued.
  const activePipelineProjectsCount = useMemo(() => {
    return projects.filter(p => {
      return (
        p.status === ProjectStatus.ACTIVE || 
        p.status === ProjectStatus.ACTIVE_PRIORITY || 
        p.status === ProjectStatus.CONSTRUCTION
      );
    }).length;
  }, [projects]);

  const totalProjectsCount = projects.length;

  const unpaidFeesPermits = useMemo(() => {
    return permits.filter(p => p.application_status === 'Fees Posted - Unpaid');
  }, [permits]);

  const unpaidFeesCount = unpaidFeesPermits.length;
  const unpaidFeesLink = useMemo(() => {
    if (unpaidFeesCount === 1) {
      const permit = unpaidFeesPermits[0];
      const project = projects.find(prj => prj.id === permit.project_id || prj.number === permit.project_id);
      return project ? `/project/${project.id}` : '/alerts';
    }
    return '/alerts';
  }, [unpaidFeesCount, unpaidFeesPermits, projects]);

  const recentlySubmittedProjects = useMemo(() => {
    const twoWeeksAgo = new Date();
    twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
    
    const recentPermits = permits.filter(p => {
      if (!p.submittal_date) return false;
      const subDate = parseDateSafe(p.submittal_date);
      if (!subDate) return false;
      return subDate >= twoWeeksAgo && subDate <= new Date();
    });

    recentPermits.sort((a, b) => {
      const dateA = parseDateSafe(a.submittal_date!)?.getTime() || 0;
      const dateB = parseDateSafe(b.submittal_date!)?.getTime() || 0;
      return dateB - dateA;
    });

    return recentPermits.slice(0, 10).map(permit => {
      const project = projects.find(prj => prj.id === permit.project_id || prj.number === permit.project_id);
      return { permit, project };
    }).filter(item => item.project);
  }, [permits, projects]);

  const criticalDeadlines = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return permits
      .map(p => {
        const proj = projects.find(prj => prj.id === p.project_id || prj.number === p.project_id);
        if (!proj) return null;
        const s = proj.status;
        if (s === ProjectStatus.CLOSED || s === ProjectStatus.CO_ISSUED) return null;
        let dateToTrack: Date | null = null;
        let typeLabel = '';
        let isExpiration = false;
        let alertKeySuffix = '';
        if (p.approval_date && p.expiration_date) {
          dateToTrack = parseDateSafe(p.expiration_date);
          typeLabel = 'Permit Expiration';
          isExpiration = true;
          alertKeySuffix = 'expiration';
        } else if (!p.approval_date && !p.submittal_date && !p.comments_1_date && p.target_date) {
          dateToTrack = parseDateSafe(p.target_date);
          typeLabel = 'Target Submittal';
          isExpiration = false;
          alertKeySuffix = 'target';
        } else if (p.expiration_date && !p.approval_date) {
          dateToTrack = parseDateSafe(p.expiration_date);
          typeLabel = 'Agency Expiration';
          isExpiration = true;
          alertKeySuffix = 'expiration';
        }
        if (!dateToTrack) return null;
        
        const alertKey = `${p.id}-${alertKeySuffix}`;
        if (dismissedAlerts.includes(alertKey)) return null;

        const diff = Math.ceil((dateToTrack.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        if (diff > 45) return null;
        return { ...p, diff, projectName: proj.name, typeLabel, alertKeySuffix, isExpiration, displayDate: dateToTrack.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) };
      })
      .filter((item): item is NonNullable<typeof item> => item !== null)
      .sort((a, b) => a.diff - b.diff)
      .slice(0, 7);
  }, [permits, projects, dismissedAlerts]);

  const anyMetricsShown = prefs.show_metric_active_projects || prefs.show_metric_unpaid_fees || prefs.show_metric_critical_tasks || prefs.show_metric_radar_alerts;

  const isFullAdmin = ['Application Owner', 'Administrator Full Access'].includes(currentUser.role);
  const isAdmin = isFullAdmin || currentUser.role === 'Administrator';
  const isPM = currentUser.role === 'Project Manager';
  const canSeeUnpaidFees = isAdmin || isPM;
  const canSeeAllTasks = ['Application Owner', 'Project Manager'].includes(currentUser.role);

  const criticalTasksCount = useMemo(() => {
    const baseTasks = canSeeAllTasks ? tasks : tasks.filter(t => t.assigned_to === currentUser.name);
    return baseTasks.filter(t => t.is_important && t.status !== 'Completed').length;
  }, [tasks, currentUser.name, canSeeAllTasks]);

  return (
    <div className="space-y-8 max-w-[1600px] mx-auto pb-20 animate-in fade-in duration-700">
      <div className="flex items-center justify-between px-2">
         <div className="space-y-1">
           <h2 className="text-2xl font-black text-slate-800 tracking-tight uppercase">Dashboard</h2>
         </div>
         <button 
           onClick={() => setIsSettingsOpen(true)}
           className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-[10px] font-black uppercase tracking-widest text-[#000066] hover:bg-slate-50 shadow-sm transition-all"
         >
           <Settings2 size={14} /> Customize Dashboard
         </button>
      </div>

      {anyMetricsShown && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <MetricCard to="/projects" label="Total Projects" value={totalProjectsCount} sub="All Records" icon={<LayoutGrid />} color="slate" />
          {prefs.show_metric_active_projects && (
            <MetricCard to="/projects" label="Active Pipeline" value={activePipelineProjectsCount} sub="Ongoing Ops" icon={<Target />} color="blue" />
          )}
          {prefs.show_metric_unpaid_fees && canSeeUnpaidFees && (
            <MetricCard to={unpaidFeesLink} label="Unpaid Fees" value={unpaidFeesCount} sub="Pending Payment" icon={<Wallet />} color="amber" />
          )}
          {prefs.show_metric_critical_tasks && (
            <MetricCard to="/tasks" label="Critical Tasks" value={criticalTasksCount} sub="High Priority" icon={<AlertTriangle />} color="rose" />
          )}
          {prefs.show_metric_radar_alerts && (
            <MetricCard to="/alerts" label="Radar Alerts" value={criticalDeadlines.filter(d => d.diff < 0).length} sub="Overdue Actions" icon={<Target />} color="indigo" />
          )}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
        {(prefs.show_recent_submissions || !prefs.show_deadline_radar) && (
          <div className={`${prefs.show_deadline_radar ? 'xl:col-span-8' : 'xl:col-span-12'} space-y-8`}>
            {prefs.show_recent_submissions ? (
              <div className="bg-white p-8 rounded-[3rem] border border-slate-200 shadow-sm h-full flex flex-col">
                <div className="flex items-center gap-3 mb-8">
                  <div className="p-2.5 bg-blue-50 rounded-2xl text-blue-600 border border-blue-100">
                    <CheckCircle2 size={22} />
                  </div>
                  <div>
                    <h3 className="text-sm font-black uppercase tracking-tight text-slate-800">Recently Submitted</h3>
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Permits submitted in the last 14 days</p>
                  </div>
                </div>
                
                <div className="space-y-3 flex-1 overflow-y-auto pr-2 no-scrollbar">
                  {recentlySubmittedProjects.length > 0 ? recentlySubmittedProjects.map((item, idx) => (
                    <Link 
                      key={`${item.permit.id}-${idx}`} 
                      to={`/project/${item.project!.id}?tab=permits`}
                      className="block p-4 bg-slate-50 hover:bg-blue-50 border border-slate-100 hover:border-blue-200 rounded-3xl transition-all group"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex flex-col gap-1">
                          <span className="px-2.5 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-widest w-fit bg-emerald-100 text-emerald-700">
                            {formatDate(item.permit.submittal_date!)}
                          </span>
                        </div>
                        <ArrowUpRight size={14} className="text-slate-400 group-hover:text-blue-600 transition-colors" />
                      </div>
                      <p className="text-sm font-black uppercase tracking-tight text-slate-800 group-hover:text-blue-700 transition-colors truncate mb-1">
                        {item.project!.name}
                      </p>
                      <p className="text-[10px] font-bold text-slate-500 uppercase truncate">
                        {item.permit.type} &bull; {item.project!.number}
                      </p>
                    </Link>
                  )) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-100 rounded-[2rem] p-10 h-full min-h-[200px]">
                      <LayoutGrid size={48} className="mb-4 opacity-20" />
                      <p className="text-[10px] font-black uppercase tracking-[0.3em]">No Recent Submissions</p>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="h-[400px] flex items-center justify-center border-2 border-dashed border-slate-100 rounded-[3rem]">
                <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest italic">Recent Submissions Disabled</p>
              </div>
            )}
          </div>
        )}

        {prefs.show_deadline_radar && (
          <div className={`${prefs.show_recent_submissions ? 'xl:col-span-4' : 'xl:col-span-12'} h-full`}>
            <div className="bg-slate-900 p-8 rounded-[3rem] shadow-2xl text-white h-full flex flex-col border border-slate-800">
              <div className="flex items-center gap-3 mb-10">
                <div className="p-2.5 bg-slate-800 rounded-2xl text-[#A68F5B] border border-slate-700 shadow-inner">
                  <Target size={22} />
                </div>
                <div>
                  <h3 className="text-sm font-black uppercase tracking-tight">Deadline Radar</h3>
                  <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Active Action Items</p>
                </div>
              </div>
              <div className="space-y-4 flex-1">
                {criticalDeadlines.length > 0 ? criticalDeadlines.map(d => (
                  <div key={d.id} className="relative group">
                    <Link to={`/project/${d.project_id}`} className="block p-4 bg-slate-800/40 hover:bg-slate-800 border border-slate-700/50 hover:border-slate-600 rounded-3xl transition-all">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex flex-col gap-1">
                           <span className={`px-2.5 py-0.5 rounded-lg text-[8px] font-black uppercase tracking-widest w-fit ${d.diff < 0 ? 'bg-rose-500 text-white animate-pulse' : 'bg-[#A68F5B] text-slate-900'}`}>
                            {d.diff < 0 ? (d.isExpiration ? 'EXPIRED' : 'OVERDUE') : `${d.diff} DAYS LEFT`}
                          </span>
                          <span className="text-[8px] font-black text-slate-500 uppercase tracking-[0.1em]">
                            {d.typeLabel}: {d.displayDate}
                          </span>
                        </div>
                        <ArrowUpRight size={14} className="text-slate-600 group-hover:text-white transition-colors" />
                      </div>
                      <p className="text-xs font-black uppercase tracking-tight text-slate-100 group-hover:text-[#A68F5B] transition-colors truncate mb-1">{d.projectName}</p>
                      <p className="text-[10px] font-bold text-slate-500 uppercase truncate">{d.type} &bull; {d.number || 'No #'}</p>
                    </Link>
                    {onDismiss && (['Application Owner', 'Administrator Full Access'].includes(currentUser.role)) && (
                      <button 
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          onDismiss(`${d.id}-${d.alertKeySuffix}`);
                        }}
                        className="absolute top-3 right-10 p-1.5 bg-slate-900/80 text-slate-500 hover:text-rose-500 rounded-lg opacity-0 group-hover:opacity-100 transition-all border border-slate-700"
                        title="Dismiss Alert"
                      >
                        <X size={12} />
                      </button>
                    )}
                  </div>
                )) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-slate-600 border-2 border-dashed border-slate-800 rounded-[2rem] p-10">
                    <CheckCircle2 size={48} className="mb-4 opacity-10" />
                    <p className="text-[10px] font-black uppercase tracking-[0.3em]">No Pending Alerts</p>
                  </div>
                )}
              </div>
              <Link to="/expiring" className="w-full mt-10 py-4 bg-white text-slate-900 rounded-2xl font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2 hover:bg-slate-100 transition-all shadow-xl">
                Full Agency Report <ChevronRight size={16} />
              </Link>
            </div>
          </div>
        )}
      </div>

      {isSettingsOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-8 py-6 border-b border-slate-50 flex items-center justify-between">
              <div>
                <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Dashboard Settings</h3>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Configure your personal view</p>
              </div>
              <button onClick={() => setIsSettingsOpen(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors"><X size={20} /></button>
            </div>
            
            <div className="p-8 space-y-8">
              <div className="space-y-4">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-50 pb-2">Metric Cards</p>
                <Toggle label="Active Projects" active={prefs.show_metric_active_projects} onChange={(v) => setPrefs({...prefs, show_metric_active_projects: v})} />
                {canSeeUnpaidFees && <Toggle label="Unpaid Fees Tracking" active={prefs.show_metric_unpaid_fees} onChange={(v) => setPrefs({...prefs, show_metric_unpaid_fees: v})} />}
                <Toggle label="Critical Task Counter" active={prefs.show_metric_critical_tasks} onChange={(v) => setPrefs({...prefs, show_metric_critical_tasks: v})} />
                <Toggle label="Overdue Radar Alerts" active={prefs.show_metric_radar_alerts} onChange={(v) => setPrefs({...prefs, show_metric_radar_alerts: v})} />
              </div>

              <div className="space-y-4 pt-4">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-50 pb-2">Layout Components</p>
                <Toggle label="Deadline Radar Panel" active={prefs.show_deadline_radar} onChange={(v) => setPrefs({...prefs, show_deadline_radar: v})} />
                <Toggle label="Recent Submissions" active={prefs.show_recent_submissions} onChange={(v) => setPrefs({...prefs, show_recent_submissions: v})} />
              </div>

              <div className="flex gap-3 pt-4">
                <button 
                  onClick={() => setIsSettingsOpen(false)}
                  className="flex-1 py-4 bg-[#000066] text-white rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-blue-800 shadow-lg transition-all"
                >
                  Save View
                </button>
                <button 
                  onClick={() => setPrefs(defaultPrefs)}
                  className="py-4 px-6 bg-slate-100 text-slate-600 rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-slate-200 transition-all"
                >
                  Reset
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const Toggle: React.FC<{ label: string, active: boolean, onChange: (v: boolean) => void }> = ({ label, active, onChange }) => (
  <button 
    onClick={() => onChange(!active)}
    className="w-full flex items-center justify-between group"
  >
    <div className="flex items-center gap-3">
      <div className={`p-2 rounded-lg transition-colors ${active ? 'bg-blue-50 text-blue-600' : 'bg-slate-100 text-slate-400'}`}>
        {active ? <Eye size={16} /> : <EyeOff size={16} />}
      </div>
      <span className={`text-sm font-bold transition-colors ${active ? 'text-slate-800' : 'text-slate-400'}`}>{label}</span>
    </div>
    <div className={`w-12 h-6 rounded-full relative transition-all duration-300 ${active ? 'bg-[#000066]' : 'bg-slate-200'}`}>
      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 shadow-sm ${active ? 'left-7' : 'left-1'}`} />
    </div>
  </button>
);

const MetricCard: React.FC<{ to: string, label: string, value: string | number, sub: string, icon: React.ReactNode, color: 'blue' | 'rose' | 'amber' | 'indigo' | 'slate' }> = ({ to, label, value, sub, icon, color }) => {
  const styles = {
    blue: 'border-blue-50 hover:border-blue-200',
    rose: 'border-rose-50 hover:border-rose-200',
    amber: 'border-amber-50 hover:border-amber-200',
    indigo: 'border-indigo-50 hover:border-indigo-200',
    slate: 'border-slate-50 hover:border-slate-200'
  };
  return (
    <Link to={to} className={`bg-white p-6 rounded-[2.5rem] border transition-all hover:shadow-xl group block outline-none focus:ring-2 focus:ring-[#000066]/10 ${styles[color]}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="p-3 bg-slate-50 rounded-2xl group-hover:bg-white group-hover:shadow-inner transition-all text-slate-400 group-hover:text-slate-800 border border-transparent group-hover:border-slate-100">{icon}</div>
        <span className="text-3xl font-black text-slate-800 tracking-tighter">{value}</span>
      </div>
      <div>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{label}</p>
        <p className="text-xs font-bold text-slate-500 italic">{sub}</p>
      </div>
    </Link>
  );
};

export default Dashboard;
