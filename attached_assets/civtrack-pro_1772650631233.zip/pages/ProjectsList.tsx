
import React, { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Project, ProjectStatus, User, Permit } from '../types';
import { StatusBadge } from './Dashboard';
import { ArrowUpRight, Filter, SearchX, Eye, Target, ChevronLeft, ChevronRight, Trash2 } from 'lucide-react';
import SearchableSelect from '../SearchableSelect';

interface ProjectsListProps {
  projects: Project[];
  permits: Permit[];
  users: User[];
  searchQuery?: string;
  onDeleteProject?: (id: string) => void;
  currentUser: User;
}

const ProjectsList: React.FC<ProjectsListProps> = ({ projects, permits, users, searchQuery = '', onDeleteProject, currentUser }) => {
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [pmFilter, setPmFilter] = useState<string>('All');
  
  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 25;

  // Reset to page 1 when any filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, statusFilter, pmFilter]);

  const filteredProjects = useMemo(() => {
    let filtered = [...projects];

    // Global Search Filter
    if (searchQuery && searchQuery.trim()) {
      const words = searchQuery.toLowerCase().trim().split(/\s+/).filter(Boolean);
      filtered = filtered.filter(p => {
        const projectPermits = permits.filter(per => per.project_id === p.id || per.project_id === p.number);
        const searchableText = [
          p.name,
          p.number,
          p.address,
          p.client_name,
          p.agency,
          p.strap_number || '',
          p.project_manager_name || '',
          users.find(u => u.id === p.project_manager_id)?.name || '',
          ...projectPermits.map(per => per.number || '')
        ].join(' ').toLowerCase();
        
        return words.every(word => searchableText.includes(word));
      });
    }

    // Status Filter
    if (statusFilter !== 'All') {
      filtered = filtered.filter(p => {
        if (statusFilter === 'Active') {
          return p.status === ProjectStatus.ACTIVE || p.status === ProjectStatus.ACTIVE_PRIORITY;
        }
        return p.status === statusFilter;
      });
    }

    // PM Filter
    if (pmFilter !== 'All') {
      filtered = filtered.filter(p => p.project_manager_id === pmFilter);
    }

    return filtered;
  }, [projects, searchQuery, statusFilter, pmFilter]);

  // Calculate project counts for each status chip
  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = {
      All: projects.length,
      Active: projects.filter(p => p.status === ProjectStatus.ACTIVE || p.status === ProjectStatus.ACTIVE_PRIORITY).length,
      Construction: projects.filter(p => p.status === ProjectStatus.CONSTRUCTION).length,
      Closed: projects.filter(p => p.status === ProjectStatus.CLOSED).length,
      'On Hold': projects.filter(p => p.status === ProjectStatus.ON_HOLD).length,
      Proposal: projects.filter(p => p.status === ProjectStatus.PROPOSAL).length,
    };
    return counts;
  }, [projects]);

  // Calculate Active project counts per Manager
  const pmActiveCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    projects.forEach(p => {
      if (p.status === ProjectStatus.ACTIVE || p.status === ProjectStatus.ACTIVE_PRIORITY) {
        counts[p.project_manager_id] = (counts[p.project_manager_id] || 0) + 1;
      }
    });
    return counts;
  }, [projects]);

  const pmOptions = useMemo(() => [
    { id: 'All', label: 'All Project Managers' },
    ...users.map(u => ({ 
      id: u.id, 
      label: `${u.name} (${pmActiveCounts[u.id] || 0} Active)` 
    }))
  ], [users, pmActiveCounts]);

  // Calculate Paginated Data
  const totalPages = Math.ceil(filteredProjects.length / itemsPerPage);
  const paginatedProjects = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredProjects.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredProjects, currentPage]);

  const statuses = ['All', 'Active', 'Construction', 'Closed', 'On Hold', 'Proposal'];

  const isFullAdmin = ['Application Owner', 'Administrator Full Access'].includes(currentUser.role);
  const isAdmin = isFullAdmin || currentUser.role === 'Administrator';

  return (
    <div className="space-y-6 animate-in slide-in-from-right-4 duration-500 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm">
        {/* Status Filter Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 lg:pb-0 no-scrollbar">
          <div className="p-2 bg-slate-50 rounded-xl text-slate-400 mr-2 shrink-0">
            <Filter size={18} />
          </div>
          {statuses.map(status => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap flex items-center gap-2 ${
                statusFilter === status 
                  ? 'bg-[#000066] text-white shadow-lg shadow-blue-900/20' 
                  : 'bg-slate-100 text-slate-500 hover:bg-slate-200 border border-transparent'
              }`}
            >
              {status}
              <span className={`px-1.5 py-0.5 rounded text-[9px] ${
                statusFilter === status 
                  ? 'bg-blue-400/30 text-white' 
                  : 'bg-slate-200 text-slate-500'
              }`}>
                {statusCounts[status]}
              </span>
            </button>
          ))}
        </div>

        {/* PM Filter Dropdown */}
        <div className="w-full lg:w-80">
          <SearchableSelect
            options={pmOptions}
            value={pmFilter}
            onChange={setPmFilter}
            placeholder="Filter by Manager"
          />
        </div>
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-200 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left table-auto">
            <thead className="bg-slate-50/80 text-slate-400 text-[10px] font-black uppercase tracking-widest sticky top-0 z-10">
              <tr>
                <th className="px-8 py-6">Project Name & Number</th>
                <th className="px-8 py-6">Project Manager</th>
                <th className="px-8 py-6">Lead Agency</th>
                <th className="px-8 py-6">Status</th>
                <th className="px-8 py-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedProjects.length > 0 ? paginatedProjects.map((project) => {
                const manager = users.find(u => u.id === project.project_manager_id) || 
                                users.find(u => u.name === project.project_manager_id) ||
                                users.find(u => u.name === project.project_manager_name);
                
                return (
                  <tr key={project.id} className="hover:bg-blue-50/30 transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex flex-col">
                        <div className="flex items-center gap-3">
                          <span className="text-sm font-black text-slate-800 group-hover:text-[#000066] transition-colors">
                            {project.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 mt-1.5">
                          <span className="text-lg font-sans font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-lg tracking-tight uppercase shadow-sm">
                            {project.number}
                          </span>
                          <span className="text-xs font-bold text-slate-400 truncate max-w-[200px]">
                            {project.client_name}
                          </span>
                        </div>
                        {(project.address || project.strap_number) && (
                          <div className="flex flex-col gap-0.5 mt-2">
                            {project.address && (
                              <span className="text-[10px] font-medium text-slate-400 truncate">
                                {project.address}
                              </span>
                            )}
                            {project.strap_number && (
                              <span className="text-[10px] font-mono font-bold text-slate-500">
                                STRAP: {project.strap_number}
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-black text-slate-400 border border-slate-200">
                          {(manager?.name || '').split(' ').map(n => n[0]).join('')}
                        </div>
                        <span className="text-sm font-bold text-slate-600">
                          {manager?.name || 'Unassigned'}
                        </span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <span className="text-xs font-black text-slate-400 uppercase tracking-tight">
                        {project.agency}
                      </span>
                    </td>
                    <td className="px-8 py-6">
                      <StatusBadge status={project.status} />
                    </td>
                    <td className="px-8 py-6 text-right">
                      <div className="flex items-center justify-end gap-3">
                        <Link 
                          to={`/project/${project.id}`} 
                          className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest text-[#000066] hover:border-[#000066] hover:bg-slate-50 transition-all inline-flex items-center gap-2 shadow-sm"
                        >
                          View <ArrowUpRight size={14} />
                        </Link>
                        {isAdmin && onDeleteProject && (
                          <button 
                            onClick={(e) => {
                              e.preventDefault();
                              onDeleteProject(project.id);
                            }}
                            className="p-2.5 text-slate-300 hover:text-rose-600 transition-all rounded-xl hover:bg-rose-50 border border-transparent hover:border-rose-100"
                            title="Delete Project"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={6} className="px-8 py-32 text-center">
                    <div className="flex flex-col items-center gap-4 text-slate-300">
                      <SearchX size={64} strokeWidth={1} />
                      <div className="space-y-1">
                        <p className="text-sm font-black uppercase tracking-[0.2em]">No matches found</p>
                        <p className="text-xs font-bold text-slate-400 italic">Try adjusting your filters or search query.</p>
                      </div>
                      <button 
                        onClick={() => { setPmFilter('All'); setStatusFilter('All'); }}
                        className="mt-2 text-[#000066] font-black uppercase text-[10px] tracking-widest hover:underline"
                      >
                        Reset Filters
                      </button>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {/* Pagination Footer */}
        <div className="bg-slate-50 px-8 py-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-col items-start gap-1">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">
              Directory Overview
            </span>
            <span className="text-xs font-bold text-slate-600">
              Showing {filteredProjects.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0} - {Math.min(currentPage * itemsPerPage, filteredProjects.length)} of {filteredProjects.length} matching projects
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <button 
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
              className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-[#000066] hover:border-[#000066] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronLeft size={18} />
            </button>
            
            <div className="flex items-center gap-1 px-2">
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                // Showing a simplified range if pages > 5
                let pageNum = i + 1;
                if (totalPages > 5 && currentPage > 3) {
                   pageNum = currentPage - 2 + i;
                   if (pageNum > totalPages) pageNum = totalPages - (4 - i);
                }
                
                if (pageNum <= 0 || pageNum > totalPages) return null;

                return (
                  <button
                    key={pageNum}
                    onClick={() => setCurrentPage(pageNum)}
                    className={`w-10 h-10 rounded-xl text-xs font-black transition-all ${
                      currentPage === pageNum 
                        ? 'bg-[#000066] text-white shadow-lg' 
                        : 'bg-white border border-slate-100 text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    {pageNum}
                  </button>
                );
              })}
              {totalPages > 5 && currentPage < totalPages - 2 && <span className="px-2 text-slate-300 font-bold">...</span>}
            </div>

            <button 
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages || totalPages === 0}
              className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-[#000066] hover:border-[#000066] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectsList;
