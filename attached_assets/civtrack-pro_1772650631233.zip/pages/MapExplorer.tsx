import React, { useState } from 'react';
import { Project, User } from '../types';
import ProjectMap from '../src/components/ProjectMap';
import { Map as MapIcon, Search, Filter, Layers, Navigation, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';

interface MapExplorerProps {
  projects: Project[];
  currentUser: User;
}

const providers = {
  street: (x: number, y: number, z: number) => `https://tile.openstreetmap.org/${z}/${x}/${y}.png`,
  satellite: (x: number, y: number, z: number) => `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`
};

const MapExplorer: React.FC<MapExplorerProps> = ({ projects, currentUser }) => {
  const [mapProvider, setMapProvider] = useState<keyof typeof providers>('street');
  const [mapCenter, setMapCenter] = useState<[number, number]>([26.6406, -81.8723]);
  const [mapZoom, setMapZoom] = useState(11);

  return (
    <div className="h-[calc(100vh-140px)] flex flex-col gap-6 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm shrink-0">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl border border-emerald-100 shadow-inner">
            <MapIcon size={24} />
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-800 tracking-tight uppercase">GIS Map Explorer</h1>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-0.5">Street & Satellite View</p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
          <button 
            onClick={() => setMapProvider('street')}
            className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mapProvider === 'street' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Street View
          </button>
          <button 
            onClick={() => setMapProvider('satellite')}
            className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mapProvider === 'satellite' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
          >
            Satellite View
          </button>
        </div>
      </div>

      <div className="flex-1 bg-white rounded-[2.5rem] border border-slate-200 shadow-xl overflow-hidden relative">
        <ProjectMap 
          projects={[]} 
          provider={providers[mapProvider]}
          center={mapCenter}
          zoom={mapZoom}
          onBoundsChanged={({ center, zoom }) => {
            setMapCenter(center);
            setMapZoom(zoom);
          }}
        />
      </div>
    </div>
  );
};

export default MapExplorer;
