import React, { useState, useMemo } from 'react';
import { User } from '../types';
import { 
  Users, Plus, Search, Mail, Shield, 
  CheckCircle2, XCircle, MoreVertical, 
  UserPlus, Pencil, Trash2, ShieldCheck,
  ShieldAlert, Filter, X
} from 'lucide-react';

interface UserDirectoryProps {
  users: User[];
  onSaveUser: (user: User) => void;
  currentUser: User;
}

const UserDirectory: React.FC<UserDirectoryProps> = ({ users, onSaveUser, currentUser }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [formData, setFormData] = useState<Partial<User>>({
    name: '',
    email: '',
    role: 'Engineer',
    is_active: true
  });

  const filteredUsers = useMemo(() => {
    const q = (searchQuery || '').toLowerCase();
    return users.filter(u => 
      (u.name || '').toLowerCase().includes(q) ||
      (u.email || '').toLowerCase().includes(q) ||
      (u.role || '').toLowerCase().includes(q)
    );
  }, [users, searchQuery]);

  const handleOpenModal = (user?: User) => {
    if (user) {
      setEditingUser(user);
      setFormData(user);
    } else {
      setEditingUser(null);
      setFormData({
        name: '',
        email: '',
        role: 'Engineer',
        is_active: true
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const userToSave: User = {
      id: editingUser?.id || crypto.randomUUID(),
      name: formData.name || '',
      email: formData.email || '',
      role: formData.role || 'Engineer',
      is_active: formData.is_active !== undefined ? formData.is_active : true,
      created_at: editingUser?.created_at || new Date().toISOString()
    };
    onSaveUser(userToSave);
    setIsModalOpen(false);
  };

  const roles = [
    'Application Owner',
    'Administrator Full Access',
    'Administrator',
    'Project Manager',
    'CAD',
    'EI'
  ];

  const isAdmin = ['Application Owner', 'Administrator Full Access'].includes(currentUser.role);

  return (
    <div className="space-y-8 animate-in fade-in duration-700 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
        <div className="flex items-center gap-5">
          <div className="p-4 bg-indigo-50 text-indigo-600 rounded-3xl border border-indigo-100 shadow-inner">
            <Users size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-800 tracking-tight uppercase">Personnel Directory</h1>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-1">Manage Team Access & Roles</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Search personnel..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:outline-none focus:ring-4 focus:ring-indigo-500/10 min-w-[300px] transition-all"
            />
          </div>
          {isAdmin && (
            <button 
              onClick={() => handleOpenModal()}
              className="flex items-center gap-3 px-8 py-4 bg-[#000066] text-white rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-blue-800 shadow-xl shadow-blue-900/20 transition-all active:scale-95"
            >
              <UserPlus size={18} /> Add Member
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredUsers.map(user => (
          <div key={user.id} className={`bg-white p-8 rounded-[2.5rem] border transition-all hover:shadow-2xl group relative overflow-hidden ${!user.is_active ? 'opacity-60 grayscale' : 'border-slate-200 hover:border-indigo-200'}`}>
            {!user.is_active && (
              <div className="absolute top-0 right-0 bg-slate-100 text-slate-400 px-4 py-1.5 text-[8px] font-black uppercase tracking-widest rounded-bl-2xl border-l border-b border-slate-200">
                Deactivated
              </div>
            )}
            
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className={`w-16 h-16 rounded-3xl flex items-center justify-center text-xl font-black border shadow-inner transition-colors ${user.is_active ? 'bg-slate-50 text-slate-400 border-slate-100 group-hover:bg-indigo-50 group-hover:text-indigo-500 group-hover:border-indigo-100' : 'bg-slate-100 text-slate-300 border-slate-200'}`}>
                  {(user.name || '').split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight group-hover:text-indigo-600 transition-colors">{user.name}</h3>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{user.role}</p>
                </div>
              </div>
              {isAdmin && (
                <button 
                  onClick={() => handleOpenModal(user)}
                  className="p-2.5 hover:bg-slate-50 rounded-xl text-slate-300 hover:text-indigo-600 transition-all border border-transparent hover:border-slate-100"
                >
                  <Pencil size={18} />
                </button>
              )}
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-3 text-slate-500">
                <div className="p-2 bg-slate-50 rounded-lg group-hover:bg-indigo-50 transition-colors">
                  <Mail size={14} className="group-hover:text-indigo-500" />
                </div>
                <span className="text-xs font-bold truncate">{user.email}</span>
              </div>
              <div className="flex items-center gap-3 text-slate-500">
                <div className="p-2 bg-slate-50 rounded-lg group-hover:bg-indigo-50 transition-colors">
                  <Shield size={14} className="group-hover:text-indigo-500" />
                </div>
                <span className="text-xs font-bold uppercase tracking-widest">{user.role}</span>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2">
                {user.is_active ? (
                  <div className="flex items-center gap-1.5 text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                    <CheckCircle2 size={12} />
                    <span className="text-[9px] font-black uppercase tracking-widest">Active</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 text-slate-400 bg-slate-50 px-3 py-1 rounded-full border border-slate-100">
                    <XCircle size={12} />
                    <span className="text-[9px] font-black uppercase tracking-widest">Inactive</span>
                  </div>
                )}
              </div>
              <span className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">ID: {user.id}</span>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-lg rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="px-10 py-8 border-b border-slate-50 flex items-center justify-between bg-slate-50/50">
              <div>
                <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight">
                  {editingUser ? 'Edit Personnel' : 'Add New Member'}
                </h3>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                  {editingUser ? `Updating profile for ${editingUser.name}` : 'Configure access for a new team member'}
                </p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="p-3 hover:bg-white rounded-2xl transition-all shadow-sm"><X size={24} /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-10 space-y-8">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Full Name</label>
                  <input 
                    type="text" 
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                    placeholder="e.g. John Doe"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Email Address</label>
                  <input 
                    type="email" 
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all"
                    placeholder="john@quattrone.com"
                  />
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Role / Title</label>
                    <select 
                      value={formData.role}
                      onChange={(e) => setFormData({...formData, role: e.target.value})}
                      className="w-full px-6 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all appearance-none"
                    >
                      {roles.map(role => (
                        <option key={role} value={role}>{role}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-1">Account Status</label>
                    <div className="flex bg-slate-50 p-1 rounded-2xl border border-slate-200">
                      <button 
                        type="button"
                        onClick={() => setFormData({...formData, is_active: true})}
                        className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${formData.is_active ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                      >
                        Active
                      </button>
                      <button 
                        type="button"
                        onClick={() => setFormData({...formData, is_active: false})}
                        className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${!formData.is_active ? 'bg-white text-rose-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
                      >
                        Inactive
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-4 pt-6">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-5 bg-slate-100 text-slate-500 rounded-[1.5rem] font-black uppercase text-[10px] tracking-widest hover:bg-slate-200 transition-all"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="flex-[2] py-5 bg-[#000066] text-white rounded-[1.5rem] font-black uppercase text-[10px] tracking-widest hover:bg-blue-800 shadow-xl shadow-blue-900/20 transition-all"
                >
                  {editingUser ? 'Update Member' : 'Create Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserDirectory;
