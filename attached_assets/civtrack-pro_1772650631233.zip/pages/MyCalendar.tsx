
import React, { useState, useMemo, useEffect } from 'react';
import { 
  ChevronLeft, ChevronRight, Calendar as CalendarIcon, 
  Printer, Briefcase, User as UserIcon, ExternalLink,
  Layers, Zap, Target, CalendarRange, Download, Plus,
  Info, Clock, Filter, Eye, EyeOff, BarChart2, X
} from 'lucide-react';
import { User, Task, Project, Permit } from '../types';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { parseDateSafe } from '../src/utils/dateUtils';

interface MyCalendarProps {
  currentUser: User;
  users: User[];
  tasks: Task[];
  projects: Project[];
  permits: Permit[];
  onUpdateTasks: (tasks: Task[]) => void;
}

const CALENDAR_USER_KEY = 'civtrack_selected_calendar_user';
const CALENDAR_LAYERS_KEY = 'civtrack_calendar_layers';

const MyCalendar: React.FC<MyCalendarProps> = ({ currentUser, users, tasks, projects, permits, onUpdateTasks }) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState<'month' | 'week'>('month');
  const [hoveredEvent, setHoveredEvent] = useState<{ id: string; type: string; x: number; y: number } | null>(null);
  const [showQuickAdd, setShowQuickAdd] = useState<{ date: string } | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [quickTaskName, setQuickTaskName] = useState('');
  
  // Layers state
  const [layers, setLayers] = useState(() => {
    const saved = localStorage.getItem(CALENDAR_LAYERS_KEY);
    return saved ? JSON.parse(saved) : { tasks: true, permits: true };
  });

  // Access Control: Only Owner can see everyone
  const canSeeAll = currentUser.role === 'Application Owner';
  
  const [selectedUserName, setSelectedUserName] = useState<string>(() => {
    if (!canSeeAll) return currentUser.name;
    const saved = localStorage.getItem(CALENDAR_USER_KEY);
    return saved || currentUser.name;
  });

  useEffect(() => {
    localStorage.setItem(CALENDAR_LAYERS_KEY, JSON.stringify(layers));
  }, [layers]);

  useEffect(() => {
    if (canSeeAll) {
      localStorage.setItem(CALENDAR_USER_KEY, selectedUserName);
    } else {
      setSelectedUserName(currentUser.name);
    }
  }, [selectedUserName, canSeeAll, currentUser.name]);

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  // Filter tasks for the selected user (include completed)
  // Using a more robust matching for names (case-insensitive and partial)
  const filteredTasks = useMemo(() => {
    if (selectedUserName === 'All') return tasks;
    const searchName = selectedUserName.toLowerCase();
    return tasks.filter(t => {
      const assigned = (t.assigned_to || '').toLowerCase();
      return assigned === searchName || assigned.includes(searchName) || searchName.includes(assigned);
    });
  }, [tasks, selectedUserName]);

  const prevMonth = () => setCurrentDate(new Date(year, month - (view === 'month' ? 1 : 0), view === 'month' ? 1 : currentDate.getDate() - 7));
  const nextMonth = () => setCurrentDate(new Date(year, month + (view === 'month' ? 1 : 0), view === 'month' ? 1 : currentDate.getDate() + 7));
  const goToToday = () => setCurrentDate(new Date());

  const handlePrint = () => window.print();

  const handleQuickAdd = () => {
    if (!quickTaskName.trim() || !showQuickAdd) return;
    
    // Ensure the date string is correctly formatted as YYYY-MM-DD
    const dateStr = showQuickAdd.date;
    
    const newTask: Task = {
      id: crypto.randomUUID(),
      project_id: '00000000-0000-0000-0000-000000000000', // Unassigned project
      project_name: 'Unassigned',
      name: quickTaskName,
      description: 'Quick added task',
      assigned_by: currentUser.name,
      assigned_to: selectedUserName,
      date_assigned: new Date().toISOString().split('T')[0],
      due_date: dateStr,
      status: 'Pending',
      is_important: false
    };

    onUpdateTasks([...tasks, newTask]);
    setQuickTaskName('');
    setShowQuickAdd(null);
  };

  const handleToggleTaskStatus = (task: Task) => {
    const newStatus = task.status === 'Completed' ? 'Pending' : 'Completed';
    const updatedTasks = tasks.map(t => t.id === task.id ? { ...t, status: newStatus } : t);
    onUpdateTasks(updatedTasks);
    if (selectedTask?.id === task.id) {
      setSelectedTask({ ...task, status: newStatus });
    }
  };

  const exportICal = () => {
    const events = filteredTasks.map(t => {
      const date = t.due_date.replace(/-/g, '');
      return `BEGIN:VEVENT
DTSTART;VALUE=DATE:${date}
DTEND;VALUE=DATE:${date}
SUMMARY:${t.name}
DESCRIPTION:${t.description || ''}
END:VEVENT`;
    }).join('\n');

    const icalContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//CivTrack Pro//Task Agenda//EN
${events}
END:VCALENDAR`;

    const blob = new Blob([icalContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `civtrack-agenda-${selectedUserName.replace(/\s+/g, '-').toLowerCase()}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getEventsForDay = (day: number, m: number, y: number) => {
    const dateStr = `${y}-${String(m + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const dayEvents: any[] = [];

    if (layers.tasks) {
      filteredTasks.filter(t => {
        if (!t.due_date) return false;
        // Compare raw YYYY-MM-DD strings directly to avoid timezone shifts
        if (t.due_date.includes('-') && t.due_date.length === 10) {
          return t.due_date === dateStr;
        }
        
        // Fallback for other formats
        const d = parseDateSafe(t.due_date);
        if (!d) return false;
        const normalized = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        return normalized === dateStr;
      }).forEach(t => dayEvents.push({ ...t, calendarType: 'task' }));
    }

    if (layers.permits) {
      permits.filter(p => {
        if (!p.expiration_date) return false;
        // Compare raw YYYY-MM-DD strings directly to avoid timezone shifts
        if (p.expiration_date.includes('-') && p.expiration_date.length === 10) {
          return p.expiration_date === dateStr;
        }
        
        // Fallback for other formats
        const d = parseDateSafe(p.expiration_date);
        if (!d) return false;
        const normalized = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        return normalized === dateStr;
      }).forEach(p => dayEvents.push({ ...p, calendarType: 'expiration', name: `EXP: ${p.type}` }));
    }

    return dayEvents;
  };

  const renderMonthView = () => {
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDayOfMonth = new Date(year, month, 1).getDay();
    const totalSlots = 42; 
    const dayElements = [];

    for (let i = 0; i < firstDayOfMonth; i++) {
      dayElements.push(<div key={`empty-${i}`} className="h-32 bg-slate-50/30 border-r border-b border-slate-100 opacity-20 print:border-slate-300" />);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      // Create date string in local time to avoid timezone shifts
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const dayEvents = getEventsForDay(day, month, year);
      const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();

      dayElements.push(
        <div 
          key={`day-${day}`} 
          className="h-32 border-r border-b border-slate-100 bg-white hover:bg-blue-50/20 transition-all relative group print:border-slate-300"
          onClick={() => setShowQuickAdd({ date: dateStr })}
        >
          <div className="p-2 flex items-center justify-between relative z-10">
            <span className={`text-xs font-black ${isToday ? 'w-6 h-6 bg-[#000066] text-white rounded-lg flex items-center justify-center print:bg-slate-200 print:text-black' : 'text-slate-400'}`}>
              {day}
            </span>
            <button className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-[#000066] transition-opacity">
              <Plus size={10} />
            </button>
          </div>
          <div className="px-1.5 space-y-1 overflow-y-auto max-h-[85px] no-scrollbar relative z-10 print:overflow-visible print:max-h-none">
            {dayEvents.map(event => {
              const project = projects.find(p => p.id === event.project_id || p.number === event.project_id || p.name === event.project_name);
              const isCompleted = event.status === 'Completed';
              
              let bgColor = isCompleted ? 'bg-slate-50 text-slate-400 border-slate-100' : 'bg-blue-50 text-blue-700 border-blue-100';
              if (event.calendarType === 'expiration') bgColor = 'bg-rose-50 text-rose-700 border-rose-100';
              if (event.is_important && !isCompleted) bgColor = 'bg-rose-500 text-white border-rose-600';

              return (
                <div 
                  key={event.id}
                  className="relative"
                  onMouseEnter={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    setHoveredEvent({ id: event.id, type: event.calendarType, x: rect.left, y: rect.top });
                  }}
                  onMouseLeave={() => setHoveredEvent(null)}
                >
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      if (event.calendarType === 'task') {
                        setSelectedTask(event);
                      } else if (project) {
                        window.location.hash = `#/project/${project.id}`;
                      }
                    }}
                    className={`block w-full text-left px-2 py-1 rounded-md text-[9px] font-bold truncate border shadow-sm transition-transform active:scale-95 ${bgColor} ${isCompleted ? 'line-through' : ''} print:bg-white print:border-slate-300 print:text-black print:shadow-none`}
                  >
                    {event.name}
                  </button>
                  
                  <AnimatePresence>
                    {hoveredEvent?.id === event.id && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.9, y: 10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 10 }}
                        className="fixed z-[200] w-64 p-4 bg-white/80 backdrop-blur-xl border border-white/20 rounded-2xl shadow-2xl pointer-events-none"
                        style={{ left: hoveredEvent.x, top: hoveredEvent.y - 140 }}
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <div className={`w-2 h-2 rounded-full ${event.calendarType === 'expiration' ? 'bg-rose-500' : 'bg-blue-500'}`} />
                          <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{event.calendarType}</span>
                        </div>
                        <p className="text-xs font-black text-slate-800 mb-1">{event.name}</p>
                        <p className="text-[10px] text-slate-500 line-clamp-2 mb-3">{event.description || 'No description provided.'}</p>
                        <div className="flex items-center justify-between border-t border-slate-100 pt-2">
                          <span className="text-[9px] font-bold text-slate-400 uppercase">{event.assigned_to || 'System'}</span>
                          <span className="text-[9px] font-black text-[#000066] uppercase">{event.status || 'Active'}</span>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </div>
      );
    }

    const remaining = totalSlots - dayElements.length;
    for (let i = 1; i <= remaining; i++) {
      dayElements.push(<div key={`empty-end-${i}`} className="h-32 bg-slate-50/30 border-r border-b border-slate-100 opacity-20 print:border-slate-300" />);
    }

    return dayElements;
  };

  const renderWeekView = () => {
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
    const weekDays = [];

    for (let i = 0; i < 7; i++) {
      const day = new Date(startOfWeek);
      day.setDate(startOfWeek.getDate() + i);
      const isToday = new Date().toDateString() === day.toDateString();
      const dayEvents = getEventsForDay(day.getDate(), day.getMonth(), day.getFullYear());

      weekDays.push(
        <div key={i} className="flex-1 min-h-[600px] border-r border-slate-100 bg-white print:border-slate-300">
          <div className={`p-4 text-center border-b border-slate-50 ${isToday ? 'bg-blue-50/50' : ''}`}>
            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1">{['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][i]}</p>
            <p className={`text-xl font-black ${isToday ? 'text-[#000066]' : 'text-slate-800'}`}>{day.getDate()}</p>
          </div>
          <div className="p-3 space-y-3">
            {dayEvents.map(event => {
              const isCompleted = event.status === 'Completed';
              return (
                <div 
                  key={event.id} 
                  onClick={() => event.calendarType === 'task' ? setSelectedTask(event) : null}
                  className={`p-3 rounded-xl border shadow-sm cursor-pointer transition-all hover:shadow-md ${event.calendarType === 'expiration' ? 'bg-rose-50 border-rose-100' : 'bg-white border-slate-100'} ${isCompleted ? 'opacity-60' : ''}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-[8px] font-black uppercase tracking-widest ${event.calendarType === 'expiration' ? 'text-rose-600' : 'text-blue-600'}`}>
                      {event.calendarType}
                    </span>
                    <Clock size={10} className="text-slate-300" />
                  </div>
                  <p className={`text-xl font-black text-slate-800 leading-tight mb-1 ${isCompleted ? 'line-through' : ''}`}>{event.name}</p>
                  <p className="text-[9px] text-slate-500 line-clamp-2 mb-2">{event.description}</p>
                  <div className="text-[9px] font-black text-[#000066] uppercase hover:underline flex items-center gap-1">
                    View Details <ExternalLink size={8} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      );
    }
    return weekDays;
  };

  return (
    <div className="max-w-[1600px] mx-auto space-y-8 animate-in fade-in duration-700 pb-20">
      {/* Header Controls */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-6 px-2 print:hidden">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-white rounded-2xl shadow-sm border border-slate-200">
            <CalendarIcon size={24} className="text-[#000066]" />
          </div>
          <div>
            <h1 className="text-3xl font-black text-slate-800 tracking-tight uppercase leading-none">
              {view === 'month' ? `${monthNames[month]} ${year}` : 'Weekly Agenda'}
            </h1>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-2">
              {selectedUserName}'s Operational Schedule
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* View Toggle */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 mr-2">
            <button 
              onClick={() => setView('month')}
              className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${view === 'month' ? 'bg-white text-[#000066] shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Month
            </button>
            <button 
              onClick={() => setView('week')}
              className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${view === 'week' ? 'bg-white text-[#000066] shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}
            >
              Week
            </button>
          </div>

          {/* Layer Toggles */}
          <div className="flex items-center gap-2 mr-4 px-4 border-r border-slate-200">
            <button 
              onClick={() => setLayers({ ...layers, tasks: !layers.tasks })}
              className={`p-2 rounded-xl border transition-all ${layers.tasks ? 'bg-blue-50 border-blue-200 text-blue-600' : 'bg-white border-slate-200 text-slate-300'}`}
              title="Toggle Tasks"
            >
              <Briefcase size={16} />
            </button>
            <button 
              onClick={() => setLayers({ ...layers, permits: !layers.permits })}
              className={`p-2 rounded-xl border transition-all ${layers.permits ? 'bg-rose-50 border-rose-200 text-rose-600' : 'bg-white border-slate-200 text-slate-300'}`}
              title="Toggle Expirations"
            >
              <Zap size={16} />
            </button>
          </div>

          {canSeeAll && (
            <div className="flex items-center bg-white p-1 rounded-2xl border border-slate-200 shadow-sm mr-2">
              <div className="px-3 py-2 text-slate-400">
                <UserIcon size={16} />
              </div>
              <select 
                value={selectedUserName}
                onChange={(e) => setSelectedUserName(e.target.value)}
                className="bg-transparent border-none text-[11px] font-black uppercase tracking-widest text-[#000066] focus:ring-0 outline-none pr-8 cursor-pointer"
              >
                <option value="All">All Personnel</option>
                {users.map(u => (
                  <option key={u.id} value={u.name}>{u.name}</option>
                ))}
              </select>
            </div>
          )}
          
          <div className="flex items-center gap-1.5 mr-2">
            <button onClick={prevMonth} className="p-2.5 bg-white rounded-xl border border-slate-200 hover:bg-slate-50 shadow-sm transition-all"><ChevronLeft size={20} /></button>
            <button onClick={goToToday} className="px-5 py-2.5 bg-white border border-slate-200 rounded-xl text-xs font-black uppercase tracking-widest text-slate-600 hover:bg-slate-50 shadow-sm">Today</button>
            <button onClick={nextMonth} className="p-2.5 bg-white rounded-xl border border-slate-200 hover:bg-slate-50 shadow-sm transition-all"><ChevronRight size={20} /></button>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={exportICal}
              className="px-4 py-2.5 bg-white border border-slate-200 text-[#000066] rounded-xl hover:bg-slate-50 transition-all shadow-sm flex items-center gap-2 text-[10px] font-black uppercase tracking-widest"
              title="Sync with Outlook"
            >
              <Download size={18} />
              <span>Sync with Outlook</span>
            </button>
            <button 
              onClick={handlePrint}
              className="px-6 py-2.5 bg-[#A68F5B] text-white rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-2 shadow-xl shadow-amber-900/10 hover:bg-[#8e7a4d] transition-all"
            >
              <Printer size={18} /> Print Agenda
            </button>
          </div>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="bg-white rounded-[3rem] border border-slate-200 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-500 print:shadow-none print:border-slate-300 print:rounded-none">
        {view === 'month' ? (
          <>
            <div className="grid grid-cols-7 border-b border-slate-100 print:border-slate-300">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="py-4 text-center">
                  <span className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em] print:text-black">{day}</span>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 bg-slate-50/30 print:bg-white">
              {renderMonthView()}
            </div>
          </>
        ) : (
          <div className="flex">
            {renderWeekView()}
          </div>
        )}
      </div>

      {/* Task Detail Modal */}
      <AnimatePresence>
        {selectedTask && (
          <div className="fixed inset-0 z-[400] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white rounded-[3rem] p-10 max-w-lg w-full shadow-[0_30px_100px_-20px_rgba(0,0,51,0.5)] border border-slate-100"
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                  <div className={`p-4 rounded-2xl ${selectedTask.status === 'Completed' ? 'bg-emerald-50 text-emerald-600' : 'bg-blue-50 text-blue-600'}`}>
                    <Briefcase size={28} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight leading-tight">{selectedTask.name}</h3>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mt-1">Task Details</p>
                  </div>
                </div>
                <button onClick={() => setSelectedTask(null)} className="p-3 bg-slate-50 rounded-2xl text-slate-400 hover:text-slate-600 transition-colors">
                  <X size={24} />
                </button>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Status</p>
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${selectedTask.status === 'Completed' ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'}`} />
                      <span className="text-xs font-black text-slate-700 uppercase">{selectedTask.status}</span>
                    </div>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Due Date</p>
                    <div className="flex items-center gap-2 text-slate-700">
                      <Clock size={14} />
                      <span className="text-xs font-black uppercase">{selectedTask.due_date}</span>
                    </div>
                  </div>
                </div>

                <div className="p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-3">Description</p>
                  <p className="text-sm text-slate-600 leading-relaxed font-medium">
                    {selectedTask.description || 'No detailed description provided for this task.'}
                  </p>
                </div>

                <div className="flex items-center justify-between px-2">
                  <div className="flex flex-col">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Assignee</span>
                    <span className="text-xs font-bold text-[#000066]">{selectedTask.assigned_to}</span>
                  </div>
                  <div className="flex flex-col text-right">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Assigned By</span>
                    <span className="text-xs font-bold text-slate-600">{selectedTask.assigned_by}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-10">
                <button 
                  onClick={() => handleToggleTaskStatus(selectedTask)}
                  className={`py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest transition-all shadow-lg ${selectedTask.status === 'Completed' ? 'bg-slate-100 text-slate-600 hover:bg-slate-200' : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-900/20'}`}
                >
                  {selectedTask.status === 'Completed' ? 'Mark as Pending' : 'Mark as Complete'}
                </button>
                <Link 
                  to={selectedTask.project_id ? `/project/${selectedTask.project_id}` : '#'}
                  onClick={() => setSelectedTask(null)}
                  className="py-4 rounded-2xl bg-[#000066] text-white font-black uppercase text-[10px] tracking-widest hover:bg-blue-800 shadow-lg shadow-blue-900/20 transition-all flex items-center justify-center gap-2"
                >
                  Go to Project <ExternalLink size={14} />
                </Link>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Quick Add Modal */}
      <AnimatePresence>
        {showQuickAdd && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-[2.5rem] p-8 max-w-md w-full shadow-2xl border border-slate-100"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
                    <Plus size={20} />
                  </div>
                  <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Quick Task</h3>
                </div>
                <button onClick={() => setShowQuickAdd(null)} className="p-2 text-slate-300 hover:text-slate-600 transition-colors">
                  <X size={20} />
                </button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 block">Task Name</label>
                  <input 
                    autoFocus
                    type="text" 
                    value={quickTaskName}
                    onChange={(e) => setQuickTaskName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleQuickAdd()}
                    placeholder="What needs to be done?"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  />
                </div>
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Due Date</span>
                    <span className="text-[11px] font-black text-[#000066] uppercase">{showQuickAdd.date}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Assignee</span>
                    <span className="text-[11px] font-black text-[#000066] uppercase">{selectedUserName}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mt-8">
                <button 
                  onClick={() => setShowQuickAdd(null)}
                  className="py-4 rounded-2xl border-2 border-slate-100 text-slate-500 font-black uppercase text-[10px] tracking-widest hover:bg-slate-50 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleQuickAdd}
                  disabled={!quickTaskName.trim()}
                  className="py-4 rounded-2xl bg-[#000066] text-white font-black uppercase text-[10px] tracking-widest hover:bg-blue-800 shadow-lg shadow-blue-900/20 transition-all disabled:opacity-50"
                >
                  Create Task
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="flex flex-wrap items-center gap-6 px-4 print:hidden">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-blue-50 border border-blue-200" />
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Tasks</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-rose-50 border border-rose-200" />
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Permit Expirations</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-rose-500" />
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">High Priority</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-slate-50 border border-slate-100" />
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Completed Tasks</span>
        </div>
        <p className="text-[10px] font-bold text-slate-300 uppercase italic ml-auto">Click any date to quick-add a task &bull; Hover for details</p>
      </div>

      <style>{`
        @media print {
          header, aside, .print\\:hidden {
            display: none !important;
          }
          main {
            padding: 0 !important;
            margin: 0 !important;
          }
          body {
            background: white !important;
            color: black !important;
          }
          .h-32 {
            height: auto !important;
            min-height: 100px !important;
          }
        }
      `}</style>
    </div>
  );
};

export default MyCalendar;
