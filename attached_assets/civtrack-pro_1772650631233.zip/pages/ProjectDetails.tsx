
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useParams, Link, useNavigate, useLocation, Navigate } from 'react-router-dom';
import { 
  FileText, CheckSquare, MessageSquare, Info, User as UserIcon, 
  Plus, Trash2, Pencil, Briefcase,
  ArrowLeft, X, CheckCircle2, Share2, Check, Eye, Target, Send, Trophy, Flag, ChevronDown,
  Calendar, UserCheck, Mail, Phone, Users, MapPin, ExternalLink, Folder, AlertTriangle, Landmark
} from 'lucide-react';
import { Project, Permit, Task, Note, ProjectStatus, User, AuditLog } from '../types';
import { StatusBadge } from './Dashboard';
import { parseDateSafe, formatDate } from '../src/utils/dateUtils';
import { PERMIT_TYPES, NOTE_TYPES, AGENCIES, APPLICATION_STATUSES, TASK_NAMES, TASK_STATUS_OPTIONS } from '../constants';
import SearchableSelect from '../SearchableSelect';
import { TaskModal } from '../src/components/TaskModal';

interface ProjectDetailsProps {
  projects: Project[];
  permits: Permit[];
  tasks: Task[];
  notes: Note[];
  users: User[];
  auditLogs: AuditLog[];
  onUpdatePermits: (permits: Permit[]) => void;
  onUpdateTasks: (tasks: Task[]) => void;
  onUpdateNotes: (notes: Note[]) => void;
  onUpdateProjects: (projects: Project[]) => void;
  onDeleteProject?: (id: string) => void;
  currentUser: User;
}

type TabType = 'overview' | 'permits' | 'tasks' | 'notes';

/**
 * Helper to ensure dates are in YYYY-MM-DD format for native date inputs
 */
const formatForInput = (dateStr: string | undefined): string => {
  if (!dateStr) return '';
  const d = parseDateSafe(dateStr);
  if (!d) return '';
  return d.toISOString().split('T')[0];
};

const InlineProjectStatusDropdown: React.FC<{ 
  project: Project, 
  onUpdate: (newStatus: ProjectStatus) => void 
}> = ({ project, onUpdate }) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) setIsOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative inline-block" ref={containerRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="focus:outline-none"
      >
        <StatusBadge status={project.status} />
      </button>

      {isOpen && (
        <div className="absolute left-0 mt-1 w-48 bg-white rounded-xl shadow-2xl border border-slate-100 py-1 z-[100] animate-in zoom-in-95">
          {Object.values(ProjectStatus).map(s => (
            <button
              key={s}
              onClick={() => { onUpdate(s); setIsOpen(false); }}
              className={`w-full text-left px-3 py-2 text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 transition-colors ${s === project.status ? 'text-[#000066]' : 'text-slate-500'}`}
            >
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

const InlineStatusDropdown: React.FC<{ 
  permit: Permit, 
  onUpdate: (update: Partial<Permit>) => void 
}> = ({ permit, onUpdate }) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) setIsOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentStatus = permit.application_status || "";

  return (
    <div className="relative inline-block" ref={containerRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`px-3 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border shadow-sm flex items-center gap-1.5 transition-all ${
          currentStatus
            ? 'bg-blue-50 text-blue-700 border-blue-200 hover:border-blue-400' 
            : 'bg-slate-50 text-slate-400 border-slate-200 hover:border-slate-300'
        }`}
      >
        {currentStatus || 'SET ACTION'}
        <ChevronDown size={10} className={isOpen ? 'rotate-180' : ''} />
      </button>

      {isOpen && (
        <div className="absolute left-0 mt-2 w-56 bg-white rounded-2xl shadow-2xl border border-slate-100 py-2 z-[110] animate-in zoom-in-95 overflow-hidden">
          <div className="px-3 py-1.5 text-[8px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-50 mb-1">Bottleneck Tracking</div>
          {APPLICATION_STATUSES.map(s => (
            <button
              key={s}
              onClick={() => { onUpdate({ application_status: s }); setIsOpen(false); }}
              className={`w-full text-left px-4 py-2.5 text-[10px] font-black uppercase tracking-widest hover:bg-blue-50 transition-colors ${s === currentStatus ? 'text-[#000066] bg-blue-50/50' : 'text-slate-600'}`}
            >
              {s}
            </button>
          ))}
          <div className="border-t border-slate-50 mt-1 pt-1">
            <button
              onClick={() => { onUpdate({ application_status: '' }); setIsOpen(false); }}
              className="w-full text-left px-4 py-2 text-[9px] font-bold text-slate-400 uppercase tracking-widest hover:bg-rose-50 hover:text-rose-500 transition-colors"
            >
              Clear Status
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const ProjectDetails: React.FC<ProjectDetailsProps> = ({ 
  projects, permits, tasks, notes, users, auditLogs,
  onUpdatePermits, onUpdateTasks, onUpdateNotes, onUpdateProjects, onDeleteProject, currentUser
}) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  
  if (id === '00000000-0000-0000-0000-000000000000') {
    return <Navigate to="/tasks" replace />;
  }

  const project = projects.find(p => p.id === id);
  
  // Tab switching logic based on query parameters (for deep linking from notifications)
  const getTabFromQuery = () => {
    const params = new URLSearchParams(location.search);
    const tabParam = params.get('tab') as TabType;
    if (['overview', 'permits', 'tasks', 'notes'].includes(tabParam)) return tabParam;
    return 'overview';
  };

  const [activeTab, setActiveTab] = useState<TabType>(getTabFromQuery());

  useEffect(() => {
    setActiveTab(getTabFromQuery());
  }, [location.search]);

  const projectPermits = useMemo(() => {
    if (!project) return [];
    return permits.filter(p => {
      const pid = (p.project_id || '').toString().trim();
      return pid === project.id || pid === project.number.trim();
    });
  }, [permits, project]);

  const projectTasks = useMemo(() => {
    if (!project) return [];
    return tasks.filter(t => {
      const pid = (t.project_id || '').toString().trim();
      return pid === project.id || pid === project.number.trim();
    });
  }, [tasks, project]);

  const projectNotes = useMemo(() => {
    if (!project) return [];
    return notes.filter(n => {
      const pid = (n.project_id || '').toString().trim();
      return pid === project.id || pid === project.number.trim();
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [notes, project]);

  const projectLogs = useMemo(() => {
    if (!project) return [];
    return auditLogs.filter(l => l.entity_id === project.id);
  }, [auditLogs, project]);

  if (!project) return <div className="p-10 text-center text-slate-500 font-bold">Project not found.</div>;

  const handleUpdateStatus = (newStatus: ProjectStatus) => {
    onUpdateProjects(projects.map(p => p.id === project.id ? { ...p, status: newStatus } : p));
  };

  const isFullAdmin = ['Application Owner', 'Administrator Full Access'].includes(currentUser.role);
  const isAdmin = isFullAdmin || currentUser.role === 'Administrator';
  const isPM = currentUser.role === 'Project Manager';
  const canManageTasksNotes = isAdmin || isPM;
  const canEditProject = isAdmin || isPM;

  return (
    <div className="w-full animate-in fade-in slide-in-from-bottom-2 duration-500">
      <div className="flex flex-col xl:flex-row xl:items-center justify-between mb-8 gap-4">
        <div className="flex items-center gap-3">
          <Link to="/projects" className="p-1.5 hover:bg-white rounded-lg border border-transparent hover:border-slate-200 text-slate-500 hover:text-[#000066]"><ArrowLeft size={18} /></Link>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-slate-800 tracking-tight">{project.name}</h2>
              {canEditProject ? (
                <InlineProjectStatusDropdown project={project} onUpdate={handleUpdateStatus} />
              ) : (
                <StatusBadge status={project.status} />
              )}
            </div>
            <div className="flex items-center gap-3 mt-1.5">
              <span className="text-lg font-sans font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-lg tracking-tight uppercase shadow-sm">
                {project.number}
              </span>
              <p className="text-slate-500 font-extrabold flex items-center gap-1.5 uppercase text-[9px] tracking-widest">
                <Briefcase size={12} /> {project.agency}
              </p>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {canEditProject && (
            <Link to={`/project/${id}/edit`} className="px-3 py-1.5 bg-[#000066] text-white rounded-lg font-black text-[9px] uppercase tracking-widest hover:bg-blue-800 flex items-center gap-1.5 shadow-md">
              <Pencil size={12} /> Edit Details
            </Link>
          )}
        </div>
      </div>

      <div className="flex items-center border-b border-slate-200 mb-6 overflow-x-auto no-scrollbar">
        <TabButton active={activeTab === 'overview'} onClick={() => setActiveTab('overview')} icon={<Info size={14} />} label="Overview" />
        <TabButton active={activeTab === 'permits'} onClick={() => setActiveTab('permits')} icon={<FileText size={14} />} label="Permit Matrix" count={projectPermits.length} />
        <TabButton active={activeTab === 'tasks'} onClick={() => setActiveTab('tasks')} icon={<CheckSquare size={14} />} label="Task Ledger" count={projectTasks.filter(t => t.status !== 'Completed').length} />
        <TabButton active={activeTab === 'notes'} onClick={() => setActiveTab('notes')} icon={<MessageSquare size={14} />} label="Notes" count={projectNotes.length} />
      </div>

      <div>
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-3 space-y-6">
              <OverviewTab project={project} isAdmin={canEditProject} users={users} />
              <ClientInfoSection project={project} isAdmin={canEditProject} />
              <SubConsultantSection project={project} isAdmin={canEditProject} />
            </div>
          </div>
        )}
        {activeTab === 'permits' && <PermitsTab project={project} permits={projectPermits} onUpdate={(newPermits) => onUpdatePermits([...permits.filter(p => p.project_id !== project.id && p.project_id !== project.number), ...newPermits])} isAdmin={isAdmin} />}
        {activeTab === 'tasks' && <TasksTab project={project} tasks={projectTasks} users={users} onUpdate={(newTasks) => onUpdateTasks([...tasks.filter(t => t.project_id !== project.id && t.project_id !== project.number), ...newTasks])} canManage={canManageTasksNotes} currentUser={currentUser} />}
        {activeTab === 'notes' && <NotesTab project={project} notes={projectNotes} users={users} onUpdate={(newNotes) => onUpdateNotes([...notes.filter(n => n.project_id !== project.id && n.project_id !== project.number), ...newNotes])} canManage={canManageTasksNotes} />}
      </div>
    </div>
  );
};

const TabButton: React.FC<{ active: boolean, onClick: () => void, icon: React.ReactNode, label: string, count?: number }> = ({ active, onClick, icon, label, count }) => (
  <button onClick={onClick} className={`flex items-center gap-1.5 px-4 py-3 border-b-2 transition-all font-extrabold text-xs whitespace-nowrap ${active ? 'border-[#A68F5B] text-[#A68F5B]' : 'border-transparent text-slate-500 hover:text-slate-800'}`}>
    {icon} {label} {count !== undefined && <span className={`ml-1 px-1 py-0.5 rounded text-[8px] ${active ? 'bg-amber-50 text-[#A68F5B]' : 'bg-slate-100 text-slate-500'}`}>{count}</span>}
  </button>
);

const OverviewTab: React.FC<{ project: Project, isAdmin: boolean, users: User[] }> = ({ project, isAdmin, users }) => {
  const isLeeCounty = project.agency === 'Lee County';
  const mapUrl = project.map_link || (isLeeCounty 
    ? 'https://gisexplorer.leegov.com/' 
    : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(project.address)}`);

  const manager = users.find(u => u.id === project.project_manager_id) || 
                  users.find(u => u.name === project.project_manager_id) ||
                  users.find(u => u.name === project.project_manager_name);

  return (
    <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm space-y-8">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight flex items-center gap-2"><Info size={16} className="text-[#A68F5B]" /> Project Overview</h3>
        {isAdmin && <Link to={`/project/${project.id}/edit`} className="text-[9px] font-black text-blue-600 uppercase tracking-widest hover:underline flex items-center gap-1"><Pencil size={10} /> Edit Base Data</Link>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <h4 className="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-2 px-1">Project Manager</h4>
              <div className="flex items-center gap-3 p-4 bg-blue-50/50 rounded-2xl border border-blue-100">
                <div className="w-10 h-10 rounded-xl bg-white shadow-sm flex items-center justify-center text-xs font-black text-[#000066] border border-blue-100">
                  {(manager?.name || 'U').split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <p className="text-xs font-black text-slate-800">{manager?.name || 'Unassigned'}</p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Lead Consultant</p>
                </div>
              </div>
            </div>
            <div>
              <h4 className="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-2 px-1">Agency Reference</h4>
              <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="p-2 bg-white rounded-xl shadow-sm text-slate-400">
                  <Landmark size={20} />
                </div>
                <div>
                  <p className="text-xs font-black text-slate-800">{project.agency || 'N/A'}</p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Jurisdiction</p>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-2 px-1">Location & Strap Reference</h4>
            <a 
              href={mapUrl} 
              target="_blank" 
              rel="noreferrer" 
              className="group flex items-start gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:border-[#000066] transition-all"
            >
              <div className="p-2 bg-white rounded-xl shadow-sm text-[#000066] group-hover:bg-[#000066] group-hover:text-white transition-colors">
                <MapPin size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-extrabold text-xs text-slate-800 leading-relaxed truncate">
                  {project.address || 'N/A'}
                </p>
                <p className="text-[10px] font-mono font-bold text-[#A68F5B] mt-1 uppercase">
                  Strap: {project.strap_number || 'N/A'}
                </p>
                <span className="text-[8px] font-black uppercase text-slate-400 group-hover:text-[#000066] flex items-center gap-1 mt-2 transition-colors">
                  {project.map_link ? 'GIS Link' : `View on ${isLeeCounty ? 'LeeGIS' : 'Map'}`} <ExternalLink size={8} />
                </span>
              </div>
            </a>
          </div>

          <div>
             <h4 className="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-2 px-1">OneDrive Repository</h4>
             {project.one_drive_folder ? (
               <a href={project.one_drive_folder} target="_blank" rel="noreferrer" className="flex items-center gap-3 p-4 bg-blue-50/30 rounded-2xl border border-blue-100 hover:bg-blue-50 transition-colors group">
                 <div className="p-2 bg-white rounded-xl shadow-sm text-blue-600"><Folder size={20} /></div>
                 <div className="min-w-0 flex-1">
                   <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Master Folder</p>
                   <p className="text-xs font-bold text-slate-600 truncate group-hover:underline">Open OneDrive Assets</p>
                 </div>
                 <ExternalLink size={14} className="text-blue-300" />
               </a>
             ) : (
               <div className="p-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-center">
                 <p className="text-[10px] font-bold text-slate-400 italic">No OneDrive Link Configured</p>
               </div>
             )}
          </div>
        </div>

        <div>
          <h4 className="text-[8px] font-black uppercase tracking-widest text-slate-400 mb-2 px-1">Project Description</h4>
          <div className="p-5 bg-white border border-slate-100 rounded-2xl shadow-inner min-h-[140px]">
            <p className="text-slate-600 text-xs font-medium leading-relaxed italic">
              {project.description || 'No detailed description has been provided for this project record.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const ClientInfoSection: React.FC<{ project: Project, isAdmin: boolean }> = ({ project, isAdmin }) => (
  <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm">
    <div className="flex items-center justify-between mb-6">
      <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight flex items-center gap-2"><UserIcon size={16} className="text-blue-600" /> Client Information</h3>
      {isAdmin && <Link to={`/project/${project.id}/edit`} className="text-[9px] font-black text-blue-600 uppercase tracking-widest hover:underline">Update Contacts</Link>}
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="space-y-4">
        <div>
          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Client Name</p>
          <p className="text-sm font-black text-slate-800">{project.client_name || 'N/A'}</p>
        </div>
        <div>
          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Email Address</p>
          {project.client_email ? <a href={`mailto:${project.client_email}`} className="text-xs font-bold text-blue-600 flex items-center gap-2 hover:underline"><Mail size={14} /> {project.client_email}</a> : <p className="text-xs text-slate-300 italic">None Provided</p>}
        </div>
      </div>
      <div className="space-y-4">
        <div>
          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Mobile Phone</p>
          <p className="text-xs font-bold text-slate-700 flex items-center gap-2"><Phone size={14} className="text-slate-300" /> {project.client_mobile || 'N/A'}</p>
        </div>
        <div>
          <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Office Phone</p>
          <p className="text-xs font-bold text-slate-700 flex items-center gap-2"><Briefcase size={14} className="text-slate-300" /> {project.client_office || 'N/A'}</p>
        </div>
      </div>
    </div>
  </div>
);

const SubConsultantSection: React.FC<{ project: Project, isAdmin: boolean }> = ({ project, isAdmin }) => {
  const consultants = [
    { label: 'Architect', value: project.architect },
    { label: 'Biologist', value: project.biologist },
    { label: 'Landscaper', value: project.landscaper },
    { label: 'Surveyor', value: project.surveyor },
    { label: 'Traffic Engineer', value: project.traffic_engineer },
  ];

  return (
    <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-sm font-black text-slate-800 uppercase tracking-tight flex items-center gap-2"><Users size={16} className="text-indigo-600" /> Sub-Consultant Team</h3>
        {isAdmin && <Link to={`/project/${project.id}/edit`} className="text-[9px] font-black text-blue-600 uppercase tracking-widest hover:underline">Manage Team</Link>}
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
        {consultants.map(c => (
          <div key={c.label} className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
            <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">{c.label}</p>
            <p className="text-[11px] font-black text-slate-800 truncate">{c.value || '—'}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const PermitsTab: React.FC<{ project: Project, permits: Permit[], onUpdate: (p: Permit[]) => void, isAdmin: boolean }> = ({ project, permits, onUpdate, isAdmin }) => {
  const [showForm, setShowForm] = useState(false);
  const [editingPermitId, setEditingPermitId] = useState<string | null>(null);
  const [permitToDelete, setPermitToDelete] = useState<Permit | null>(null);
  const [formState, setFormState] = useState<Partial<Permit>>({ type: PERMIT_TYPES[0], application_status: '' });

  const handleOpenForm = (permit?: Permit) => {
    if (permit) { setEditingPermitId(permit.id); setFormState(permit); }
    else { setEditingPermitId(null); setFormState({ type: PERMIT_TYPES[0], application_status: '' }); }
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingPermitId) { onUpdate(permits.map(p => p.id === editingPermitId ? { ...p, ...formState } as Permit : p)); }
    else { const newPermit: Permit = { ...formState, id: crypto.randomUUID(), project_id: project.id, type: formState.type || PERMIT_TYPES[0], application_status: formState.application_status || '', number: formState.number || '', } as Permit; onUpdate([...permits, newPermit]); }
    setShowForm(false);
  };

  const handleFieldChange = (name: string, value: string) => setFormState(prev => ({ ...prev, [name]: value }));

  const formatDateShort = (dateStr: string) => { 
    if (!dateStr) return '-'; 
    const d = parseDateSafe(dateStr);
    if (!d) return dateStr;
    return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
  };

  const confirmDeletePermit = () => {
    if (!permitToDelete) return;
    onUpdate(permits.filter(p => p.id !== permitToDelete.id));
    setPermitToDelete(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-sm font-black text-slate-800 uppercase tracking-tighter">Agency Permit Matrix</h3>
        {isAdmin && (
          <button onClick={() => handleOpenForm()} className="bg-[#1d4ed8] text-white px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 shadow-md hover:bg-blue-800 transition-all">
            <Plus size={14} /> New Permit
          </button>
        )}
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-[1.5rem] border-2 border-blue-50 shadow-xl animate-in slide-in-from-top-2">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-xs font-black text-[#000066] uppercase">{editingPermitId ? 'Edit Permit Details' : 'New Permit Entry'}</h4>
              <button type="button" onClick={() => setShowForm(false)} className="text-slate-400 hover:text-rose-500 transition-colors"><X size={16} /></button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              <SearchableSelect label="Type" options={PERMIT_TYPES} value={formState.type || ''} onChange={(val) => handleFieldChange('type', val)} required />
              <div className="space-y-1"><label className="block text-[8px] font-black text-slate-400 uppercase tracking-widest">Permit #</label><input value={formState.number || ''} onChange={(e) => handleFieldChange('number', e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-bold focus:ring-2 focus:ring-blue-100 outline-none" placeholder="Reference #" /></div>
              <div className="space-y-1"><label className="block text-[8px] font-black text-slate-400 uppercase tracking-widest">Current Bottleneck</label><select value={formState.application_status || ''} onChange={(e) => handleFieldChange('application_status', e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-bold focus:ring-2 focus:ring-blue-100 outline-none"><option value="">— NO ACTION SELECTED —</option>{APPLICATION_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}</select></div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
              <DateInput label="Target" value={formState.target_date} onChange={(e) => handleFieldChange('target_date', e.target.value)} />
              <DateInput label="Submittal" value={formState.submittal_date} onChange={(e) => handleFieldChange('submittal_date', e.target.value)} />
              <DateInput label="Comments 1" value={formState.comments_1_date} onChange={(e) => handleFieldChange('comments_1_date', e.target.value)} />
              <DateInput label="Resubmit 1" value={formState.resubmittal_1_date} onChange={(e) => handleFieldChange('resubmittal_1_date', e.target.value)} />
              <DateInput label="Comments 2" value={formState.comments_2_date} onChange={(e) => handleFieldChange('comments_2_date', e.target.value)} />
              <DateInput label="Resubmit 2" value={formState.resubmittal_2_date} onChange={(e) => handleFieldChange('resubmittal_2_date', e.target.value)} />
              <DateInput label="Approval" value={formState.approval_date} onChange={(e) => handleFieldChange('approval_date', e.target.value)} />
              <DateInput label="Expiration" value={formState.expiration_date} onChange={(e) => handleFieldChange('expiration_date', e.target.value)} />
            </div>
            <button type="submit" className="w-full bg-[#000066] text-white py-2 rounded-lg font-black uppercase text-[9px] tracking-widest hover:bg-blue-800 shadow-md">{editingPermitId ? 'Save Changes' : 'Add to Matrix'}</button>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-slate-200">
        <div className="overflow-x-auto">
          <table className="w-full text-left table-auto">
            <thead className="bg-white text-slate-500 text-[10px] font-bold uppercase tracking-wider border-b border-slate-200">
              <tr>
                <th className="px-2 py-3 w-[180px]">Permit Type</th>
                <th className="px-2 py-3 w-[140px]">Permit #</th>
                <th className="px-2 py-3">Target</th>
                <th className="px-2 py-3">Submittal</th>
                <th className="px-2 py-3">Comments 1</th>
                <th className="px-2 py-3">Resub 1</th>
                <th className="px-2 py-3">Comments 2</th>
                <th className="px-2 py-3">Resub 2</th>
                <th className="px-2 py-3">Approval</th>
                <th className="px-2 py-3">Expiration</th>
                {isAdmin && <th className="px-2 py-3 text-right">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y-0">
              {permits.map((permit, index) => (
                <tr key={permit.id} className={`${index % 2 === 0 ? 'bg-slate-50/50' : 'bg-white'} hover:bg-blue-50/30 transition-colors group`}>
                  <td className="px-2 py-3">
                    <div className="flex flex-col gap-1">
                      <span className="font-bold text-slate-800 text-xs leading-tight">{permit.type}</span>
                      <div className="w-fit">
                        <InlineStatusDropdown permit={permit} onUpdate={(u) => onUpdate(permits.map(p => p.id === permit.id ? {...p, ...u} : p))} />
                      </div>
                    </div>
                  </td>
                  <td className="px-2 py-3">
                    <span className="text-slate-600 text-xs font-medium break-all">
                      {permit.number || ''}
                    </span>
                  </td>
                  <td className="px-2 py-3 text-xs text-slate-800 whitespace-nowrap">{formatDateShort(permit.target_date) !== '-' ? formatDateShort(permit.target_date) : ''}</td>
                  <td className="px-2 py-3 text-xs text-slate-800 whitespace-nowrap">{formatDateShort(permit.submittal_date) !== '-' ? formatDateShort(permit.submittal_date) : ''}</td>
                  <td className="px-2 py-3 text-xs text-slate-800 whitespace-nowrap">{formatDateShort(permit.comments_1_date) !== '-' ? formatDateShort(permit.comments_1_date) : ''}</td>
                  <td className="px-2 py-3 text-xs text-slate-800 whitespace-nowrap">{formatDateShort(permit.resubmittal_1_date) !== '-' ? formatDateShort(permit.resubmittal_1_date) : ''}</td>
                  <td className="px-2 py-3 text-xs text-slate-800 whitespace-nowrap">{formatDateShort(permit.comments_2_date) !== '-' ? formatDateShort(permit.comments_2_date) : ''}</td>
                  <td className="px-2 py-3 text-xs text-slate-800 whitespace-nowrap">{formatDateShort(permit.resubmittal_2_date) !== '-' ? formatDateShort(permit.resubmittal_2_date) : ''}</td>
                  <td className="px-2 py-3 text-xs text-slate-800 whitespace-nowrap">{formatDateShort(permit.approval_date) !== '-' ? formatDateShort(permit.approval_date) : ''}</td>
                  <td className="px-2 py-3 text-xs text-slate-800 whitespace-nowrap">{formatDateShort(permit.expiration_date) !== '-' ? formatDateShort(permit.expiration_date) : ''}</td>
                  {isAdmin && (
                    <td className="px-2 py-3 text-right">
                      <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => handleOpenForm(permit)} className="p-1.5 text-slate-400 hover:text-[#000066] rounded transition-all" title="Edit Permit">
                          <Pencil size={14} />
                        </button>
                        <button onClick={() => setPermitToDelete(permit)} className="p-1.5 text-slate-400 hover:text-rose-600 rounded transition-all">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
              {permits.length === 0 && (
                <tr>
                  <td colSpan={11} className="px-6 py-16 text-center text-slate-400 italic text-sm">
                    No permits identified for this record.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CUSTOM PERMIT DELETE POPUP */}
      {permitToDelete && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white rounded-3xl p-10 max-w-sm w-full shadow-2xl border border-slate-100 transform animate-in zoom-in-95 duration-200">
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-rose-50 rounded-2xl flex items-center justify-center mb-6 text-rose-500 border border-rose-100">
                <AlertTriangle size={32} />
              </div>
              <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight mb-2">Delete Permit?</h3>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-8 leading-relaxed">
                This will permanently remove the permit matrix entry for <span className="text-[#000066]">{permitToDelete.type}</span>.
              </p>
              
              <div className="grid grid-cols-2 gap-4 w-full">
                <button 
                  onClick={() => setPermitToDelete(null)} 
                  className="py-3.5 rounded-xl border border-slate-200 text-slate-500 font-black uppercase text-[10px] tracking-widest hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button 
                  onClick={confirmDeletePermit} 
                  className="py-3.5 rounded-xl bg-rose-600 text-white font-black uppercase text-[10px] tracking-widest hover:bg-rose-700 shadow-lg shadow-rose-900/20"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const DateInput: React.FC<{ label: string, value?: string, onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void }> = ({ label, value, onChange }) => (
  <div className="space-y-0.5">
    <label className="block text-[7px] font-black text-slate-400 uppercase tracking-widest leading-tight">{label}</label>
    <input 
      type="date" 
      value={formatForInput(value)} 
      onChange={onChange} 
      className="w-full bg-slate-50 border border-slate-200 rounded px-1.5 py-1 text-[9px] font-bold outline-none focus:ring-1 focus:ring-blue-100" 
    />
  </div>
);

const TasksTab: React.FC<{ project: Project, tasks: Task[], users: User[], onUpdate: (t: Task[]) => void, canManage: boolean, currentUser: User }> = ({ project, tasks, users, onUpdate, canManage, currentUser }) => {
  const [showForm, setShowForm] = useState(false);
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [formState, setFormState] = useState<Partial<Task>>({
    name: TASK_NAMES[0],
    description: '',
    assigned_by: users[0]?.name || '',
    assigned_to: users[0]?.name || '',
    date_assigned: new Date().toISOString().split('T')[0],
    due_date: new Date().toISOString().split('T')[0],
    is_important: false,
    status: 'Assigned',
    notes: ''
  });

  const handleOpenForm = (task?: Task) => {
    if (task) {
      setEditingTaskId(task.id);
      setFormState(task);
    } else {
      setEditingTaskId(null);
      setFormState({
        name: TASK_NAMES[0],
        description: '',
        assigned_by: users[0]?.name || '',
        assigned_to: users[0]?.name || '',
        date_assigned: new Date().toISOString().split('T')[0],
        due_date: new Date().toISOString().split('T')[0],
        is_important: false,
        status: 'Assigned',
        notes: ''
      });
    }
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingTaskId) {
      onUpdate(tasks.map(t => t.id === editingTaskId ? { ...t, ...formState } as Task : t));
    } else {
      const newTask: Task = {
        id: crypto.randomUUID(),
        project_id: project.id,
        project_name: project.name,
        name: formState.name || TASK_NAMES[0],
        description: formState.description || '',
        assigned_by: formState.assigned_by || users[0]?.name || '',
        assigned_to: formState.assigned_to || users[0]?.name || '',
        date_assigned: formState.date_assigned || new Date().toISOString().split('T')[0],
        due_date: formState.due_date || new Date().toISOString().split('T')[0],
        date_completed: formState.date_completed,
        status: formState.status || 'Assigned',
        is_important: !!formState.is_important,
        notes: formState.notes || ''
      };
      onUpdate([...tasks, newTask]);
    }
    setShowForm(false);
  };

  const activeTasks = tasks.filter(t => t.status !== 'Completed');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-sm font-black text-slate-800 uppercase tracking-tighter">Project Task Ledger</h3>
        {canManage && (
          <button 
            onClick={() => handleOpenForm()}
            className="bg-[#000066] text-white px-4 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 hover:bg-blue-800 transition-all shadow-sm"
          >
            <Plus size={14} /> New Task
          </button>
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4">
          <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between p-5 border-b border-slate-100">
              <h4 className="text-sm font-black text-slate-800 uppercase tracking-tight">{editingTaskId ? 'Edit Task Details' : 'Initialize New Task'}</h4>
              <button onClick={() => setShowForm(false)} className="text-slate-400 hover:text-rose-500 transition-colors"><X size={20} /></button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto no-scrollbar">
              <div className="space-y-1">
                <FormLabel label="Task Name" required />
                <select 
                  value={formState.name}
                  onChange={(e) => setFormState({...formState, name: e.target.value})}
                  className="task-input"
                >
                  {TASK_NAMES.map(tn => <option key={tn} value={tn}>{tn}</option>)}
                </select>
              </div>

              <div className="space-y-1">
                <FormLabel label="Task Description" required />
                <textarea 
                  value={formState.description}
                  onChange={(e) => setFormState({...formState, description: e.target.value})}
                  rows={2}
                  className="task-input"
                  placeholder="Task specific details..."
                  required
                />
              </div>

              <div className="flex items-center gap-2 px-1">
                <label className="flex items-center gap-2 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    checked={formState.is_important}
                    onChange={(e) => setFormState({...formState, is_important: e.target.checked})}
                    className="w-4 h-4 rounded border-slate-300 text-rose-600 focus:ring-rose-500"
                  />
                  <span className="text-[10px] font-black uppercase text-slate-500 group-hover:text-rose-600 transition-colors flex items-center gap-1.5">
                    Mark as Important <Flag size={12} className={formState.is_important ? 'text-rose-500 fill-rose-500' : 'text-slate-300'} />
                  </span>
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-50">
                <div className="space-y-1">
                  <FormLabel label="Assigned By" required />
                  <select 
                    value={formState.assigned_by}
                    onChange={(e) => setFormState({...formState, assigned_by: e.target.value})}
                    className="task-input"
                  >
                    {users.map(u => <option key={u.id} value={u.name}>{u.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <FormLabel label="Date Assigned" required />
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={14} />
                    <input 
                      type="date"
                      value={formatForInput(formState.date_assigned)}
                      onChange={(e) => setFormState({...formState, date_assigned: e.target.value})}
                      className="task-input pl-9"
                      required
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <FormLabel label="Assigned To" required />
                  <select 
                    value={formState.assigned_to}
                    onChange={(e) => setFormState({...formState, assigned_to: e.target.value})}
                    className="task-input"
                  >
                    {users.map(u => <option key={u.id} value={u.name}>{u.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <FormLabel label="Date Due" required />
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={14} />
                    <input 
                      type="date"
                      value={formatForInput(formState.due_date)}
                      onChange={(e) => setFormState({...formState, due_date: e.target.value})}
                      className="task-input pl-9"
                      required
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-50">
                <div className="space-y-1">
                  <FormLabel label="Task Status" required />
                  <select 
                    value={formState.status}
                    onChange={(e) => setFormState({...formState, status: e.target.value})}
                    className="task-input"
                  >
                    {TASK_STATUS_OPTIONS.map(ts => <option key={ts} value={ts}>{ts}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <FormLabel label="Date Completed" />
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={14} />
                    <input 
                      type="date"
                      value={formatForInput(formState.date_completed)}
                      onChange={(e) => setFormState({...formState, date_completed: e.target.value})}
                      className="task-input pl-9"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1 pt-2 border-t border-slate-50">
                <FormLabel label="Notes" />
                <textarea 
                  value={formState.notes}
                  onChange={(e) => setFormState({...formState, notes: e.target.value})}
                  rows={2}
                  className="task-input"
                  placeholder="Additional task notes..."
                />
              </div>

              <div className="flex items-center gap-3 pt-6">
                <button type="submit" className="flex-1 py-3 bg-[#000066] text-white rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-blue-800 shadow-lg transition-all">
                  Submit
                </button>
                <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-3 bg-white border border-slate-200 text-slate-600 rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-slate-50 transition-all">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {tasks.length > 0 ? tasks.map(task => (
          <div key={task.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-5 hover:shadow-md transition-all group">
            <button 
              onClick={() => onUpdate(tasks.map(t => t.id === task.id ? { ...t, status: t.status === 'Completed' ? 'Pending' : 'Completed' } : t))}
              className={`w-10 h-10 rounded-xl border-2 flex items-center justify-center transition-all ${
                task.status === 'Completed' 
                  ? 'bg-emerald-50 border-emerald-500 text-emerald-600' 
                  : 'bg-slate-50 border-slate-100 text-slate-200 group-hover:border-blue-200 group-hover:text-blue-300'
              }`}
            >
              <Check size={20} />
            </button>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <h4 className={`text-sm font-black truncate transition-all ${task.status === 'Completed' ? 'text-slate-400 line-through' : 'text-slate-800'}`}>{task.name}</h4>
                {task.is_important && <Flag size={12} className="text-rose-500 fill-rose-500" />}
                <span className={`text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded border ${
                  task.status === 'Completed' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-blue-50 text-blue-600 border-blue-100'
                }`}>
                  {task.status}
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1.5"><UserIcon size={12} className="opacity-50" /> {task.assigned_to}</span>
                <span className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1.5"><Calendar size={12} className="opacity-50" /> {task.due_date}</span>
                {task.description && <span className="text-[10px] font-medium text-slate-400 italic truncate max-w-[200px]">{task.description}</span>}
              </div>
            </div>
            {canManage && (
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => handleOpenForm(task)} className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"><Pencil size={16} /></button>
                <button onClick={() => { if(confirm('Delete task?')) onUpdate(tasks.filter(t => t.id !== task.id)) }} className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all"><Trash2 size={16} /></button>
              </div>
            )}
          </div>
        )) : (
          <div className="py-16 text-center border-2 border-dashed border-slate-200 rounded-[3rem] bg-slate-50/20">
            <CheckSquare size={48} className="mx-auto mb-4 text-slate-200 opacity-20" />
            <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">No Active Tasks</h4>
          </div>
        )}
      </div>

      <style>{`
        .task-input {
          width: 100%;
          background-color: #f8fafc;
          border: 1px solid #e2e8f0;
          border-radius: 0.75rem;
          padding: 0.625rem 0.875rem;
          font-size: 0.875rem;
          font-weight: 600;
          color: #1e293b;
          transition: all 0.2s;
          outline: none;
        }
        .task-input:focus {
          background-color: #fff;
          border-color: #000066;
          box-shadow: 0 0 0 4px rgba(0, 0, 102, 0.05);
        }
        .task-input::placeholder {
          color: #cbd5e1;
          font-weight: 500;
        }
      `}</style>
    </div>
  );
};

const FormLabel: React.FC<{ label: string, required?: boolean }> = ({ label, required }) => (
  <label className="flex items-center justify-between text-[10px] font-black uppercase tracking-[0.05em] text-slate-400 mb-1.5 px-0.5">
    {label}
    {required && <span className="text-[9px] font-bold lowercase text-slate-300 italic">Required</span>}
  </label>
);

const NotesTab: React.FC<{ project: Project, notes: Note[], users: User[], onUpdate: (n: Note[]) => void, canManage: boolean }> = ({ project, notes, users, onUpdate, canManage }) => {
  const [showForm, setShowForm] = useState(false);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [formState, setFormState] = useState<Partial<Note>>({ 
    type: NOTE_TYPES[0], 
    body: '', 
    author: users[0]?.name || '' 
  });

  const handleOpenForm = (note?: Note) => {
    if (note) {
      setEditingNoteId(note.id);
      setFormState(note);
    } else {
      setEditingNoteId(null);
      setFormState({ 
        type: NOTE_TYPES[0], 
        body: '', 
        author: users[0]?.name || '',
        date: new Date().toISOString() 
      });
    }
    setShowForm(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingNoteId) {
      onUpdate(notes.map(n => n.id === editingNoteId ? { ...n, ...formState } as Note : n));
    } else {
      const newNote: Note = {
        id: crypto.randomUUID(),
        project_id: project.id,
        type: formState.type || NOTE_TYPES[0],
        body: formState.body || '',
        author: formState.author || users[0]?.name || '',
        date: new Date().toISOString()
      };
      onUpdate([...notes, newNote]);
    }
    setShowForm(false);
  };

  const handleDelete = (noteId: string) => {
    if (confirm('Delete this note permanently?')) {
      onUpdate(notes.filter(n => n.id !== noteId));
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-sm font-black text-slate-800 uppercase tracking-tighter">Project Activity Log</h3>
        {canManage && (
          <button 
            onClick={() => handleOpenForm()}
            className="bg-[#000066] text-white px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 hover:bg-blue-800 transition-all shadow-md"
          >
            <Plus size={14} /> New Entry
          </button>
        )}
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-[1.5rem] border-2 border-blue-50 shadow-2xl animate-in slide-in-from-top-2">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h4 className="text-xs font-black text-[#000066] uppercase">{editingNoteId ? 'Edit Project Note' : 'New Project Entry'}</h4>
              <button type="button" onClick={() => setShowForm(false)} className="text-slate-400 hover:text-rose-500 transition-colors"><X size={16} /></button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="block text-[8px] font-black text-slate-400 uppercase tracking-widest">Entry Type</label>
                <select 
                  value={formState.type || NOTE_TYPES[0]} 
                  onChange={(e) => setFormState({...formState, type: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-bold focus:ring-2 focus:ring-blue-100 outline-none"
                >
                  {NOTE_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="block text-[8px] font-black text-slate-400 uppercase tracking-widest">Recorded By</label>
                <select 
                  value={formState.author || (users[0]?.name || '')} 
                  onChange={(e) => setFormState({...formState, author: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-xs font-bold focus:ring-2 focus:ring-blue-100 outline-none"
                >
                  {users.map(u => <option key={u.id} value={u.name}>{u.name}</option>)}
                </select>
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-[8px] font-black text-slate-400 uppercase tracking-widest">Entry Body</label>
              <textarea 
                value={formState.body || ''} 
                onChange={(e) => setFormState({...formState, body: e.target.value})}
                rows={4}
                required
                placeholder="Log updates, meeting minutes, or internal comments here..."
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-sm font-semibold focus:ring-2 focus:ring-blue-100 outline-none transition-all"
              />
            </div>

            <button 
              type="submit" 
              className="w-full bg-[#000066] text-white py-2.5 rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-blue-800 shadow-lg transition-all"
            >
              {editingNoteId ? 'Update Entry' : 'Post to Ledger'}
            </button>
          </form>
        </div>
      )}

      <div className="space-y-4">
        {notes.length > 0 ? notes.map(note => (
          <div key={note.id} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm relative group hover:shadow-md transition-all">
            <div className="flex flex-col md:flex-row md:items-start justify-between mb-4 gap-4">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest border shadow-sm ${
                  note.type === 'Internal Review' ? 'bg-indigo-50 text-indigo-700 border-indigo-100' :
                  note.type === 'Client Meeting' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                  'bg-slate-50 text-slate-500 border-slate-100'
                }`}>
                  {note.type}
                </span>
                <span className="flex items-center gap-1.5 px-2.5 py-1 bg-blue-50 text-blue-700 rounded-lg text-[9px] font-black uppercase tracking-widest border border-blue-100">
                  <UserCheck size={12} className="opacity-50" /> {note.author}
                </span>
                <span className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">
                  <Calendar size={12} /> {new Date(note.date).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}
                </span>
              </div>
              
              {canManage && (
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={() => handleOpenForm(note)}
                    className="p-2 text-slate-400 hover:text-[#000066] hover:bg-blue-50 rounded-xl transition-all"
                    title="Edit entry"
                  >
                    <Pencil size={14} />
                  </button>
                  <button 
                    onClick={() => handleDelete(note.id)}
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all"
                    title="Delete entry"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              )}
            </div>
            
            <p className="text-slate-700 leading-relaxed font-semibold text-sm whitespace-pre-wrap">{note.body}</p>
            
            <div className="mt-4 pt-4 border-t border-slate-50 flex justify-end">
              <span className="text-[7px] font-black text-slate-300 uppercase tracking-[0.3em]">CivTrack Pro Ledger Entry &bull; Secure</span>
            </div>
          </div>
        )) : (
          <div className="py-24 text-center border-2 border-dashed border-slate-200 rounded-[3rem] bg-slate-50/20">
            <MessageSquare size={48} className="mx-auto mb-4 text-slate-200" />
            <h4 className="text-sm font-black text-slate-400 uppercase tracking-widest">No entries on file</h4>
            <p className="text-[10px] font-bold text-slate-300 uppercase mt-1">Start tracking project milestones and communications</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectDetails;
