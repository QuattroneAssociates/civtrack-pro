
import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Project, Permit, User } from '../types';
import { parseDateSafe, formatDate } from '../src/utils/dateUtils';
import { CalendarClock, ArrowUpRight, Search, Filter, AlertCircle, Clock, Link as LinkIcon, X, AlertTriangle } from 'lucide-react';
import SearchableSelect from '../SearchableSelect';

interface ExpiringPermitsProps {
  projects: Project[];
  permits: Permit[];
  users: User[];
  searchQuery?: string;
  dismissedAlerts: string[];
  onDismiss: (key: string) => void;
  currentUser: User;
}

const ExpiringPermits: React.FC<ExpiringPermitsProps> = ({ projects, permits, users, searchQuery = '', dismissedAlerts, onDismiss, currentUser }) => {
  const [pmFilter, setPmFilter] = useState<string>('All');
  const [localSearch, setLocalSearch] = useState<string>('');
  const [alertToDelete, setAlertToDelete] = useState<{ id: string; key: string; name: string } | null>(null);

  const today = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
  }, []);

  const expiringList = useMemo(() => {
    const combined = permits.filter(p => p.expiration_date).map(p => {
      const project = projects.find(proj => proj.id === p.project_id || proj.number === p.project_id);
      
      const expDate = parseDateSafe(p.expiration_date);
      let diffDays = 999;
      
      if (expDate) {
        const diffTime = expDate.getTime() - today.getTime();
        diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      }
      
      return { permit: p, project, diffDays, expDate };
    });

    // Only show those expiring within 90 days or already expired, and not dismissed
    return combined.filter(item => {
      const key = `${item.permit.id}-expiration`;
      if (dismissedAlerts.includes(key)) return false;
      return item.diffDays <= 90;
    }).sort((a, b) => a.diffDays - b.diffDays);
  }, [projects, permits, today, dismissedAlerts]);

  const filteredList = useMemo(() => {
    let list = expiringList;

    const q = (localSearch || searchQuery || '').toLowerCase().trim();
    if (q) {
      const words = q.split(/\s+/).filter(Boolean);
      list = list.filter(({ project, permit }) => {
        const manager = users.find(u => u.id === project?.project_manager_id);
        const searchableText = [
          project?.name || '',
          project?.number || '',
          project?.address || '',
          project?.client_name || '',
          project?.strap_number || '',
          permit.type,
          permit.number || '',
          manager?.name || ''
        ].join(' ').toLowerCase();
        
        return words.every(word => searchableText.includes(word));
      });
    }

    if (pmFilter !== 'All') {
      list = list.filter(({ project }) => project?.project_manager_id === pmFilter);
    }

    return list;
  }, [expiringList, pmFilter, localSearch, searchQuery]);

  const pmOptions = useMemo(() => [
    { id: 'All', label: 'All Project Managers' },
    ...users.map(u => ({ id: u.id, label: u.name }))
  ], [users]);

  const formatDate = (dateStr: string) => {
    const d = parseDateSafe(dateStr);
    if (!d) return dateStr || '-';
    return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
  };

  const confirmDismiss = () => {
    if (alertToDelete) {
      onDismiss(alertToDelete.key);
      setAlertToDelete(null);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-rose-50 text-rose-600 rounded-2xl">
            <CalendarClock size={24} />
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">Expiring Permits Report</h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Showing permits expiring within 90 days</p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-4 w-full lg:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input 
              type="text" 
              placeholder="Search project or permit..." 
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/20"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
            />
          </div>
          <div className="w-full sm:w-64">
            <SearchableSelect
              options={pmOptions}
              value={pmFilter}
              onChange={setPmFilter}
              placeholder="Filter by Manager"
            />
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-200 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[10px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-100">
              <tr>
                <th className="px-8 py-5">Project & Manager</th>
                <th className="px-8 py-5">Permit Details</th>
                <th className="px-8 py-5">Expiration Date</th>
                <th className="px-8 py-5">Status</th>
                <th className="px-8 py-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredList.length > 0 ? filteredList.map(({ project, permit, diffDays }) => {
                const manager = users.find(u => u.id === project?.project_manager_id);
                const isExpired = diffDays < 0;
                
                return (
                  <tr key={permit.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-8 py-5">
                      <div className="flex flex-col">
                        {project ? (
                          <>
                            <span className="text-sm font-black text-slate-800 uppercase tracking-tight">
                              {project.name}
                            </span>
                            <span className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1 mt-0.5">
                              PM: {manager?.name || 'Unassigned'}
                            </span>
                            {(project.address || project.strap_number) && (
                              <div className="flex flex-col gap-0.5 mt-1.5">
                                {project.address && (
                                  <span className="text-[9px] font-bold text-slate-400 truncate max-w-[200px] uppercase">
                                    {project.address}
                                  </span>
                                )}
                                {project.strap_number && (
                                  <span className="text-[9px] font-mono font-black text-slate-500 uppercase">
                                    STRAP: {project.strap_number}
                                  </span>
                                )}
                              </div>
                            )}
                          </>
                        ) : (
                          <>
                            <span className="text-sm font-black text-slate-400 italic uppercase">Legacy Reference</span>
                            <span className="text-[10px] font-black text-[#A68F5B] uppercase mt-0.5">Record #{permit.project_id}</span>
                          </>
                        )}
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-slate-700">
                          {permit.type}
                        </span>
                        <span className="inline-block bg-blue-50 text-[#000066] border border-blue-100 px-2 py-0.5 rounded text-[11px] font-black uppercase tracking-tight mt-1 w-fit">
                          #{permit.number || 'TBD'}
                        </span>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <div className={`flex flex-col ${isExpired ? 'text-rose-600' : 'text-slate-800'}`}>
                        <span className="text-sm font-black">{formatDate(permit.expiration_date)}</span>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      {isExpired ? (
                        <div className="flex items-center gap-2 px-3 py-1 bg-rose-50 text-rose-700 rounded-lg w-fit border border-rose-100">
                          <AlertCircle size={14} />
                          <span className="text-[10px] font-black uppercase tracking-widest whitespace-nowrap">
                            Expired {Math.abs(diffDays)}d ago
                          </span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 px-3 py-1 bg-amber-50 text-amber-700 rounded-lg w-fit border border-amber-100 shadow-sm">
                          <Clock size={14} />
                          <span className="text-[10px] font-black uppercase tracking-widest whitespace-nowrap">
                            {diffDays === 0 ? 'Expires Today' : `${diffDays}d remaining`}
                          </span>
                        </div>
                      )}
                    </td>
                    <td className="px-8 py-5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {project && (
                          <Link 
                            to={`/project/${project.id}`} 
                            className="p-3 bg-white border border-slate-200 text-[#000066] hover:border-[#000066] hover:bg-slate-50 rounded-2xl transition-all inline-flex items-center gap-2"
                            title="View Project"
                          >
                            <ArrowUpRight size={18} />
                          </Link>
                        )}
                        {['Application Owner', 'Administrator Full Access'].includes(currentUser.role) && (
                          <button
                            onClick={() => setAlertToDelete({ id: permit.id, name: permit.type, key: `${permit.id}-expiration` })}
                            className="p-3 bg-white border border-slate-200 text-slate-400 hover:border-rose-200 hover:text-rose-600 hover:bg-rose-50 rounded-2xl transition-all inline-flex items-center gap-2"
                            title="Dismiss Alert"
                          >
                            <X size={18} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={5} className="px-8 py-32 text-center">
                    <div className="flex flex-col items-center gap-4 text-slate-300">
                      <CalendarClock size={64} strokeWidth={1} />
                      <div className="space-y-1">
                        <p className="text-sm font-black uppercase tracking-[0.2em]">No expiring permits found</p>
                        <p className="text-xs font-bold text-slate-400 italic">Adjust your search or filters.</p>
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CUSTOM ARE YOU SURE POPUP */}
      {alertToDelete && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-[#000033]/40 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white rounded-[2.5rem] p-10 max-w-sm w-full shadow-[0_25px_80px_-15px_rgba(0,0,51,0.4)] border border-slate-100 transform animate-in zoom-in-95 duration-200">
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-rose-50 rounded-[1.5rem] flex items-center justify-center mb-6 text-rose-500 border-2 border-rose-100 shadow-inner">
                <AlertTriangle size={36} strokeWidth={1.5} />
              </div>
              <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight mb-2">Dismiss Alert?</h3>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-8 leading-relaxed">
                Remove <span className="text-[#000066]">{alertToDelete.name}</span> from the expiring list.
              </p>
              
              <div className="grid grid-cols-2 gap-4 w-full">
                <button 
                  onClick={() => setAlertToDelete(null)} 
                  className="py-4 rounded-2xl border-2 border-slate-100 text-slate-500 font-black uppercase text-[10px] tracking-widest hover:bg-slate-50 hover:border-slate-200 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={confirmDismiss} 
                  className="py-4 rounded-2xl bg-rose-600 text-white font-black uppercase text-[10px] tracking-widest hover:bg-rose-700 shadow-lg shadow-rose-900/20 transition-all"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpiringPermits;
