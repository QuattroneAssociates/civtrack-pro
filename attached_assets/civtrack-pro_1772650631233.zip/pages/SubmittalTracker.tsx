
import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Project, Permit, 
} from '../types';
import { 
  ArrowUpRight, Clock, CheckCircle2, AlertCircle, Target, Briefcase, Plus, Filter, Search, Send
} from 'lucide-react';
import { APPLICATION_STATUSES, SUBMITTAL_TYPES, FEE_STATUSES, AGENCY_DEADLINE_CONFIG } from '../constants';

interface SubmittalTrackerProps {
  projects: Project[];
  permits: Permit[];
  onUpdatePermits: (newPermits: Permit[]) => void;
}

const SubmittalTracker: React.FC<SubmittalTrackerProps> = ({ projects, permits, onUpdatePermits }) => {
  const [searchTerm, setSearchTerm] = useState("");

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  /**
   * Helper to calculate Response Due Date based on centralized Agency Business Rules.
   * Priority: Permit.lastActionDate -> Permit.submittalDate -> Permit.targetDate
   */
  const calculateResponseDue = (permit: Permit, municipality: string) => {
    // If we don't even have a base date, we can't calculate
    const baseDateStr = permit.last_action_date || permit.submittal_date || permit.target_date;
    if (!baseDateStr) return null;

    const date = new Date(baseDateStr);
    const agencyKey = permit.agency || municipality;
    
    // Normalize key for matching config
    let configKey = 'Other';
    if (agencyKey.includes('Fort Myers')) configKey = 'City of Fort Myers';
    else if (agencyKey === 'SFWMD') configKey = 'SFWMD';
    else if (agencyKey === 'FDOT') configKey = 'FDOT';
    else if (agencyKey.includes('Lee')) configKey = 'Lee County';
    else if (agencyKey.includes('Cape Coral')) configKey = 'Cape Coral';
    else if (agencyKey.includes('Bonita')) configKey = 'Bonita Springs';

    const config = AGENCY_DEADLINE_CONFIG[configKey] || AGENCY_DEADLINE_CONFIG['Other'];
    
    let daysToAdd = config.resubmittal; // Default to resubmittal logic

    if (permit.submittal_type === 'Initial Submittal') {
      daysToAdd = config.initial;
    } else if (permit.submittal_type === 'Extension' || permit.submittal_type === 'Extension Requested') {
      daysToAdd = config.extension;
    }
    
    date.setDate(date.getDate() + daysToAdd);
    return date;
  };

  /**
   * Automated Ball In Court Logic
   */
  const getAutomatedBallInCourt = (permit: Permit) => {
    // If fees are posted, ball is automatically CLIENT
    if (permit.fee_status === 'Fees Posted' || permit.application_status === 'Fees Pending') {
      return 'CLIENT';
    }
    if (permit.application_status === 'Submitted') {
      return 'CITY';
    }
    if (permit.application_status === 'Comments Received') {
      return 'QUATTRONE';
    }
    return 'TBD';
  };

  /**
   * Processed Submittals Data
   */
  const submittals = useMemo(() => {
    // Filter: only items NOT Approved or Issued
    const activePermits = permits.filter(p => !['Approved', 'Issued'].includes(p.application_status || ''));
    
    return activePermits.map(p => {
      const proj = projects.find(proj => proj.id === p.project_id);
      const responseDue = calculateResponseDue(p, proj?.agency || 'Other');
      
      let diffDays = null;
      if (responseDue) {
        const diffTime = responseDue.getTime() - today.getTime();
        diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      }

      return {
        ...p,
        project: proj,
        responseDue,
        diffDays,
        ballInCourt: getAutomatedBallInCourt(p)
      };
    })
    .filter(item => {
      if (!searchTerm.trim()) return true;
      const q = searchTerm.toLowerCase();
      return (
        (item.project?.name || '').toLowerCase().includes(q) ||
        (item.type || '').toLowerCase().includes(q) ||
        (item.number || '').toLowerCase().includes(q)
      );
    })
    // Sort by Due Date Ascending
    .sort((a, b) => {
      if (!a.responseDue) return 1;
      if (!b.responseDue) return -1;
      return a.responseDue.getTime() - b.responseDue.getTime();
    });
  }, [permits, projects, searchTerm, today]);

  const handleUpdateField = (permitId: string, field: keyof Permit, value: string) => {
    const updated = permits.map(p => p.id === permitId ? { ...p, [field]: value } : p);
    onUpdatePermits(updated);
  };

  const handleExtension = (permitId: string) => {
    const updated = permits.map(p => {
      if (p.id === permitId) {
        return { 
          ...p, 
          submittalType: 'Extension Requested',
          applicationStatus: 'Extension Requested'
        };
      }
      return p;
    });
    onUpdatePermits(updated);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 px-1">
        <div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tight uppercase">Submittal Tracker</h1>
          <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mt-1">Global Active Permit Application Ledger</p>
        </div>
        <div className="relative w-full lg:w-96">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text"
            placeholder="Search submittals..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-medium focus:ring-2 focus:ring-[#000066]/10 outline-none shadow-sm"
          />
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left table-auto">
            <thead className="bg-slate-50 text-[10px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-100">
              <tr>
                <th className="px-6 py-6 min-w-[300px]">Project & Agency</th>
                <th className="px-6 py-6">Status / Type</th>
                <th className="px-6 py-6 text-center">Last Action</th>
                <th className="px-6 py-6 text-center">Response Due</th>
                <th className="px-6 py-6 text-center">Ball In Court</th>
                <th className="px-6 py-6">Fee Status</th>
                <th className="px-6 py-6">Submittal Notes</th>
                <th className="px-6 py-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {submittals.map(sub => {
                const isCFM = (sub.agency || sub.project?.agency || '').includes('Fort Myers');
                const isWaitingOnCity = sub.feeStatus === 'Waiting on City';
                const priorityColor = sub.diffDays === null ? 'bg-slate-200' :
                  sub.diffDays < 7 ? 'bg-rose-500' :
                  sub.diffDays < 30 ? 'bg-amber-500' : 'bg-emerald-500';

                return (
                  <tr key={sub.id} className={`group hover:bg-blue-50/20 transition-all relative ${sub.fee_status === 'Waiting on City' ? 'bg-emerald-50/40' : ''}`}>
                    {/* Priority Indicator */}
                    <td className="absolute left-0 top-0 bottom-0 w-1.5" style={{ backgroundColor: priorityColor === 'bg-rose-500' ? '#e11d48' : priorityColor === 'bg-amber-500' ? '#f59e0b' : priorityColor === 'bg-emerald-500' ? '#10b981' : '#e2e8f0' }}></td>
                    
                    <td className="px-6 py-6">
                      <div className="flex flex-col gap-1">
                        <Link to={`/project/${sub.project_id}`} className="text-sm font-black text-slate-800 hover:text-[#000066] transition-colors leading-tight">
                          {sub.project?.name}
                        </Link>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-tight">{sub.agency || sub.project?.agency}</span>
                          <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded uppercase">{sub.number || 'TBD'}</span>
                        </div>
                      </div>
                    </td>

                    <td className="px-6 py-6">
                      <div className="flex flex-col gap-2">
                        <select 
                          value={sub.application_status || 'Submitted'} 
                          onChange={(e) => handleUpdateField(sub.id, 'application_status', e.target.value)}
                          className="bg-slate-50 border border-slate-100 rounded-lg px-2 py-1 text-[10px] font-black uppercase tracking-tight focus:ring-1 focus:ring-[#000066] outline-none"
                        >
                          {APPLICATION_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                        <select 
                          value={sub.submittal_type || 'Initial Submittal'} 
                          onChange={(e) => handleUpdateField(sub.id, 'submittal_type', e.target.value)}
                          className="bg-white border border-slate-100 rounded-lg px-2 py-1 text-[10px] font-bold focus:ring-1 focus:ring-[#000066] outline-none"
                        >
                          {SUBMITTAL_TYPES.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                    </td>

                    <td className="px-6 py-6 text-center">
                      <input 
                        type="date"
                        value={sub.last_action_date || ''}
                        onChange={(e) => handleUpdateField(sub.id, 'last_action_date', e.target.value)}
                        className="bg-transparent border-b border-dashed border-slate-200 text-xs font-bold text-slate-600 focus:border-[#000066] outline-none text-center"
                      />
                    </td>

                    <td className="px-6 py-6 text-center">
                      <div className="flex flex-col items-center">
                        <span className={`text-sm font-black ${sub.diffDays !== null && sub.diffDays <= 14 ? 'text-rose-600' : 'text-slate-800'}`}>
                          {sub.responseDue ? sub.responseDue.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '-'}
                        </span>
                        {sub.diffDays !== null && (
                          <span className={`text-[9px] font-black uppercase tracking-widest ${sub.diffDays < 7 ? 'text-rose-500' : 'text-slate-400'}`}>
                            {sub.diffDays < 0 ? 'Overdue' : `${sub.diffDays} Days Left`}
                          </span>
                        )}
                      </div>
                    </td>

                    <td className="px-6 py-6 text-center">
                      <span className={`inline-block px-3 py-1 rounded-xl text-[10px] font-black tracking-[0.2em] shadow-sm ${
                        sub.ballInCourt === 'CITY' ? 'bg-[#000066] text-white' : 
                        sub.ballInCourt === 'QUATTRONE' ? 'bg-[#A68F5B] text-white' : 
                        'bg-amber-100 text-amber-700'
                      }`}>
                        {sub.ballInCourt}
                      </span>
                    </td>

                    <td className="px-6 py-6">
                      <select 
                        value={sub.fee_status || 'N/A'} 
                        onChange={(e) => handleUpdateField(sub.id, 'fee_status', e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 rounded-lg px-2 py-2 text-[10px] font-bold focus:ring-1 focus:ring-[#000066] outline-none"
                      >
                        {FEE_STATUSES.map(f => <option key={f} value={f}>{f}</option>)}
                      </select>
                    </td>

                    <td className="px-6 py-6">
                      <textarea 
                        value={sub.submittal_notes || ''}
                        onChange={(e) => handleUpdateField(sub.id, 'submittal_notes', e.target.value)}
                        placeholder="Add quick note..."
                        rows={1}
                        className="w-full bg-slate-50/50 hover:bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:bg-white focus:border-[#000066] focus:ring-0 outline-none transition-all resize-none min-w-[150px]"
                      />
                    </td>

                    <td className="px-6 py-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {isCFM && sub.diffDays !== null && sub.diffDays <= 10 && sub.application_status !== 'Extension Requested' && (
                          <button 
                            onClick={() => handleExtension(sub.id)}
                            className="p-2 bg-amber-50 text-amber-600 rounded-xl hover:bg-amber-100 transition-all shadow-sm"
                            title="File Extension"
                          >
                            <Send size={16} />
                          </button>
                        )}
                        <Link to={`/project/${sub.project_id}`} className="p-2 bg-slate-50 text-slate-400 hover:text-blue-600 rounded-xl transition-all">
                          <ArrowUpRight size={18} />
                        </Link>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {submittals.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-8 py-32 text-center text-slate-300 italic">No active submittals found matching criteria.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        <div className="bg-slate-50 px-8 py-4 border-t border-slate-100 flex items-center justify-between text-[10px] font-black text-slate-400 uppercase tracking-widest">
          <span>{submittals.length} Active Submittals Monitored</span>
          <div className="flex gap-4">
             <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-rose-500"></div> Critical (&lt;7d)</div>
             <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-amber-500"></div> Urgent (&lt;30d)</div>
             <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500"></div> Standard (&gt;30d)</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubmittalTracker;
