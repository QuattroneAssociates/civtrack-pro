
import React, { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Project, Permit, User } from '../types';
import { parseDateSafe, formatDate } from '../src/utils/dateUtils';
import { Search, ChevronLeft, ChevronRight, CheckCircle2, X, Clock, Zap, Target, AlertTriangle, ExternalLink, Wallet, ClipboardList } from 'lucide-react';

interface AlertsProps {
  projects: Project[];
  permits: Permit[];
  users: User[];
  dismissedAlerts: string[];
  onDismiss: (key: string) => void;
  searchQuery?: string;
  currentUser: User;
}

const Alerts: React.FC<AlertsProps> = ({ projects, permits, users, dismissedAlerts, onDismiss, searchQuery = '', currentUser }) => {
  const [localSearches, setLocalSearches] = useState<Record<string, string>>({});
  const [alertToDelete, setAlertToDelete] = useState<{ id: string; key: string; name: string } | null>(null);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const getDaysDiff = (dateStr: string) => {
    const d = parseDateSafe(dateStr);
    if (!d) return null;
    const diffTime = today.getTime() - d.getTime();
    return Math.floor(diffTime / (1000 * 60 * 60 * 24));
  };

  const isWithinDays = (dateStr: string, days: number) => {
    const d = parseDateSafe(dateStr);
    if (!d) return false;
    const diffTime = d.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays >= 0 && diffDays <= days;
  };

  const isPast = (dateStr: string) => {
    const d = parseDateSafe(dateStr);
    if (!d) return false;
    return d.getTime() < today.getTime();
  };

  const alertsData = useMemo(() => {
    const data = permits.map(p => ({
      permit: p,
      project: projects.find(proj => proj.id === p.project_id || proj.number === p.project_id)
    })).filter(item => item.project);

    return {
      target: data.filter(({ permit }) => {
        const key = `${permit.id}-target`;
        if (dismissedAlerts.includes(key)) return false;
        if (permit.submittal_date || permit.approval_date) return false;
        if (!permit.target_date) return false;
        return isPast(permit.target_date) || isWithinDays(permit.target_date, 7);
      }),
      expiration: data.filter(({ permit }) => {
        const key = `${permit.id}-expiration`;
        if (dismissedAlerts.includes(key)) return false;
        if (!permit.expiration_date) return false;
        return isPast(permit.expiration_date) || isWithinDays(permit.expiration_date, 90);
      }),
      submittalStagnant: data.filter(({ permit }) => {
        const key = `${permit.id}-submittalStagnant`;
        if (dismissedAlerts.includes(key)) return false;
        if (!permit.submittal_date || permit.comments_1_date || permit.approval_date) return false;
        const diff = getDaysDiff(permit.submittal_date);
        return diff !== null && diff >= 30;
      }),
      commentsStagnant: data.filter(({ permit }) => {
        const key = `${permit.id}-commentsStagnant`;
        if (dismissedAlerts.includes(key)) return false;
        const hasComments = permit.comments_1_date || permit.comments_2_date;
        if (!hasComments || permit.approval_date) return false;
        
        const latestCommentDate = permit.comments_2_date || permit.comments_1_date;
        const latestResubmittalDate = permit.resubmittal_2_date || permit.resubmittal_1_date;
        if (latestResubmittalDate) return false;

        const diff = getDaysDiff(latestCommentDate as string);
        return diff !== null && diff >= 30;
      }),
      unpaidFees: data.filter(({ permit }) => {
        const key = `${permit.id}-unpaidFees`;
        if (dismissedAlerts.includes(key)) return false;
        return permit.application_status === 'Fees Posted - Unpaid';
      })
    };
  }, [projects, permits, dismissedAlerts]);

  const handleLocalSearch = (section: string, val: string) => {
    setLocalSearches(prev => ({ ...prev, [section]: val }));
  };

  const filterList = (list: any[], section: string) => {
    const q = (localSearches[section] || searchQuery || '').toLowerCase().trim();
    if (!q) return list;
    const words = q.split(/\s+/).filter(Boolean);
    return list.filter(({ project, permit }) => {
      const manager = users.find(u => u.id === project.project_manager_id) || 
                      users.find(u => u.name === project.project_manager_id) ||
                      users.find(u => u.name === project.project_manager_name);
      const searchableText = [
        project.name,
        project.number,
        project.address || '',
        project.client_name || '',
        project.strap_number || '',
        permit.type,
        permit.number || '',
        manager?.name || ''
      ].join(' ').toLowerCase();
      
      return words.every(word => searchableText.includes(word));
    });
  };

  const confirmDismiss = () => {
    if (alertToDelete) {
      onDismiss(alertToDelete.key);
      setAlertToDelete(null);
    }
  };

  return (
    <div className="max-w-[1500px] mx-auto space-y-12 animate-in fade-in duration-700 pb-20">
      <div className="flex items-center justify-between px-2">
        <div className="space-y-1">
          <h1 className="text-3xl font-black text-slate-800 tracking-tight uppercase">Permit Action Center</h1>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Operational Oversight & Risks</p>
        </div>
        <div className="p-3 bg-rose-50 text-rose-600 rounded-2xl border border-rose-100">
           <AlertTriangle size={24} />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <SummaryCard label="Total Permits" count={permits.length} color="slate" icon={<ClipboardList size={18} />} />
        <SummaryCard label="Pending Fees" count={alertsData.unpaidFees.length} color="indigo" icon={<Wallet size={18} />} />
        <SummaryCard label="Target Submittal" count={alertsData.target.length} color="amber" icon={<Target size={18} />} />
        <SummaryCard label="Agency Expiration" count={alertsData.expiration.length} color="rose" icon={<Zap size={18} />} />
        <SummaryCard label="Stagnant Items" count={alertsData.submittalStagnant.length + alertsData.commentsStagnant.length} color="slate" icon={<Clock size={18} />} />
      </div>

      <div className="space-y-16">
        <AlertTable 
          title="Pending Fee Payments"
          subtitle="Permits marked as 'Fees Posted - Unpaid'."
          data={filterList(alertsData.unpaidFees, 'unpaidFees')}
          onSearch={(v) => handleLocalSearch('unpaidFees', v)}
          searchValue={localSearches['unpaidFees'] || ''}
          onDeleteTrigger={(id, name) => setAlertToDelete({ id, name, key: `${id}-unpaidFees` })}
          dateLabel="Status Date"
          dateField="last_action_date"
          accentColor="#4f46e5"
          searchQuery={searchQuery}
          currentUser={currentUser}
        />

        <AlertTable 
          title="Target Submittals Overdue"
          subtitle="Target date in past or within 7 days (not yet submitted)"
          data={filterList(alertsData.target, 'target')}
          onSearch={(v) => handleLocalSearch('target', v)}
          searchValue={localSearches['target'] || ''}
          onDeleteTrigger={(id, name) => setAlertToDelete({ id, name, key: `${id}-target` })}
          dateLabel="Target Date"
          dateField="target_date"
          accentColor="#A68F5B"
          searchQuery={searchQuery}
          currentUser={currentUser}
        />

        <AlertTable 
          title="Submittal Stagnation"
          subtitle="Submitted with no comments or approval received (30+ days)"
          data={filterList(alertsData.submittalStagnant, 'submittalStagnant')}
          users={users}
          onSearch={(v) => handleLocalSearch('submittalStagnant', v)}
          searchValue={localSearches['submittalStagnant'] || ''}
          onDeleteTrigger={(id, name) => setAlertToDelete({ id, name, key: `${id}-submittalStagnant` })}
          dateLabel="Submitted On"
          dateField="submittal_date"
          accentColor="#64748b"
          searchQuery={searchQuery}
          currentUser={currentUser}
        />

        <AlertTable 
          title="Resubmittal Stagnation"
          subtitle="Comments received with no resubmittal or approval (30+ days)"
          data={filterList(alertsData.commentsStagnant, 'resubStagnant')}
          users={users}
          onSearch={(v) => handleLocalSearch('resubStagnant', v)}
          searchValue={localSearches['resubStagnant'] || ''}
          onDeleteTrigger={(id, name) => setAlertToDelete({ id, name, key: `${id}-commentsStagnant` })}
          dateLabel="Comments On"
          dateField="comments_1_date"
          accentColor="#64748b"
          searchQuery={searchQuery}
          currentUser={currentUser}
        />

        <AlertTable 
          title="Agency Permits Expiring"
          subtitle="Agency permits expiring within the next 90 days"
          data={filterList(alertsData.expiration, 'expiration')}
          users={users}
          onSearch={(v) => handleLocalSearch('expiration', v)}
          searchValue={localSearches['expiration'] || ''}
          onDeleteTrigger={(id, name) => setAlertToDelete({ id, name, key: `${id}-expiration` })}
          dateLabel="Expiration"
          dateField="expiration_date"
          accentColor="#e11d48"
          searchQuery={searchQuery}
          currentUser={currentUser}
        />
      </div>

      {/* CUSTOM ARE YOU SURE POPUP */}
      {alertToDelete && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-[#000033]/40 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white rounded-[2.5rem] p-10 max-w-sm w-full shadow-[0_25px_80px_-15px_rgba(0,0,51,0.4)] border border-slate-100 transform animate-in zoom-in-95 duration-200">
            <div className="flex flex-col items-center text-center">
              <div className="w-20 h-20 bg-rose-50 rounded-[1.5rem] flex items-center justify-center mb-6 text-[#e11d48] border-2 border-rose-100">
                <AlertTriangle size={40} />
              </div>
              <h3 className="text-2xl font-black text-[#000033] uppercase tracking-tight mb-2">Are you sure?</h3>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.25em] mb-8 leading-relaxed">
                You are about to permanently dismiss this operational alert. This cannot be undone.
              </p>
              
              <div className="w-full p-5 bg-slate-50 rounded-2xl border border-slate-200 mb-10">
                <p className="text-[11px] font-black text-[#000066] uppercase truncate leading-tight">{alertToDelete.name}</p>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1.5">Action Alert Item</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4 w-full">
                <button 
                  onClick={() => setAlertToDelete(null)} 
                  className="py-4 rounded-2xl border-2 border-slate-200 text-slate-500 font-black uppercase text-[10px] tracking-widest hover:bg-slate-50 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={confirmDismiss} 
                  className="py-4 rounded-2xl bg-[#e11d48] text-white font-black uppercase text-[10px] tracking-widest hover:bg-rose-700 shadow-lg shadow-rose-900/20 transition-all"
                >
                  Yes, Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const SummaryCard: React.FC<{ label: string, count: number, color: 'amber' | 'rose' | 'indigo' | 'slate', icon: React.ReactNode }> = ({ label, count, color, icon }) => {
  const colors = {
    amber: 'bg-amber-50 text-amber-600 border-amber-100',
    rose: 'bg-rose-50 text-rose-600 border-rose-100',
    indigo: 'bg-indigo-50 text-indigo-600 border-indigo-100',
    slate: 'bg-slate-50 text-slate-600 border-slate-100'
  };
  
  return (
    <div className={`p-6 rounded-[2rem] border transition-all hover:shadow-lg flex items-center justify-between ${colors[color]}`}>
      <div>
        <p className="text-[9px] font-black uppercase tracking-widest opacity-60 mb-1">{label}</p>
        <p className="text-2xl font-black">{count}</p>
      </div>
      <div className="p-3 bg-white/60 rounded-2xl shadow-sm">{icon}</div>
    </div>
  );
};

interface AlertTableProps {
  title: string;
  subtitle?: string;
  data: any[];
  users: User[];
  onSearch: (v: string) => void;
  searchValue: string;
  onDeleteTrigger: (id: string, name: string) => void;
  dateLabel: string;
  dateField: keyof Permit;
  accentColor: string;
  searchQuery: string;
  currentUser: User;
}

const AlertTable: React.FC<AlertTableProps> = ({ 
  title, subtitle, data, users, onSearch, searchValue, onDeleteTrigger, dateLabel, dateField, accentColor, searchQuery, currentUser
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const combinedSearch = searchValue || searchQuery;

  useEffect(() => {
    setCurrentPage(1);
  }, [combinedSearch]);

  const totalPages = Math.ceil(data.length / itemsPerPage);
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return data.slice(start, start + itemsPerPage);
  }, [data, currentPage]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 px-2">
        <div className="space-y-1">
          <div className="flex items-center gap-3">
            <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">{title}</h3>
            <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[9px] font-black uppercase tracking-widest">{data.length} Records</span>
          </div>
          {subtitle && <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none">{subtitle}</p>}
        </div>
        
        <div className="relative group">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-slate-500" size={14} />
          <input 
            type="text" 
            placeholder="Search records..." 
            value={searchValue}
            onChange={(e) => onSearch(e.target.value)}
            className="pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-[#000066]/5 min-w-[240px] shadow-sm transition-all" 
          />
        </div>
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-200 shadow-xl overflow-hidden">
        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left table-auto min-w-[1200px]">
            <thead className="bg-slate-50/80 text-[10px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-100">
              <tr>
                <th className="px-10 py-5 w-[30%]">Project Information</th>
                <th className="px-10 py-5 w-[20%]">Project Manager</th>
                <th className="px-10 py-5 w-[25%]">Permit Details</th>
                <th className="px-10 py-5 text-center w-[15%]">{dateLabel.toUpperCase()}</th>
                <th className="px-10 py-5 text-right pr-14 w-[10%]">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedData.length > 0 ? paginatedData.map((item) => {
                const manager = users.find(u => u.id === item.project.project_manager_id) || 
                                users.find(u => u.name === item.project.project_manager_id) ||
                                users.find(u => u.name === item.project.project_manager_name);
                
                return (
                  <tr key={item.permit.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-10 py-6 border-l-[6px]" style={{ borderLeftColor: accentColor }}>
                      <Link to={`/project/${item.project.id}`} className="block group/link">
                        <p className="text-sm font-black text-[#000066] uppercase tracking-tight truncate max-w-[300px] group-hover/link:underline flex items-center gap-2">
                          {item.project.name}
                          <ExternalLink size={12} className="opacity-0 group-hover/link:opacity-100 transition-opacity" />
                        </p>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Job #{item.project.number}</p>
                        {(item.project.address || item.project.strap_number) && (
                          <div className="flex flex-col gap-0.5 mt-1.5">
                            {item.project.address && (
                              <span className="text-[9px] font-bold text-slate-400 truncate max-w-[250px] uppercase">
                                {item.project.address}
                              </span>
                            )}
                            {item.project.strap_number && (
                              <span className="text-[9px] font-mono font-black text-slate-500 uppercase">
                                STRAP: {item.project.strap_number}
                              </span>
                            )}
                          </div>
                        )}
                      </Link>
                    </td>
                    <td className="px-10 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-[10px] font-black text-slate-400 shrink-0">
                          {(manager?.name || '').split(' ').map(n => n[0]).join('')}
                        </div>
                        <span className="text-[13px] font-bold text-slate-600">{manager?.name || 'Unassigned'}</span>
                      </div>
                    </td>
                    <td className="px-10 py-6">
                      <p className="text-[13px] font-bold text-slate-800 leading-tight">{item.permit.type}</p>
                      <span className="inline-block bg-indigo-50 text-indigo-700 border border-indigo-100 px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest mt-1.5 shadow-sm">
                        #{item.permit.number || 'TBD'}
                      </span>
                    </td>
                    <td className="px-10 py-6 text-center">
                      <span className="text-sm font-black text-slate-800">
                        {formatDate(item.permit[dateField] as string)}
                      </span>
                    </td>
                    <td className="px-10 py-6 text-right pr-14">
                      {['Application Owner', 'Administrator Full Access'].includes(currentUser.role) && (
                        <button 
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            onDeleteTrigger(item.permit.id, item.project.name);
                          }}
                          className="flex items-center justify-center p-2 rounded-lg hover:bg-slate-100 transition-all ml-auto group/btn transform active:scale-95"
                          title="Dismiss Alert"
                        >
                          <X size={20} className="text-slate-400 group-hover:text-rose-500 transition-colors" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={5} className="px-8 py-32 text-center">
                    <div className="flex flex-col items-center gap-4 text-slate-200">
                       <CheckCircle2 size={64} strokeWidth={1} />
                       <div className="space-y-1">
                         <p className="text-sm font-black uppercase tracking-[0.2em]">Record Clean</p>
                         <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest italic">No pending items in this category</p>
                       </div>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {data.length > itemsPerPage && (
          <div className="bg-slate-50 px-8 py-5 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
              View {Math.min(data.length, (currentPage - 1) * itemsPerPage + 1)}-{Math.min(data.length, currentPage * itemsPerPage)} of {data.length}
            </p>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                disabled={currentPage === 1}
                className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-[#000066] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
              >
                <ChevronLeft size={16} />
              </button>
              <div className="flex items-center gap-1">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                  <button
                    key={page}
                    onClick={() => setCurrentPage(page)}
                    className={`w-9 h-9 rounded-xl text-[10px] font-black transition-all ${
                      currentPage === page 
                        ? 'bg-[#000066] text-white shadow-lg' 
                        : 'bg-white border border-slate-100 text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    {page}
                  </button>
                )).slice(Math.max(0, currentPage - 3), Math.min(totalPages, currentPage + 2))}
              </div>
              <button 
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                disabled={currentPage === totalPages}
                className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-[#000066] disabled:opacity-30 disabled:cursor-not-allowed transition-all"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Alerts;
