
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Save, Info, User as UserIcon, Link as LinkIcon, Users, Target, Phone, Mail, Building, Landmark, MapPin, ArrowLeft } from 'lucide-react';
import { Project, ProjectStatus, TitlePolicyStatus, User } from '../types';
import { AGENCIES, SUB_CONSULTANTS, BIC_OPTIONS } from '../constants';
import SearchableSelect from '../SearchableSelect';

interface ProjectFormProps {
  projects?: Project[];
  users: User[];
  currentUser: User;
  onSave: (project: Project) => void;
}

const ProjectForm: React.FC<ProjectFormProps> = ({ projects = [], users, currentUser, onSave }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const existingProject = projects.find(p => p.id === id);

  const [formData, setFormData] = useState<Partial<Project>>({
    status: ProjectStatus.ACTIVE,
    title_policy_status: TitlePolicyStatus.PENDING,
    project_manager_id: '1',
    agency: AGENCIES[0],
    architect: '',
    biologist: '',
    landscaper: '',
    surveyor: '',
    traffic_engineer: '',
    ball_in_court: BIC_OPTIONS[0],
    client_name: '',
    client_email: '',
    client_mobile: '',
    client_office: '',
    one_drive_folder: '',
    one_drive_notes: '',
    address: '',
    map_link: '',
    strap_number: '',
    description: ''
  });

  useEffect(() => {
    if (existingProject) {
      setFormData(existingProject);
    }
  }, [existingProject]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const now = new Date().toISOString().split('T')[0];

    const projectToSave: Project = {
      ...(formData as Project),
      id: existingProject?.id || crypto.randomUUID(),
      created_at: existingProject?.created_at || now,
      created_by: existingProject?.created_by || currentUser.name,
      last_updated_date: now,
      last_updated_by: currentUser.name,
    };
    onSave(projectToSave);
    navigate(`/project/${projectToSave.id}`);
  };

  return (
    <div className="max-w-5xl mx-auto pb-24 animate-in slide-in-from-bottom-4 duration-700">
      <form onSubmit={handleSubmit} className="space-y-10">
        {/* Navigation & Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
             <Link to={existingProject ? `/project/${existingProject.id}` : "/projects"} className="p-2.5 bg-white border border-slate-200 rounded-2xl text-slate-400 hover:text-[#000066] transition-all shadow-sm">
                <ArrowLeft size={20} />
             </Link>
             <div>
                <h2 className="text-3xl font-black text-slate-800 tracking-tight leading-none uppercase">
                  {existingProject ? 'Edit Project' : 'New Project'}
                </h2>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Record Management System</p>
             </div>
          </div>
          <div className="flex items-center gap-3">
            <button 
              type="submit" 
              className="px-8 py-3 bg-[#000066] text-white rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-[#000080] shadow-xl shadow-blue-900/10 transition-all flex items-center gap-2 transform active:scale-95"
            >
              <Save size={18} /> {existingProject ? 'Save Changes' : 'Initialize Record'}
            </button>
          </div>
        </div>

        {/* Section 1: Core Identification */}
        <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <Landmark size={120} />
          </div>
          <div className="flex items-center gap-3 mb-10">
            <div className="p-3 bg-blue-50 text-[#000066] rounded-2xl"><Info size={24} /></div>
            <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Project Identification</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-6">
            <div className="md:col-span-2 lg:col-span-2">
              <FormLabel label="Project Name" required />
              <input name="name" value={formData.name || ''} onChange={handleChange} className="form-input" placeholder="Project Title" required />
            </div>
            <div>
              <FormLabel label="Project #" required />
              <input name="number" value={formData.number || ''} onChange={handleChange} className="form-input" placeholder="YYYYXXXX" required />
            </div>
            <div>
              <FormLabel label="Project Manager" required />
              <select name="project_manager_id" value={formData.project_manager_id} onChange={handleChange} className="form-input">
                 {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
              </select>
            </div>
            <div>
              <FormLabel label="Lead Agency" required />
              <select name="agency" value={formData.agency} onChange={handleChange} className="form-input">
                 {AGENCIES.map(a => <option key={a} value={a}>{a}</option>)}
              </select>
            </div>
            <div>
              <FormLabel label="Project Status" required />
              <select name="status" value={formData.status} onChange={handleChange} className="form-input font-black uppercase text-[10px] tracking-widest text-[#000066]">
                 {Object.values(ProjectStatus).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="md:col-span-2 lg:col-span-2">
              <FormLabel label="Address" required />
              <input name="address" value={formData.address || ''} onChange={handleChange} className="form-input" placeholder="Full Location Details" required />
            </div>
            <div>
              <FormLabel label="GIS / Map Short Link" />
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                <input name="map_link" value={formData.map_link || ''} onChange={handleChange} className="form-input pl-12" placeholder="e.g. https://arcg.is/..." />
              </div>
            </div>
            <div className="md:col-span-2 lg:col-span-2">
              <FormLabel label="Description" />
              <textarea name="description" value={formData.description || ''} onChange={handleChange} rows={2} className="form-input" placeholder="Brief project summary..." />
            </div>
            <div>
              <FormLabel label="Strap #" required />
              <input name="strap_number" value={formData.strap_number || ''} onChange={handleChange} className="form-input" placeholder="Property ID" required />
            </div>
          </div>
        </div>

        {/* Section 2: Client Info */}
        <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <UserIcon size={120} />
          </div>
          <div className="flex items-center gap-3 mb-10">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl"><UserIcon size={24} /></div>
            <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Client Contact Information</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-6">
            <div className="md:col-span-2 lg:col-span-4">
              <FormLabel label="Client Legal Name / Entity" required />
              <input name="client_name" value={formData.client_name || ''} onChange={handleChange} className="form-input" placeholder="Company or Individual Name" required />
            </div>
            <div className="md:col-span-2 lg:col-span-2">
              <FormLabel label="Client Email" />
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                <input type="email" name="client_email" value={formData.client_email || ''} onChange={handleChange} className="form-input pl-12" placeholder="client@example.com" />
              </div>
            </div>
            <div>
              <FormLabel label="Mobile Phone" />
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                <input name="client_mobile" value={formData.client_mobile || ''} onChange={handleChange} className="form-input pl-12" placeholder="555-000-0000" />
              </div>
            </div>
            <div>
              <FormLabel label="Office Phone" />
              <div className="relative">
                <Building className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                <input name="client_office" value={formData.client_office || ''} onChange={handleChange} className="form-input pl-12" placeholder="555-000-0000" />
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Sub-Consultant Info */}
        <div className="bg-slate-50 p-10 rounded-[3rem] border border-slate-200 shadow-inner">
          <div className="flex items-center gap-3 mb-10">
            <div className="p-3 bg-white text-indigo-600 rounded-2xl shadow-sm border border-slate-100"><Users size={24} /></div>
            <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Sub-Consultant Info</h3>
          </div>
          <div className="space-y-6">
            <ConsultantField label="Architect" name="architect" value={formData.architect || ''} onChange={handleChange} />
            <ConsultantField label="Biologist" name="biologist" value={formData.biologist || ''} onChange={handleChange} />
            <ConsultantField label="Landscaper" name="landscaper" value={formData.landscaper || ''} onChange={handleChange} />
            <ConsultantField label="Surveyor" name="surveyor" value={formData.surveyor || ''} onChange={handleChange} />
            <ConsultantField label="Traffic Engineer" name="traffic_engineer" value={formData.traffic_engineer || ''} onChange={handleChange} />
          </div>
        </div>

        {/* Section 4: Project Storage */}
        <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="flex items-center gap-3 mb-10">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><LinkIcon size={24} /></div>
            <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">OneDrive Assets</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
            <div>
              <FormLabel label="Master Project Folder URL" />
              <input name="one_drive_folder" value={formData.one_drive_folder || ''} onChange={handleChange} className="form-input" placeholder="https://..." />
            </div>
            <div>
              <FormLabel label="Project Notes Folder URL" />
              <input name="one_drive_notes" value={formData.one_drive_notes || ''} onChange={handleChange} className="form-input" placeholder="https://..." />
            </div>
          </div>
        </div>

        <style>{`
          .form-input {
            width: 100%;
            background-color: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 1.25rem;
            padding: 0.8rem 1.25rem;
            font-size: 0.875rem;
            font-weight: 600;
            color: #1e293b;
            transition: all 0.2s;
            outline: none;
          }
          .form-input:focus {
            border-color: #000066;
            background-color: #fff;
            box-shadow: 0 10px 25px -5px rgba(0,0,102,0.1);
          }
          .consultant-select {
            width: 100%;
            background-color: #f1f5f9;
            border: none;
            border-radius: 0.75rem;
            padding: 0.75rem 1.25rem;
            font-size: 0.9rem;
            font-weight: 500;
            color: #1e293b;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2394a3b8' stroke-width='2'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19.5 8.25l-7.5 7.5-7.5-7.5'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 1rem center;
            background-size: 1.2rem;
            cursor: pointer;
            transition: background-color 0.2s;
          }
          .consultant-select:hover {
            background-color: #e2e8f0;
          }
        `}</style>
      </form>
    </div>
  );
};

const FormLabel: React.FC<{ label: string, required?: boolean }> = ({ label, required }) => (
  <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-2 px-1">
    {label} {required && <span className="text-rose-500">*</span>}
  </label>
);

const ConsultantField: React.FC<{ label: string, name: string, value: string, onChange: any }> = ({ label, name, value, onChange }) => (
  <div className="space-y-2">
    <label className="block text-[13px] font-black text-slate-800">{label}</label>
    <div className="relative">
      <input 
        name={name}
        value={value}
        onChange={onChange}
        placeholder="—"
        className="consultant-select"
      />
    </div>
  </div>
);

export default ProjectForm;
