import React, { useState, useRef } from 'react';
import { Download, Upload, Database, ChevronRight, X, CheckSquare, ShieldCheck, AlertCircle } from 'lucide-react';
import { Project, Permit, Task, Note, ProjectStatus, TitlePolicyStatus, User } from '../types';

interface ExportDataProps {
  projects: Project[];
  permits: Permit[];
  tasks: Task[];
  notes: Note[];
  users: User[];
  onImport: (data: { projects?: Project[], permits?: Permit[], tasks?: Task[], notes?: Note[] }) => Promise<void>;
  onReset: () => Promise<void>;
}

const ExportData: React.FC<ExportDataProps> = ({ projects, permits, tasks, notes, users, onImport, onReset }) => {
  const [importStatus, setImportStatus] = useState<{ type: 'success' | 'error' | 'loading', message: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeImportCategory, setActiveImportCategory] = useState<'projects' | 'permits' | 'tasks' | 'notes' | null>(null);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [isResetting, setIsResetting] = useState(false);

  const convertToCSV = (data: any[]) => {
    if (data.length === 0) return '';
    const headers = Object.keys(data[0]);
    const rows = data.map(obj => 
      headers.map(header => {
        const val = obj[header];
        const stringVal = val === null || val === undefined ? '' : String(val);
        const escaped = stringVal.replace(/"/g, '""');
        return `"${escaped}"`;
      }).join(',')
    );
    return [headers.join(','), ...rows].join('\n');
  };

  const downloadFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const parseCSV = (text: string) => {
    const cleanText = text.replace(/^\uFEFF/, '').replace(/\r/g, ''); 
    const result: string[][] = [];
    let row: string[] = [''];
    let i = 0;
    let quote = false;

    for (let char of cleanText) {
      if (char === '"') {
        quote = !quote;
      } else if (char === ',' && !quote) {
        row.push('');
        i++;
      } else if (char === '\n' && !quote) {
        result.push(row.map(cell => cell.trim()));
        row = [''];
        i = 0;
      } else {
        row[i] += char;
      }
    }
    if (row.length > 1 || row[0] !== '') {
      result.push(row.map(cell => cell.trim()));
    }
    if (result.length < 2) return [];
    
    const headers = result[0].map(h => h.trim());
    return result.slice(1).map(rowData => {
      const obj: any = {};
      headers.forEach((header, index) => {
        if (header) obj[header] = rowData[index] || '';
      });
      return obj;
    }).filter(o => Object.values(o).some(v => v !== ''));
  };

  const cleanDate = (d: string) => {
    if (!d) return '';
    const trimmed = d.trim();
    if (trimmed.includes('T')) return trimmed.split('T')[0];
    return trimmed;
  };

  const findKey = (headers: string[], patterns: string[]): string | undefined => {
    for (const p of patterns) {
      const pNorm = p.toLowerCase().replace(/[^a-z0-9#]/g, '');
      const exactMatch = headers.find(h => h.toLowerCase().replace(/[^a-z0-9#]/g, '') === pNorm);
      if (exactMatch) return exactMatch;
    }
    return headers.find(h => {
      const hNorm = h.toLowerCase().replace(/[^a-z0-9#]/g, '');
      return patterns.some(p => {
        const pNorm = p.toLowerCase().replace(/[^a-z0-9#]/g, '');
        return hNorm.includes(pNorm);
      });
    });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeImportCategory) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const rawData = parseCSV(text);
        if (rawData.length === 0) {
          setImportStatus({ type: 'error', message: 'The CSV file appears to be empty or improperly formatted.' });
          return;
        }
        
        setImportStatus({ type: 'loading', message: `Processing ${rawData.length} records...` });
        
        const headers = Object.keys(rawData[0]);
        console.log(`Importing ${activeImportCategory}. Found headers:`, headers);

        if (activeImportCategory === 'projects') {
          const pmNameKey = findKey(headers, ['manager name', 'pm name', 'project manager']) || 'Project Manager Name';
          const statusKey = findKey(headers, ['project status', 'status', 'state']) || 'Project Status';
          const nameKey = findKey(headers, ['project name', 'name', 'title']) || 'Project Name';
          const numKey = findKey(headers, ['project #', 'project number', 'job #', 'job number', 'id']) || 'Project #';
          const strapKey = findKey(headers, ['strap #', 'strap number', 'parcel id', 'strap']) || 'Strap #';
          const addressKey = findKey(headers, ['project address', 'address', 'location']) || 'Project Address';
          const agencyKey = findKey(headers, ['agency name', 'agency', 'jurisdiction']) || 'Agency Name';
          const clientKey = findKey(headers, ['client name', 'client', 'customer']) || 'Client Name';
          const clientEmailKey = findKey(headers, ['client email']) || 'Client Email';
          const clientMobileKey = findKey(headers, ['client mobile phone', 'client mobile']) || 'Client Mobile Phone';
          const clientOfficeKey = findKey(headers, ['client office phone', 'client office']) || 'Client Office Phone';
          const architectKey = findKey(headers, ['subs/sub - architect', 'architect']) || 'Subs/Sub - Architect';
          const biologistKey = findKey(headers, ['subs/sub - biologist', 'biologist']) || 'Subs/Sub - Biologist';
          const landscaperKey = findKey(headers, ['subs/sub - landscaper', 'landscaper']) || 'Subs/Sub - Landscaper';
          const surveyorKey = findKey(headers, ['subs/sub - surveyor', 'surveyor']) || 'Subs/Sub - Surveyor';
          const trafficEngKey = findKey(headers, ['subs/sub - traffic eng', 'traffic engineer']) || 'Subs/Sub - Traffic Eng';
          const titlePolicyKey = findKey(headers, ['presubitms/presub - titlepolicy - status', 'title policy status']) || 'PreSubItms/PreSub - TitlePolicy - Status';

          const mapped = rawData.map(item => {
            const pmName = (item[pmNameKey] || '').trim();
            // Try to find a matching PM by name (case-insensitive)
            const matchedPM = users.find(u => u.name.toLowerCase() === pmName.toLowerCase() || pmName.toLowerCase().includes(u.name.toLowerCase().split(' ')[0]));
            let status = ProjectStatus.ACTIVE;
            const rawStatus = (item[statusKey] || '').trim().toLowerCase();
            if (rawStatus.includes('close')) status = ProjectStatus.CLOSED;
            else if (rawStatus.includes('construction')) status = ProjectStatus.CONSTRUCTION;
            else if (rawStatus.includes('hold')) status = ProjectStatus.ON_HOLD;
            else if (rawStatus.includes('proposal')) status = ProjectStatus.PROPOSAL;
            else if (rawStatus.includes('co issued')) status = ProjectStatus.CO_ISSUED;

            let titleStatus = TitlePolicyStatus.PENDING;
            const rawTitle = (item[titlePolicyKey] || '').trim().toLowerCase();
            if (rawTitle.includes('received')) titleStatus = TitlePolicyStatus.RECEIVED;
            else if (rawTitle.includes('not required')) titleStatus = TitlePolicyStatus.NOT_REQUIRED;
            else if (rawTitle.includes('review')) titleStatus = TitlePolicyStatus.REVIEWING;

            return {
              id: (item.id || item['id'] || crypto.randomUUID()).trim(),
              name: (item[nameKey] || 'Unnamed Project').trim(),
              number: (item[numKey] || '').trim(),
              status: status,
              description: '',
              strap_number: (item[strapKey] || '').trim(),
              address: (item[addressKey] || '').trim(),
              agency: (item[agencyKey] || '').trim(),
              client_name: (item[clientKey] || 'N/A').trim(),
              client_email: (item[clientEmailKey] || '').trim(),
              client_mobile: (item[clientMobileKey] || '').trim(),
              client_office: (item[clientOfficeKey] || '').trim(),
              architect: (item[architectKey] || '').trim(),
              biologist: (item[biologistKey] || '').trim(),
              landscaper: (item[landscaperKey] || '').trim(),
              surveyor: (item[surveyorKey] || '').trim(),
              traffic_engineer: (item[trafficEngKey] || '').trim(),
              title_policy_status: titleStatus,
              one_drive_folder: '',
              one_drive_notes: '',
              project_manager_id: matchedPM ? matchedPM.id : (pmName || '1'),
              created_at: cleanDate(item['RecMetadataInfo/Date Created']) || new Date().toISOString().split('T')[0],
              created_by: (item['RecMetadataInfo/Created By Email'] || 'System Import').trim(),
            } as Project;
          });
          await onImport({ projects: mapped });
          setImportStatus({ type: 'success', message: `Import Success: ${mapped.length} projects synced to cloud.` });
        }

        if (activeImportCategory === 'tasks') {
          const projectNumKey = findKey(headers, ['project #', 'job #', 'project number', 'job number']) || 'Project #';
          const projectNameKey = findKey(headers, ['project name']) || 'Project Name';
          const taskNameKey = findKey(headers, ['task name', 'task', 'subject']) || 'Task Name';
          const descKey = findKey(headers, ['task description', 'description', 'details']) || 'Task Description';
          const assignedByKey = findKey(headers, ['assigned by name', 'from']) || 'Assigned By Name';
          const assignedToKey = findKey(headers, ['assigned to name', 'to', 'assigned to']) || 'Assigned To Name';
          const dateAssignedKey = findKey(headers, ['date assigned', 'assigned date']) || 'Date Assigned';
          const dateDueKey = findKey(headers, ['date due', 'due date', 'deadline']) || 'Date Due';
          const dateCompletedKey = findKey(headers, ['date completed', 'completed date']) || 'Date Completed';
          const statusKey = findKey(headers, ['task status', 'status', 'state']) || 'Task Status';
          const notesKey = findKey(headers, ['notes', 'comments']) || 'Notes';

          const mappedTasks = rawData.map(item => {
            const projectNum = (item[projectNumKey] || '').trim();
            const matchedProject = projects.find(p => p.number === projectNum || p.id === projectNum);
            let status = (item[statusKey] || 'Assigned').trim();
            if (status === 'Complete') status = 'Completed';
            return {
              id: (item['🔒 Row ID'] || item['id'] || crypto.randomUUID()).trim(),
              project_id: matchedProject ? matchedProject.id : '00000000-0000-0000-0000-000000000000', // Fallback to a dummy UUID or handle orphaned tasks
              project_name: (item[projectNameKey] || matchedProject?.name || '').trim(),
              name: (item[taskNameKey] || 'Unnamed Task').trim(),
              description: (item[descKey] || '').trim(),
              assigned_by: (item[assignedByKey] || 'System').trim(),
              assigned_to: (item[assignedToKey] || 'Unassigned').trim(),
              date_assigned: cleanDate(item[dateAssignedKey]) || '',
              due_date: cleanDate(item[dateDueKey]) || '',
              date_completed: cleanDate(item[dateCompletedKey]) || '',
              status: status,
              is_important: false,
              notes: (item[notesKey] || '').trim()
            } as Task;
          }).filter(t => t.project_id !== '00000000-0000-0000-0000-000000000000'); // Filter out orphaned tasks to avoid FK errors
          await onImport({ tasks: mappedTasks });
          setImportStatus({ type: 'success', message: `Import Success: ${mappedTasks.length} tasks synced to cloud.` });
        }

        if (activeImportCategory === 'permits') {
          const numKey = findKey(headers, ['project #', 'project number', 'job #', 'job number', 'projectid']) || 'Project #';
          const permitNumKey = findKey(headers, ['permit #', 'permit number', 'permit id', 'number']) || 'Permit #';
          const typeKey = findKey(headers, ['permit type', 'type', 'category']) || 'Permit Type';
          const appKey = findKey(headers, ['permit approval date', 'approval', 'approved date', 'approvaldate']) || 'Permit Approval Date';
          const expKey = findKey(headers, ['permit expiration date', 'expiration', 'expires', 'expiry', 'expirationdate']) || 'Permit Expiration Date';
          const targetKey = findKey(headers, ['permit target date', 'target date', 'targetdate']) || 'Permit Target Date';
          const submittalKey = findKey(headers, ['permit submittal date', 'submittal date', 'submittaldate']) || 'Permit Submittal Date';
          const comments1Key = findKey(headers, ['permit agency comments 1 date', 'comments 1 date', 'comments1date']) || 'Permit Agency Comments 1 Date';
          const resubmittal1Key = findKey(headers, ['permit resubmittal 1 date', 'resubmittal 1 date', 'resubmittal1date']) || 'Permit Resubmittal 1 Date';
          const comments2Key = findKey(headers, ['permit agency comments 2 date', 'comments 2 date', 'comments2date']) || 'Permit Agency Comments 2 Date';
          const resubmittal2Key = findKey(headers, ['permit resubmittal 2 date', 'resubmittal 2 date', 'resubmittal2date']) || 'Permit Resubmittal 2 Date';

          const mappedPermits = rawData.map(item => {
            const projectNum = (item[numKey] || '').trim();
            let matchedProject = projects.find(p => p.number === projectNum || p.id === projectNum);
            return {
              id: (item['🔒 Row ID'] || item['id'] || crypto.randomUUID()).trim(),
              project_id: matchedProject ? matchedProject.id : '00000000-0000-0000-0000-000000000000',
              number: (item[permitNumKey] || '').trim(),
              type: (item[typeKey] || 'General').trim(),
              approval_date: cleanDate(item[appKey]) || '',
              expiration_date: cleanDate(item[expKey]) || '',
              application_status: item[appKey] ? 'Approved' : 'Active',
              description: '',
              target_date: cleanDate(item[targetKey]) || '',
              submittal_date: cleanDate(item[submittalKey]) || '',
              comments_1_date: cleanDate(item[comments1Key]) || '',
              resubmittal_1_date: cleanDate(item[resubmittal1Key]) || '',
              comments_2_date: cleanDate(item[comments2Key]) || '',
              resubmittal_2_date: cleanDate(item[resubmittal2Key]) || ''
            } as Permit;
          }).filter(p => p.project_id !== '00000000-0000-0000-0000-000000000000');
          await onImport({ permits: mappedPermits });
          setImportStatus({ type: 'success', message: `Import Success: ${mappedPermits.length} permits synced to cloud.` });
        }

        if (activeImportCategory === 'notes') {
          const numKey = findKey(headers, ['project #', 'project number', 'job #', 'job number']) || 'Project #';
          const bodyKey = findKey(headers, ['body', 'content', 'note', 'text', 'comment', 'description']) || 'Note';
          const authorKey = findKey(headers, ['author name', 'author', 'by', 'created by']) || 'Author Name';
          const dateKey = findKey(headers, ['date', 'created date', 'timestamp']) || 'Date';

          const mappedNotes = rawData.map(item => {
            const projectNum = (item[numKey] || '').trim();
            let matchedProject = projects.find(p => p.number === projectNum || p.id === projectNum);
            return {
              id: (item['🔒 Row ID'] || item['id'] || crypto.randomUUID()).trim(),
              project_id: matchedProject ? matchedProject.id : '00000000-0000-0000-0000-000000000000',
              type: 'General',
              body: (item[bodyKey] || '').trim(),
              date: cleanDate(item[dateKey]) || new Date().toISOString(),
              author: (item[authorKey] || 'System').trim()
            } as Note;
          }).filter(n => n.project_id !== '00000000-0000-0000-0000-000000000000');
          await onImport({ notes: mappedNotes });
          setImportStatus({ type: 'success', message: `Import Success: ${mappedNotes.length} notes synced to cloud.` });
        }
        
        setActiveImportCategory(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
      } catch (err: any) {
        console.error(err);
        setImportStatus({ type: 'error', message: `Critical Error: ${err.message || 'Check CSV column formatting.'}` });
      }
    };
    reader.readAsText(file);
  };

  const triggerImport = (category: 'projects' | 'permits' | 'tasks' | 'notes') => {
    setActiveImportCategory(category);
    fileInputRef.current?.click();
  };

  const handleResetConfirm = async () => {
    setIsResetting(true);
    try {
      await onReset();
      setImportStatus({ type: 'success', message: 'All application data has been cleared successfully.' });
      setIsResetModalOpen(false);
    } catch (err: any) {
      setImportStatus({ type: 'error', message: `Reset Failed: ${err.message || 'Unknown error'}` });
    } finally {
      setIsResetting(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-12 px-6 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div className="flex items-center gap-4">
          <div className="p-4 bg-[#000066] text-white rounded-[1.5rem] shadow-xl">
            <Database size={32} />
          </div>
          <div>
            <h1 className="text-4xl font-black text-slate-800 tracking-tight leading-none">Data Management Center</h1>
            <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mt-2">Migrate and backup your project records</p>
          </div>
        </div>
      </div>

      {importStatus && (
        <div className={`mb-8 p-5 rounded-[2rem] flex items-center justify-between border-2 ${
          importStatus.type === 'success' ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 
          importStatus.type === 'loading' ? 'bg-blue-50 border-blue-100 text-blue-700' :
          'bg-rose-50 border-rose-100 text-rose-700'
        }`}>
          <div className="flex items-center gap-4">
            {importStatus.type === 'success' ? <ShieldCheck size={28} /> : 
             importStatus.type === 'loading' ? <Database className="animate-pulse" size={28} /> :
             <AlertCircle size={28} />}
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] mb-0.5">
                {importStatus.type === 'loading' ? 'Syncing to Cloud...' : 'Operation Result'}
              </p>
              <p className="text-sm font-bold">{importStatus.message}</p>
            </div>
          </div>
          {importStatus.type !== 'loading' && (
            <button onClick={() => setImportStatus(null)} className="p-2 hover:bg-black/5 rounded-full transition-colors"><X size={20} /></button>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="space-y-6">
          <div className="flex items-center gap-2 px-2">
            <h2 className="text-lg font-black text-slate-400 uppercase tracking-[0.2em]">Backup to CSV</h2>
            <div className="flex-1 h-px bg-slate-100"></div>
          </div>
          <div className="grid grid-cols-1 gap-4">
            <ActionCard 
              icon={<Download className="text-blue-500" />} 
              label="Export Projects" 
              onClick={() => downloadFile(convertToCSV(projects), 'projects_backup.csv', 'text/csv')}
            />
            <ActionCard 
              icon={<Download className="text-amber-500" />} 
              label="Export Permits" 
              onClick={() => downloadFile(convertToCSV(permits), 'permits_backup.csv', 'text/csv')}
            />
            <ActionCard 
              icon={<Download className="text-indigo-500" />} 
              label="Export Notes" 
              onClick={() => downloadFile(convertToCSV(notes), 'notes_backup.csv', 'text/csv')}
            />
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex items-center gap-2 px-2">
            <h2 className="text-lg font-black text-[#A68F5B] uppercase tracking-[0.2em]">Sync External Data</h2>
            <div className="flex-1 h-px bg-slate-100"></div>
          </div>
          <div className="grid grid-cols-1 gap-4">
            <ActionCard 
              icon={<Upload className="text-[#A68F5B]" />} 
              label="Sync Projects List" 
              onClick={() => triggerImport('projects')}
              isImport
            />
            <ActionCard 
              icon={<Upload className="text-blue-600" />} 
              label="Sync Permits Matrix" 
              onClick={() => triggerImport('permits')}
              isImport
            />
            <ActionCard 
              icon={<CheckSquare className="text-indigo-600" />} 
              label="Sync Tasks List" 
              onClick={() => triggerImport('tasks')}
              isImport
            />
            <ActionCard 
              icon={<Upload className="text-rose-600" />} 
              label="Sync Project Notes" 
              onClick={() => triggerImport('notes')}
              isImport
            />
          </div>
        </div>
      </div>

      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        className="hidden" 
        accept=".csv"
      />

      <div className="mt-24 text-center space-y-4 border-t border-slate-100 pt-12">
        <div className="max-w-md mx-auto p-8 bg-rose-50 rounded-[2.5rem] border border-rose-100">
          <AlertCircle className="text-rose-500 mx-auto mb-4" size={32} />
          <h3 className="text-lg font-black text-rose-800 uppercase tracking-tight">Nuclear Option</h3>
          <p className="text-xs font-bold text-rose-600 uppercase tracking-widest mt-2 mb-6">Permanently delete all projects, permits, tasks, and notes from Supabase.</p>
          <button 
            onClick={() => setIsResetModalOpen(true)}
            className="w-full py-4 bg-rose-600 text-white rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-rose-700 shadow-lg shadow-rose-200 transition-all"
          >
            Reset All Application Data
          </button>
        </div>
        <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.5em] mt-12">Quattrone & Associates &bull; Local Data Persistence</p>
      </div>

      {isResetModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-[2.5rem] p-8 max-w-sm w-full shadow-2xl border border-slate-100">
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-rose-50 rounded-full flex items-center justify-center mb-6 text-rose-500">
                <AlertCircle size={32} />
              </div>
              <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight mb-2">Are you absolutely sure?</h3>
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-widest mb-8 leading-relaxed">
                This will wipe your entire database. This action is irreversible and will delete all projects, permits, tasks, and notes.
              </p>
              <div className="grid grid-cols-2 gap-4 w-full">
                <button 
                  onClick={() => setIsResetModalOpen(false)} 
                  disabled={isResetting}
                  className="py-4 rounded-2xl border border-slate-200 text-slate-600 font-black uppercase text-[10px] tracking-widest hover:bg-slate-50 disabled:opacity-50"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleResetConfirm}
                  disabled={isResetting}
                  className="py-4 rounded-2xl bg-rose-600 text-white font-black uppercase text-[10px] tracking-widest hover:bg-rose-700 shadow-lg shadow-rose-200 disabled:opacity-50 flex items-center justify-center"
                >
                  {isResetting ? 'Resetting...' : 'Yes, Reset All'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ActionCard: React.FC<{ icon: React.ReactNode, label: string, onClick: () => void, isImport?: boolean }> = ({ icon, label, onClick, isImport }) => (
  <button 
    onClick={onClick}
    className="group bg-white border border-slate-200 p-8 rounded-[2.5rem] flex items-center justify-between text-left transition-all hover:border-[#000066] hover:shadow-2xl hover:-translate-y-1"
  >
    <div className="flex items-center gap-6">
      <div className="p-4 bg-slate-50 rounded-2xl group-hover:bg-blue-50 transition-colors border border-slate-50">
        {icon}
      </div>
      <div>
        <p className="font-black text-slate-800 uppercase tracking-tight text-sm">{label}</p>
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">{isImport ? 'Import CSV Data' : 'Download CSV Backup'}</p>
      </div>
    </div>
    <ChevronRight size={20} className="text-slate-300 group-hover:text-[#000066] transition-all" />
  </button>
);

export default ExportData;