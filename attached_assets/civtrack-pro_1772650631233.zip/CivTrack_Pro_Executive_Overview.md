# CivTrack Pro: Executive Overview & Operations Guide

## Introduction
CivTrack Pro is a custom-built, cloud-based project management application designed specifically for civil engineering workflows. It centralizes project data, tracks critical permit deadlines, manages team task assignments, and provides high-level oversight for firm leadership.

This document outlines the core features, access policies, and basic usage instructions for the application.

---

## 1. Core Features & Capabilities

### 🏢 Project Management (The "Master File")
*   **Centralized Database:** Replaces scattered spreadsheets. Every project has a single "Master File" containing client details, sub-consultant contacts, location data (Strap/GIS), and a direct link to the project's OneDrive folder.
*   **Status Tracking:** Projects are categorized by their current phase (Proposal, Active, Construction, On Hold, Closed, etc.), allowing leadership to instantly see the health of the firm's pipeline.

### 📜 Permit Matrix & Deadline Tracking
*   **Bottleneck Identification:** Tracks the exact status of every permit (e.g., "Under Agency Review", "Fees Posted - Unpaid", "Approved").
*   **Automated Radar:** The system automatically calculates deadlines based on target submittal dates and permit expiration dates.
*   **Expiring Permits Report:** A dedicated dashboard specifically for tracking permits that are within 90 days of expiring, ensuring nothing falls through the cracks.

### ✅ Task Ledger & Delegation
*   **Accountability:** Tasks can be assigned to specific team members with clear due dates and priority flags.
*   **Cross-Project View:** The "Tasks" tab aggregates all to-do items across all projects into one master list.
*   **Historical Archive:** Completed tasks are not deleted; they are moved to an archive for historical reference and performance tracking.

### 📅 Operational Calendar
*   **Visual Agenda:** A dynamic calendar view showing when tasks are due and when permits expire.
*   **Outlook Integration:** Users can click "Sync with Outlook" to download their schedule and import it into their standard email calendar.

### 🔔 Alert Center & Notifications
*   **Automated Pings:** When a user is assigned a new task, they receive an alert in the top-right notification bell.
*   **Global Alerts:** The system flags overdue items and critical deadlines on the main dashboard.

---

## 2. Access Control & Security Policies

CivTrack Pro uses a strict Role-Based Access Control (RBAC) system to ensure data security and operational focus.

### The Roles:
1.  **Application Owner (Firm Leadership):**
    *   *Capabilities:* Full, unrestricted access.
    *   *Visibility:* Can view the calendar and task lists for *all* personnel. Can dismiss global alerts. Can edit core project data and manage user accounts.
2.  **Project Manager / Administrator:**
    *   *Capabilities:* High-level access for managing operations.
    *   *Visibility:* Can view tasks and calendars for all personnel (to manage workloads). Can create/edit projects, permits, and tasks.
3.  **Engineer / CAD / EI (Standard Users):**
    *   *Capabilities:* Focused access for daily execution.
    *   *Visibility:* **Restricted.** These users can *only* see their own tasks and their own calendar. They cannot view what is assigned to other team members. They can update task statuses and add project notes, but cannot delete core project files.

---

## 3. How to Use the Application (Layman's Terms)

### For Firm Leadership (The "10,000-Foot View")
*   **The Dashboard:** This is your morning briefing. Check the "Active Pipeline" metric to see ongoing work. Look at the "Deadline Radar" on the right side to see if any permits are expiring or if targets are overdue.
*   **Workload Management:** Go to the **Calendar** or **Tasks** tab. Use the "Filter by Personnel" dropdown to select a specific employee (or "All Personnel") to see exactly what is on their plate this week.
*   **Unpaid Fees:** Check the "Unpaid Fees" metric on the dashboard to see which projects are stalled waiting for client payments.

### For Project Managers (The "Operational View")
*   **Starting a Project:** Click "New Project" in the sidebar. Fill out the basic details. Once created, open the project and start adding required permits to the "Permit Matrix."
*   **Assigning Work:** Open a project, go to the "Task Ledger" tab, and click "New Task." Assign it to an engineer and set a due date. They will receive a notification instantly.
*   **Tracking Progress:** Use the "Alerts" and "Expiring" tabs daily to ensure sub-consultants and agencies are moving forward.

### For Engineers & Staff (The "Execution View")
*   **Daily Routine:** Log in and look at your **Dashboard** or **Calendar**. You will only see the items assigned specifically to you.
*   **Completing Work:** When you finish a task, click the checkbox next to it. It will cross out and move to the archive.
*   **Logging Updates:** If you have a client call or receive agency feedback, go to the specific Project, click the "Notes" tab, and add a "New Entry." This keeps a permanent, searchable record of all communications.

---

## 4. Data Management & Backup

*   **Cloud Sync:** All data is saved instantly to a secure cloud database (Supabase).
*   **Data Tools:** In the "Data Tools" tab, leadership can export the entire database to Excel/CSV files for offline backup or custom reporting.
*   **Audit Trail:** The system silently logs who makes changes to projects (e.g., "Shelly updated Permit #123 on Tuesday"). This ensures accountability if data is accidentally altered.
