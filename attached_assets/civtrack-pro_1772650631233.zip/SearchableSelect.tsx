
import React, { useState, useRef, useEffect } from 'react';
import { Search, ChevronDown, Check } from 'lucide-react';

interface SearchableSelectProps {
  options: string[] | { id: string; label: string }[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
  required?: boolean;
  dark?: boolean;
}

const SearchableSelect: React.FC<SearchableSelectProps> = ({
  options,
  value,
  onChange,
  placeholder = "Select an option",
  label,
  required,
  dark = false
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const containerRef = useRef<HTMLDivElement>(null);

  const normalizedOptions = options.map(opt => 
    typeof opt === 'string' ? { id: opt, label: opt } : opt
  );

  const selectedOption = normalizedOptions.find(opt => opt.id === value);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filteredOptions = normalizedOptions.filter(opt => {
    const label = (opt.label || '').toLowerCase();
    const term = (searchTerm || '').toLowerCase();
    return label.includes(term);
  });

  return (
    <div className="relative w-full" ref={containerRef}>
      {label && (
        <label className={`block text-xs font-black uppercase tracking-widest mb-2 ${dark ? 'text-slate-500' : 'text-slate-900'}`}>
          {label} {required && <span className="text-rose-500">*</span>}
        </label>
      )}
      
      <button
        type="button"
        onClick={() => {
          setIsOpen(!isOpen);
          setSearchTerm("");
        }}
        className={`w-full text-left flex items-center justify-between px-4 py-2.5 rounded-xl border transition-all text-sm
          ${dark 
            ? 'bg-slate-800 border-slate-700 text-slate-100 hover:border-slate-600' 
            : 'bg-[#f1f1f1] border-slate-200 text-slate-800 hover:border-slate-300'
          }
          ${isOpen ? 'ring-2 ring-[#000066] border-[#000066]' : ''}
        `}
      >
        <span className={!selectedOption ? 'text-slate-400' : ''}>
          {selectedOption ? selectedOption.label : placeholder}
        </span>
        <ChevronDown size={16} className={isOpen ? 'text-[#000066]' : 'text-slate-400'} />
      </button>

      {isOpen && (
        <div className={`absolute z-50 mt-1 w-full border rounded-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-100
          ${dark ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}
        `}>
          <div className={`p-2 border-b sticky top-0 z-10 ${dark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
            <div className="relative">
              <Search className="absolute left-3 top-2.5 text-slate-400" size={14} />
              <input
                type="text"
                autoFocus
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className={`w-full pl-9 pr-4 py-2 text-sm rounded-lg focus:outline-none focus:ring-2 focus:ring-[#000066]/20 focus:border-[#000066] border
                  ${dark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-800'}
                `}
              />
            </div>
          </div>
          
          <div className="max-h-60 overflow-y-auto">
            {filteredOptions.length > 0 ? (
              filteredOptions.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => {
                    onChange(opt.id);
                    setIsOpen(false);
                  }}
                  className={`w-full text-left px-4 py-2.5 text-sm transition-colors flex items-center justify-between
                    ${dark 
                      ? 'text-slate-300 hover:bg-slate-800' 
                      : 'text-slate-700 hover:bg-slate-50'
                    }
                    ${value === opt.id ? (dark ? 'bg-slate-800 text-white font-bold' : 'bg-slate-100 text-slate-900 font-bold') : ''}
                  `}
                >
                  <span>{opt.label}</span>
                  {value === opt.id && <Check size={14} className="text-[#000066]" />}
                </button>
              ))
            ) : (
              <div className="px-4 py-4 text-xs text-slate-400 italic">No matches found</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchableSelect;
