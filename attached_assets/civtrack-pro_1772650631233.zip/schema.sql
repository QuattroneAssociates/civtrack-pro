-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Projects Table
CREATE TABLE projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  number TEXT NOT NULL UNIQUE,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'Active',
  project_manager_id TEXT NOT NULL,
  address TEXT NOT NULL,
  map_link TEXT,
  agency TEXT NOT NULL,
  strap_number TEXT NOT NULL,
  one_drive_folder TEXT,
  one_drive_notes TEXT,
  client_name TEXT NOT NULL,
  client_email TEXT,
  client_mobile TEXT,
  client_office TEXT,
  architect TEXT,
  biologist TEXT,
  landscaper TEXT,
  surveyor TEXT,
  traffic_engineer TEXT,
  title_policy_status TEXT NOT NULL DEFAULT 'Pending',
  ball_in_court TEXT,
  created_at DATE NOT NULL DEFAULT CURRENT_DATE,
  created_by TEXT,
  last_updated_date DATE DEFAULT CURRENT_DATE,
  last_updated_by TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION
);

-- Permits Table
CREATE TABLE permits (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  number TEXT,
  description TEXT,
  target_date DATE,
  submittal_date DATE,
  comments_1_date DATE,
  resubmittal_1_date DATE,
  comments_2_date DATE,
  resubmittal_2_date DATE,
  approval_date DATE,
  expiration_date DATE,
  agency TEXT,
  application_status TEXT,
  submittal_type TEXT,
  fee_status TEXT,
  fee_amount TEXT,
  external_dependency TEXT,
  last_action_date DATE,
  submittal_notes TEXT
);

-- Tasks Table
CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  assigned_by TEXT NOT NULL,
  assigned_to TEXT NOT NULL,
  date_assigned DATE NOT NULL DEFAULT CURRENT_DATE,
  due_date DATE NOT NULL,
  date_completed DATE,
  status TEXT NOT NULL DEFAULT 'Pending',
  is_important BOOLEAN NOT NULL DEFAULT FALSE,
  notes TEXT,
  tags TEXT[], -- Array of tags
  comments JSONB -- Array of comment objects
);

-- Notes Table
CREATE TABLE notes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  body TEXT NOT NULL,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  author TEXT NOT NULL
);

-- Audit Logs Table
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  entity_id UUID NOT NULL,
  entity_type TEXT NOT NULL,
  entity_name TEXT NOT NULL,
  action TEXT NOT NULL,
  field_name TEXT,
  old_value TEXT,
  new_value TEXT,
  user_id UUID NOT NULL,
  user_name TEXT NOT NULL,
  timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Users Table (if needed, otherwise managed by Supabase Auth)
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
