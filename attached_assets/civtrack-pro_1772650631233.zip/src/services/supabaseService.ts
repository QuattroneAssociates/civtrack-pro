import { supabase } from '../lib/supabase';
import { Project, Permit, Task, Note, CalendarEvent, AppNotification, User, AuditLog } from '../../types';

// Helper to normalize DB result to snake_case (internal app standard)
const toSnakeCase = (obj: any): any => {
  if (!obj) return obj;
  const newObj: any = {};
  Object.keys(obj).forEach(key => {
    // Specific mappings based on the user's SQL script
    const mappings: Record<string, string> = {
      'projectManagerId': 'project_manager_id',
      'projectManagerName': 'project_manager_name',
      'strapNumber': 'strap_number',
      'clientName': 'client_name',
      'clientEmail': 'client_email',
      'clientMobile': 'client_mobile',
      'clientOffice': 'client_office',
      'trafficEngineer': 'traffic_engineer',
      'titlePolicyStatus': 'title_policy_status',
      'ballInCourt': 'ball_in_court',
      'createdAt': 'created_at',
      'createdBy': 'created_by',
      'lastUpdatedDate': 'last_updated_date',
      'lastUpdatedBy': 'last_updated_by',
      'projectId': 'project_id',
      'approvalDate': 'approval_date',
      'expirationDate': 'expiration_date',
      'applicationStatus': 'application_status',
      'projectName': 'project_name',
      'assignedBy': 'assigned_by',
      'assignedTo': 'assigned_to',
      'dateAssigned': 'date_assigned',
      'dueDate': 'due_date',
      'dateCompleted': 'date_completed',
      'isImportant': 'is_important',
      'userId': 'user_id',
      'startTime': 'start_time',
      'endTime': 'end_time',
      'isActive': 'is_active',
      'targetDate': 'target_date',
      'submittalDate': 'submittal_date',
      'comments1Date': 'comments_1_date',
      'resubmittal1Date': 'resubmittal_1_date',
      'comments2Date': 'comments_2_date',
      'resubmittal2Date': 'resubmittal_2_date',
      'entityId': 'entity_id',
      'entityType': 'entity_type',
      'entityName': 'entity_name',
      'fieldName': 'field_name',
      'oldValue': 'old_value',
      'newValue': 'new_value',
      'userName': 'user_name'
    };
    const newKey = mappings[key] || key;
    newObj[newKey] = obj[key];
  });
  return newObj;
};

// Helper to convert internal snake_case to camelCase for DB writes if needed
// We detect the schema mode based on reads
let USE_CAMEL_CASE_DB = false;

const toDbSchema = (obj: any): any => {
  if (!USE_CAMEL_CASE_DB) return obj;
  const newObj: any = {};
  Object.keys(obj).forEach(key => {
    const mappings: Record<string, string> = {
      'project_manager_id': 'projectManagerId',
      'project_manager_name': 'projectManagerName',
      'strap_number': 'strapNumber',
      'client_name': 'clientName',
      'client_email': 'clientEmail',
      'client_mobile': 'clientMobile',
      'client_office': 'clientOffice',
      'traffic_engineer': 'trafficEngineer',
      'title_policy_status': 'titlePolicyStatus',
      'ball_in_court': 'ballInCourt',
      'created_at': 'createdAt',
      'created_by': 'createdBy',
      'last_updated_date': 'lastUpdatedDate',
      'last_updated_by': 'lastUpdatedBy',
      'project_id': 'projectId',
      'approval_date': 'approvalDate',
      'expiration_date': 'expirationDate',
      'application_status': 'applicationStatus',
      'project_name': 'projectName',
      'assigned_by': 'assignedBy',
      'assigned_to': 'assignedTo',
      'date_assigned': 'dateAssigned',
      'due_date': 'dueDate',
      'date_completed': 'dateCompleted',
      'is_important': 'isImportant',
      'user_id': 'userId',
      'start_time': 'startTime',
      'end_time': 'endTime',
      'is_active': 'isActive',
      'target_date': 'targetDate',
      'submittal_date': 'submittalDate',
      'comments_1_date': 'comments1Date',
      'resubmittal_1_date': 'resubmittal1Date',
      'comments_2_date': 'comments2Date',
      'resubmittal_2_date': 'resubmittal2Date',
      'entity_id': 'entityId',
      'entity_type': 'entityType',
      'entity_name': 'entityName',
      'field_name': 'fieldName',
      'old_value': 'oldValue',
      'new_value': 'newValue',
      'user_name': 'userName'
    };
    const newKey = mappings[key] || key;
    newObj[newKey] = obj[key];
  });
  return newObj;
};

export const supabaseService = {
  // Projects
  async getProjects() {
    console.log('Supabase: Fetching projects...');
    const { data, error } = await supabase
      .from('projects')
      .select('*');
    
    if (error) {
      console.error('Supabase Error (getProjects):', error);
      throw error;
    }

    // Detect schema
    if (data && data.length > 0) {
      const first = data[0];
      if ('projectManagerId' in first || 'createdAt' in first) {
        console.log('Supabase: Detected camelCase schema');
        USE_CAMEL_CASE_DB = true;
      }
    }
    
    // Normalize data
    const normalizedData = (data || []).map(toSnakeCase);
    
    // Sort client-side to avoid issues if created_at column is missing or named differently
    const sortedData = (normalizedData as Project[]).sort((a, b) => {
      const dateA = new Date(a.created_at || 0).getTime();
      const dateB = new Date(b.created_at || 0).getTime();
      return dateB - dateA;
    });

    console.log('Supabase: Projects fetched', sortedData.length);
    return sortedData;
  },

  async saveProject(project: Project) {
    const dbPayload = toDbSchema(project);
    const { data, error } = await supabase
      .from('projects')
      .upsert(dbPayload)
      .select();
    if (error) throw error;
    return toSnakeCase(data[0]) as Project;
  },

  async bulkSaveProjects(projects: Project[]) {
    console.log(`Supabase: Bulk saving ${projects.length} projects`);
    const dbPayload = projects.map(toDbSchema);
    const { data, error } = await supabase
      .from('projects')
      .upsert(dbPayload)
      .select();
    if (error) throw error;
    return (data || []).map(toSnakeCase) as Project[];
  },

  async deleteProject(id: string) {
    const { error } = await supabase
      .from('projects')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },

  async clearAllProjects() {
    const { error } = await supabase
      .from('projects')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all
    if (error) throw error;
  },

  // Permits
  async getPermits() {
    const { data, error } = await supabase
      .from('permits')
      .select('*');
    if (error) throw error;
    
    // Normalize data
    const normalizedData = (data || []).map(toSnakeCase);
    return normalizedData as Permit[];
  },

  async savePermit(permit: Permit) {
    const permitToSave = { ...permit };
    // Strip virtual/UI-only fields
    delete (permitToSave as any).project_name;
    
    const dbPayload = toDbSchema(permitToSave);
    const { data, error } = await supabase
      .from('permits')
      .upsert(dbPayload)
      .select();
    if (error) {
      console.error('Supabase Error (savePermit):', error);
      throw error;
    }
    return toSnakeCase(data[0]) as Permit;
  },

  async bulkSavePermits(permits: Permit[]) {
    const dbPayload = permits.map(toDbSchema);
    const { data, error } = await supabase
      .from('permits')
      .upsert(dbPayload)
      .select();
    if (error) throw error;
    return (data || []).map(toSnakeCase) as Permit[];
  },

  async deletePermit(id: string) {
    const { error } = await supabase
      .from('permits')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },

  async clearAllPermits() {
    const { error } = await supabase
      .from('permits')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');
    if (error) throw error;
  },

  // Tasks
  async getTasks() {
    console.log('Supabase: Fetching tasks...');
    const { data, error } = await supabase
      .from('tasks')
      .select('*');
    if (error) {
      console.error('Supabase Error (getTasks):', error);
      throw error;
    }
    
    // Normalize data first
    const normalizedData = (data || []).map(toSnakeCase);
    
    const sortedData = (normalizedData as any[]).map(t => {
      let notes = t.notes;
      let tags = t.tags || [];
      let comments = t.comments || [];
      if (notes && notes.startsWith('{')) {
        try {
          const parsed = JSON.parse(notes);
          if (parsed.isSerializedTaskData) {
            notes = parsed.text || '';
            tags = parsed.tags || [];
            comments = parsed.comments || [];
          }
        } catch (e) {}
      }
      return { ...t, notes, tags, comments };
    }).sort((a, b) => {
      const dateA = new Date(a.date_assigned || 0).getTime();
      const dateB = new Date(b.date_assigned || 0).getTime();
      return dateB - dateA;
    });

    console.log('Supabase: Tasks fetched', sortedData.length);
    return sortedData as Task[];
  },

  async saveTask(task: Task) {
    console.log('Supabase: saveTask called for', task.id);
    const taskToSave: any = { ...task };
    // Strip virtual/UI-only fields
    delete taskToSave.project_name;
    
    // In the new schema, tags and comments are first-class columns
    // but we'll keep the serialized notes for backward compatibility if needed, 
    // or just use the columns directly.
    
    const dbPayload = toDbSchema(taskToSave);
    console.log('Supabase: saveTask payload', dbPayload);
    
    const { data, error } = await supabase
      .from('tasks')
      .upsert(dbPayload)
      .select();
    
    if (error) {
      console.error('Supabase Error (saveTask):', error);
      throw error;
    }
    
    console.log('Supabase: Task saved', data?.[0]?.id);
    return toSnakeCase(data[0]) as Task;
  },

  async bulkSaveTasks(tasks: Task[]) {
    const dbPayload = tasks.map(toDbSchema);
    const { data, error } = await supabase
      .from('tasks')
      .upsert(dbPayload)
      .select();
    if (error) throw error;
    
    return (data || []).map(toSnakeCase) as Task[];
  },

  async deleteTask(id: string) {
    const { error } = await supabase
      .from('tasks')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },

  async clearAllTasks() {
    const { error } = await supabase
      .from('tasks')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');
    if (error) throw error;
  },

  // Notes
  async getNotes() {
    const { data, error } = await supabase
      .from('notes')
      .select('*');
    if (error) throw error;
    
    // Normalize data
    const normalizedData = (data || []).map(toSnakeCase);
    
    const sortedData = (normalizedData as Note[]).sort((a, b) => {
      const dateA = new Date(a.date || 0).getTime();
      const dateB = new Date(b.date || 0).getTime();
      return dateB - dateA;
    });

    return sortedData;
  },

  async saveNote(note: Note) {
    const noteToSave = { ...note };
    // Strip virtual/UI-only fields
    delete (noteToSave as any).project_name;

    const dbPayload = toDbSchema(noteToSave);
    const { data, error } = await supabase
      .from('notes')
      .upsert(dbPayload)
      .select();
    if (error) {
      console.error('Supabase Error (saveNote):', error);
      throw error;
    }
    return toSnakeCase(data[0]) as Note;
  },

  async deleteNote(id: string) {
    const { error } = await supabase
      .from('notes')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },

  async clearAllNotes() {
    const { error } = await supabase
      .from('notes')
      .delete()
      .neq('id', '00000000-0000-0000-0000-000000000000');
    if (error) throw error;
  },

  async bulkSaveNotes(notes: Note[]) {
    const dbPayload = notes.map(toDbSchema);
    const { data, error } = await supabase
      .from('notes')
      .upsert(dbPayload)
      .select();
    if (error) throw error;
    return (data || []).map(toSnakeCase) as Note[];
  },

  // Calendar Events
  async getCalendarEvents() {
    const { data, error } = await supabase
      .from('calendar_events')
      .select('*');
    if (error) throw error;
    return data as CalendarEvent[];
  },

  async saveCalendarEvent(event: CalendarEvent) {
    const { data, error } = await supabase
      .from('calendar_events')
      .upsert(event)
      .select();
    if (error) throw error;
    return data[0] as CalendarEvent;
  },

  async deleteCalendarEvent(id: string) {
    const { error } = await supabase
      .from('calendar_events')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },

  // Notifications
  async getNotifications() {
    console.log('Supabase: Fetching notifications...');
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .order('timestamp', { ascending: false });
    if (error) {
      console.error('Supabase Error (getNotifications):', error);
      throw error;
    }
    console.log('Supabase: Notifications fetched', data?.length || 0);
    return data as AppNotification[];
  },

  async saveNotification(notification: AppNotification) {
    const { data, error } = await supabase
      .from('notifications')
      .upsert(notification)
      .select();
    if (error) throw error;
    return data[0] as AppNotification;
  },

  async deleteNotification(id: string) {
    const { error } = await supabase
      .from('notifications')
      .delete()
      .eq('id', id);
    if (error) throw error;
  },

  async clearUserNotifications(recipient: string) {
    const { error } = await supabase
      .from('notifications')
      .delete()
      .eq('recipient', recipient);
    if (error) throw error;
  },

  // Users
  async getUsers() {
    const { data, error } = await supabase
      .from('users')
      .select('*');
    if (error) throw error;
    return (data || []).map(toSnakeCase) as User[];
  },

  async saveUser(user: User) {
    const dbPayload = toDbSchema(user);
    const { data, error } = await supabase
      .from('users')
      .upsert(dbPayload)
      .select();
    if (error) throw error;
    return toSnakeCase(data[0]) as User;
  },

  // Audit Logs
  async getAuditLogs(entity_id?: string) {
    let query = supabase.from('audit_logs').select('*');
    if (entity_id) {
      query = query.eq('entity_id', entity_id);
    }
    const { data, error } = await query.order('timestamp', { ascending: false });
    if (error) throw error;
    return (data || []).map(toSnakeCase) as AuditLog[];
  },

  async saveAuditLog(log: AuditLog) {
    const dbPayload = toDbSchema(log);
    const { error } = await supabase
      .from('audit_logs')
      .insert(dbPayload);
    if (error) throw error;
  },

  // Dismissed Alerts
  async getDismissedAlerts() {
    const { data, error } = await supabase
      .from('dismissed_alerts')
      .select('alert_key');
    if (error) {
      // If table doesn't exist yet, return empty
      if (error.code === 'PGRST116' || error.message.includes('does not exist')) return [];
      throw error;
    }
    return (data as { alert_key: string }[]).map(d => d.alert_key);
  },

  async saveDismissedAlert(alertKey: string) {
    console.log('Supabase: Saving dismissed alert', alertKey);
    const { error } = await supabase
      .from('dismissed_alerts')
      .upsert({ alert_key: alertKey }, { onConflict: 'alert_key' });
    if (error) {
      console.error('Supabase Error (saveDismissedAlert):', error);
      throw error;
    }
  },

  async clearAllDismissedAlerts() {
    const { error } = await supabase
      .from('dismissed_alerts')
      .delete()
      .neq('alert_key', 'none');
    if (error) throw error;
  }
};
