export const parseDateSafe = (dateStr: string | undefined | null): Date | null => {
  const cleanStr = String(dateStr || '').trim();
  if (!cleanStr || cleanStr === '-' || cleanStr === 'TBD' || cleanStr === 'null') return null;
  const d = new Date(cleanStr);
  if (!isNaN(d.getTime())) return d;
  const usParts = cleanStr.split('/');
  if (usParts.length === 3) {
    let year = parseInt(usParts[2]);
    if (usParts[2].length === 2) year += year < 50 ? 2000 : 1900;
    const manualDate = new Date(year, parseInt(usParts[0]) - 1, parseInt(usParts[1]));
    return isNaN(manualDate.getTime()) ? null : manualDate;
  }
  return null;
};

export const formatDate = (dateStr: string | undefined | null): string => {
  const d = parseDateSafe(dateStr);
  if (!d) return dateStr || '-';
  return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
};
