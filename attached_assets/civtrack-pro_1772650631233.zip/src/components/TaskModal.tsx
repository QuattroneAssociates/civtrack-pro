import React, { useState } from 'react';
import { Task, TaskComment, User } from '../../types';
import { X, MessageSquare, Tag, Send, Clock, User as UserIcon } from 'lucide-react';

interface TaskModalProps {
  task: Task;
  currentUser: User;
  onClose: () => void;
  onUpdate: (task: Task) => void;
}

const PREDEFINED_TAGS = ['Urgent', 'Client-Request', 'Waiting-On-Surveyor', 'Agency-Review', 'Internal-Review'];

export const TaskModal: React.FC<TaskModalProps> = ({ task, currentUser, onClose, onUpdate }) => {
  const [commentText, setCommentText] = useState('');
  const [showTagMenu, setShowTagMenu] = useState(false);

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    const newComment: TaskComment = {
      id: crypto.randomUUID(),
      author: currentUser.name,
      text: commentText,
      timestamp: new Date().toISOString()
    };

    onUpdate({
      ...task,
      comments: [...(task.comments || []), newComment]
    });
    setCommentText('');
  };

  const toggleTag = (tag: string) => {
    const currentTags = task.tags || [];
    const newTags = currentTags.includes(tag) 
      ? currentTags.filter(t => t !== tag)
      : [...currentTags, tag];
    
    onUpdate({ ...task, tags: newTags });
  };

  // Simple @mention highlighting
  const renderCommentText = (text: string | null | undefined) => {
    if (!text) return null;
    const parts = text.split(/(@\w+)/g);
    return parts.map((part, i) => {
      if (part.startsWith('@')) {
        return <span key={i} className="text-blue-600 font-bold bg-blue-50 px-1 rounded">{part}</span>;
      }
      return <span key={i}>{part}</span>;
    });
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        <div className="px-10 py-8 border-b border-slate-50 flex items-center justify-between bg-slate-50/50 shrink-0">
          <div>
            <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight">
              {task.name}
            </h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
              Task Details & Collaboration
            </p>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-white rounded-2xl transition-all shadow-sm"><X size={24} /></button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-10 space-y-8 no-scrollbar">
          {/* Tags Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                <Tag size={14} /> Tags & Labels
              </h4>
              <button 
                onClick={() => setShowTagMenu(!showTagMenu)}
                className="text-[10px] font-bold text-blue-600 uppercase hover:underline"
              >
                {showTagMenu ? 'Close Menu' : '+ Add Tag'}
              </button>
            </div>
            
            {showTagMenu && (
              <div className="flex flex-wrap gap-2 p-4 bg-slate-50 rounded-2xl border border-slate-100 mb-4">
                {PREDEFINED_TAGS.map(tag => {
                  const isActive = (task.tags || []).includes(tag);
                  return (
                    <button
                      key={tag}
                      onClick={() => toggleTag(tag)}
                      className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all border ${
                        isActive 
                          ? 'bg-blue-600 text-white border-blue-700 shadow-md' 
                          : 'bg-white text-slate-500 border-slate-200 hover:border-blue-300 hover:text-blue-600'
                      }`}
                    >
                      #{tag}
                    </button>
                  );
                })}
              </div>
            )}

            <div className="flex flex-wrap gap-2">
              {(task.tags || []).map(tag => (
                <span key={tag} className="px-3 py-1 bg-blue-50 text-blue-700 border border-blue-100 rounded-lg text-[10px] font-black uppercase tracking-widest">
                  #{tag}
                </span>
              ))}
              {(!task.tags || task.tags.length === 0) && !showTagMenu && (
                <span className="text-xs text-slate-400 italic">No tags added.</span>
              )}
            </div>
          </div>

          {/* Comments Section */}
          <div className="space-y-6 pt-6 border-t border-slate-100">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
              <MessageSquare size={14} /> Discussion Thread
            </h4>
            
            <div className="space-y-4">
              {(task.comments || []).map(comment => (
                <div key={comment.id} className="bg-slate-50 p-5 rounded-3xl border border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-black text-slate-700 flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-[10px]">
                        {comment.author.charAt(0)}
                      </div>
                      {comment.author}
                    </span>
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1">
                      <Clock size={10} /> {new Date(comment.timestamp).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 ml-8 leading-relaxed">
                    {renderCommentText(comment.text)}
                  </p>
                </div>
              ))}
              {(!task.comments || task.comments.length === 0) && (
                <div className="text-center py-8 bg-slate-50 rounded-3xl border border-dashed border-slate-200">
                  <p className="text-xs font-bold text-slate-400">No comments yet. Start the discussion!</p>
                </div>
              )}
            </div>

            <form onSubmit={handleAddComment} className="mt-4 relative">
              <textarea
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Add a comment... Use @name to mention someone."
                className="w-full pl-6 pr-16 py-4 bg-white border border-slate-200 rounded-3xl text-sm focus:outline-none focus:ring-4 focus:ring-blue-500/10 transition-all resize-none min-h-[100px]"
              />
              <button 
                type="submit"
                disabled={!commentText.trim()}
                className="absolute right-4 bottom-4 p-3 bg-[#000066] text-white rounded-2xl hover:bg-blue-800 transition-all disabled:opacity-50 disabled:hover:bg-[#000066]"
              >
                <Send size={16} />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
