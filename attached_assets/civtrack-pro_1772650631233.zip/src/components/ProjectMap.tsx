import React from 'react';
import { Map, Marker, ZoomControl } from 'pigeon-maps';
import { Project } from '../../types';
import { MapPin, Navigation } from 'lucide-react';

interface ProjectMapProps {
  projects: Project[];
  onSelectProject?: (project: Project) => void;
  center?: [number, number];
  zoom?: number;
  onBoundsChanged?: (params: { center: [number, number], zoom: number }) => void;
  provider?: (x: number, y: number, z: number, dpr?: number) => string;
}

const ProjectMap: React.FC<ProjectMapProps> = ({ projects, onSelectProject, center = [26.6406, -81.8723], zoom = 11, onBoundsChanged, provider }) => {
  // Filter projects that have lat/lng
  const projectsWithLocation = projects.filter(p => p.latitude && p.longitude);

  return (
    <div className="w-full h-full rounded-[2.5rem] overflow-hidden border border-slate-200 shadow-inner relative">
      <Map 
        height={undefined} 
        center={center as [number, number]} 
        defaultZoom={zoom}
        onBoundsChanged={onBoundsChanged}
        boxClassname="pigeon-filters"
        provider={provider}
      >
        <ZoomControl />
        {projectsWithLocation.map(project => (
          <Marker 
            {...({
              key: project.id,
              width: 40,
              anchor: [project.latitude as number, project.longitude as number] as [number, number],
              onClick: () => onSelectProject?.(project)
            } as any)}
          >
            <div className="group relative cursor-pointer">
              <div className="p-2 bg-white rounded-2xl shadow-xl border-2 border-[#000066] text-[#000066] transform transition-all group-hover:scale-110 group-hover:-translate-y-1">
                <MapPin size={20} fill="currentColor" fillOpacity={0.2} />
              </div>
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 opacity-0 group-hover:opacity-100 transition-all pointer-events-none z-50">
                <div className="bg-slate-900 text-white px-4 py-2 rounded-xl shadow-2xl whitespace-nowrap border border-slate-700">
                  <p className="text-[10px] font-black uppercase tracking-tight">{project.name}</p>
                  <p className="text-[8px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">#{project.number}</p>
                  <div className="absolute top-full left-1/2 -translate-x-1/2 w-2 h-2 bg-slate-900 rotate-45 -mt-1 border-r border-b border-slate-700"></div>
                </div>
              </div>
            </div>
          </Marker>
        ))}
      </Map>
      
    </div>
  );
};

export default ProjectMap;
