/// <reference types="vite/client" />
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.VITE_SUPABASE_ANON;

if (!supabaseUrl) console.error('Supabase URL is missing!');
if (!supabaseAnonKey) console.error('Supabase Anon Key is missing!');

export const supabase = createClient(supabaseUrl || '', supabaseAnonKey || '');
