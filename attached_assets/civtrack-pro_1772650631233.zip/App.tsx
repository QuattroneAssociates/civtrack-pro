
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { HashRouter, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, PlusCircle, Menu, X, Search as SearchIcon, 
  HardHat, FolderKanban, CheckSquare, Bell, CalendarClock, 
  AlertTriangle, ExternalLink, Download, ClipboardList, 
  Database, PanelLeftClose, PanelLeftOpen, CalendarDays,
  User as UserIcon, LogOut, ChevronDown, Check, Clock, CheckCircle2,
  Users, BarChart3
} from 'lucide-react';
import Dashboard from './pages/Dashboard';
import ProjectsList from './pages/ProjectsList';
import TasksList from './pages/TasksList';
import ProjectDetails from './pages/ProjectDetails';
import ProjectForm from './pages/ProjectForm';
import Alerts from './pages/Alerts';
import ExpiringPermits from './pages/ExpiringPermits';
import ExportData from './pages/ExportData';
import MyCalendar from './pages/MyCalendar';
import UserDirectory from './pages/UserDirectory';
import Reports from './pages/Reports';
import { Project, Permit, Task, Note, CalendarEvent, ProjectStatus, TitlePolicyStatus, User, AppNotification, AuditLog } from './types';
import { USERS } from './constants';
import { supabaseService } from './src/services/supabaseService';
import { supabase } from './src/lib/supabase';
import { Login } from './pages/Login';
import { ResetPassword } from './pages/ResetPassword';
import { Session } from '@supabase/supabase-js';

const STORAGE_KEY = 'civtrack_data_v_screenshots_v3'; 

const QALogo: React.FC<{ size?: number }> = ({ size = 28 }) => (
  <img 
    src="https://res.cloudinary.com/glide/image/fetch/f_auto,w_150,h_150,c_lfill/https%3A%2F%2Ffirebasestorage.googleapis.com%2Fv0%2Fb%2Fglide-prod.appspot.com%2Fo%2Ficon-images%252Fanonymous-2d340fc2-6912-482f-b86f-73402a2cd5ec.JPG%3Falt%3Dmedia%26token%3D6d6ae256-7bcf-4ab1-8151-3c53e29b262d" 
    alt="Quattrone Logo" 
    style={{ width: size, height: size }}
    className="object-contain"
  />
);

const NotificationCenter: React.FC<{
  notifications: AppNotification[],
  currentUser: User,
  onClearAll: () => void,
  onClearNotification: (id: string) => void
}> = ({ notifications, currentUser, onClearAll, onClearNotification }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  // Filter notifications intended for the current user
  const userNotifications = notifications.filter(n => n.recipient === currentUser.name);
  
  // The badge count reflects all items until they are cleared
  const activeCount = userNotifications.length;

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) setIsOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={`p-2 rounded-xl border transition-all relative ${isOpen ? 'bg-blue-50 border-blue-200 text-[#000066]' : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-[#000066]'}`}
      >
        <Bell size={20} />
        {activeCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-rose-500 text-white text-[10px] font-black rounded-full flex items-center justify-center border-2 border-white shadow-sm animate-pulse">
            {activeCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-3 w-80 bg-white rounded-[1.5rem] shadow-2xl border border-slate-100 overflow-hidden z-[100] animate-in zoom-in-95 duration-150 origin-top-right">
          <div className="p-4 border-b border-slate-50 flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-widest text-slate-800">Alert Center</h3>
            {userNotifications.length > 0 && (
              <button onClick={onClearAll} className="text-[9px] font-black uppercase text-rose-500 hover:underline">Clear All</button>
            )}
          </div>
          <div className="max-h-96 overflow-y-auto no-scrollbar">
            {userNotifications.length > 0 ? (
              userNotifications.map(n => (
                <div 
                  key={n.id} 
                  className="p-4 border-b border-slate-50 transition-colors hover:bg-slate-50 flex gap-3 bg-blue-50/30 relative group"
                >
                  <div 
                    onClick={() => { if(n.link) window.location.hash = n.link; setIsOpen(false); }}
                    className="flex-1 flex gap-3 cursor-pointer"
                  >
                    <div className={`mt-1 shrink-0 w-8 h-8 rounded-lg flex items-center justify-center ${
                      n.type === 'task' ? 'bg-blue-100 text-blue-600' : 
                      n.type === 'permit' ? 'bg-rose-100 text-rose-600' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {n.type === 'task' ? <CheckSquare size={14} /> : n.type === 'permit' ? <CalendarClock size={14} /> : <Bell size={14} />}
                    </div>
                    <div className="min-w-0 pr-6">
                      <p className="text-xs font-bold leading-tight text-slate-900">{n.title}</p>
                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{n.message}</p>
                      <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mt-2 flex items-center gap-1">
                        <Clock size={10} /> {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onClearNotification(n.id);
                    }}
                    className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-rose-500 bg-white hover:bg-rose-50 rounded-lg opacity-0 group-hover:opacity-100 transition-all border border-slate-200"
                    title="Clear Alert"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))
            ) : (
              <div className="p-10 text-center">
                <CheckCircle2 size={32} className="mx-auto text-slate-100 mb-2" />
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-300">No new alerts</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const GlobalHeader: React.FC<{ 
  searchQuery: string, 
  setSearchQuery: (q: string) => void,
  isSidebarOpen: boolean,
  toggleSidebar: () => void,
  currentUser: User,
  notifications: AppNotification[],
  onClearAll: () => void,
  onClearNotification: (id: string) => void
}> = ({ searchQuery, setSearchQuery, isSidebarOpen, toggleSidebar, currentUser, notifications, onClearAll, onClearNotification }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const isPortal = location.pathname.startsWith('/portal');
  const [installPrompt, setInstallPrompt] = useState<any>(null);

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setInstallPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    installPrompt.userChoice.then((choiceResult: any) => {
      if (choiceResult.outcome === 'accepted') {
        setInstallPrompt(null);
      }
    });
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);
    if (val.trim() && !['/', '/projects', '/tasks', '/alerts', '/expiring', '/export', '/calendar'].includes(location.pathname)) {
      navigate('/projects');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between shadow-sm min-h-[70px] print:hidden">
      <div className="flex items-center gap-4 flex-1">
        <button 
          onClick={toggleSidebar}
          className="p-2 bg-slate-50 text-[#000066] rounded-xl border border-slate-200 hover:bg-slate-100 transition-all shadow-sm"
          title={isSidebarOpen ? "Hide Sidebar" : "Show Sidebar"}
        >
          {isSidebarOpen ? <PanelLeftClose size={20} /> : <PanelLeftOpen size={20} />}
        </button>
        {location.pathname !== '/' && (
          <div className="hidden md:flex items-center gap-3 shrink-0 ml-2">
            <HardHat className="text-[#000066]" size={24} />
            <div className="h-6 w-px bg-slate-200" />
          </div>
        )}
        {location.pathname !== '/' && (
          <div className="relative flex-1 max-w-xl group">
            <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-[#000066]" size={16} />
            <input type="text" placeholder="Search..." value={searchQuery} onChange={handleSearchChange} className="w-full pl-10 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-[#000066]/10 transition-all" />
            {searchQuery && <button onClick={() => setSearchQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-rose-500"><X size={14} /></button>}
          </div>
        )}
      </div>
      <div className="flex items-center gap-4 ml-4 shrink-0">
        {installPrompt && (
          <button 
            onClick={handleInstall}
            className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-colors"
          >
            <Download size={14} />
            Install App
          </button>
        )}
        <NotificationCenter 
          notifications={notifications} 
          currentUser={currentUser}
          onClearAll={onClearAll} 
          onClearNotification={onClearNotification}
        />
        <div className="h-8 w-px bg-slate-200 mx-2 hidden md:block" />
        <div className="flex items-center gap-3">
          <div className="hidden sm:block text-right">
            <p className="text-xs font-black text-slate-800 leading-none">{currentUser.name}</p>
            <p className="text-[9px] font-bold text-slate-400 uppercase mt-0.5">{currentUser.role}</p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-[#000066] flex items-center justify-center text-white font-black text-xs shadow-lg">
            {(currentUser.name || '').split(' ').map(n => n[0]).join('')}
          </div>
        </div>
      </div>
    </header>
  );
};

const AppContent: React.FC = () => {
  const [session, setSession] = useState<Session | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [permits, setPermits] = useState<Permit[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [users, setUsers] = useState<User[]>(USERS.map(u => ({ ...u, is_active: true })));
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [dismissedAlerts, setDismissedAlerts] = useState<string[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [searchQuery, searchQuerySet] = useState('');
  const [projectToDelete, setProjectToDelete] = useState<Project | null>(null);
  const [supabaseError, setSupabaseError] = useState<string | null>(null);
  
  const [currentUser, setCurrentUser] = useState<User>(USERS[0]);

  const navigate = useNavigate();
  const location = useLocation();

  const setSearchQuery = (q: string) => searchQuerySet(q);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user) {
        const metadata = session.user.user_metadata;
        setCurrentUser({
          id: session.user.id,
          name: metadata.display_name || metadata.full_name || session.user.email?.split('@')[0] || 'User',
          role: metadata.user_role || metadata.role || 'Engineer',
          email: session.user.email || '',
        });
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session?.user) {
        const metadata = session.user.user_metadata;
        setCurrentUser({
          id: session.user.id,
          name: metadata.display_name || metadata.full_name || session.user.email?.split('@')[0] || 'User',
          role: metadata.user_role || metadata.role || 'Engineer',
          email: session.user.email || '',
        });
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) {
      console.log('App: No session found, skipping data load');
      return;
    }
    
    const loadData = async () => {
      console.log('App: Starting data load from Supabase...');
      try {
        const [p, per, t, n, notifs, u, logs, da] = await Promise.all([
          supabaseService.getProjects(),
          supabaseService.getPermits(),
          supabaseService.getTasks(),
          supabaseService.getNotes(),
          supabaseService.getNotifications(),
          supabaseService.getUsers(),
          supabaseService.getAuditLogs(),
          supabaseService.getDismissedAlerts()
        ]);

        console.log(`App: Data loaded. Projects: ${p.length}, Permits: ${per.length}, Tasks: ${t.length}`);
        
        // If Supabase returns empty projects, try to load from local storage as a fallback
        // This handles the case where the user might be offline or the DB is fresh but they have local data
        if (p.length === 0) {
          console.log('App: Supabase returned empty projects, checking local storage...');
          const saved = localStorage.getItem(STORAGE_KEY);
          if (saved) {
            const data = JSON.parse(saved);
            if (data.projects && data.projects.length > 0) {
              console.log('App: Found local data, using it as primary source.');
              
              const localProjects = data.projects || [];
              const projectsWithCoords = localProjects.map((project: Project, index: number) => {
                if (project.latitude && project.longitude) return project;
                const sampleCoords = [
                  { lat: 26.6406, lng: -81.8723 },
                  { lat: 26.5629, lng: -81.9495 },
                  { lat: 26.6042, lng: -81.8374 },
                  { lat: 26.7056, lng: -81.7681 },
                  { lat: 26.5012, lng: -81.8012 }
                ];
                const coords = sampleCoords[index % sampleCoords.length];
                return { ...project, latitude: coords.lat, longitude: coords.lng };
              });
              
              setProjects(projectsWithCoords);
              setPermits(data.permits || []);
              setTasks(data.tasks || []);
              setNotes(data.notes || []);
              setNotifications(data.notifications || []);
              setDismissedAlerts(data.dismissedAlerts || []);
              
              // Also set Supabase error to indicate we are in offline/local mode
              setSupabaseError('Using local data (Cloud sync pending)');
              return; // Exit early since we loaded from local
            }
          }
        }

        const sortedData = (p.map((project: Project, index: number) => {
          if (project.latitude && project.longitude) return project;
          // Add some sample coordinates around Fort Myers area if missing
          const sampleCoords = [
            { lat: 26.6406, lng: -81.8723 },
            { lat: 26.5629, lng: -81.9495 },
            { lat: 26.6042, lng: -81.8374 },
            { lat: 26.7056, lng: -81.7681 },
            { lat: 26.5012, lng: -81.8012 }
          ];
          const coords = sampleCoords[index % sampleCoords.length];
          return { ...project, latitude: coords.lat, longitude: coords.lng };
        }) as Project[]).sort((a, b) => {
          const dateA = new Date(a.created_at || 0).getTime();
          const dateB = new Date(b.created_at || 0).getTime();
          return dateB - dateA;
        });

        setProjects(sortedData);
        setPermits(per);
        setTasks(t);
        setNotes(n);
        setNotifications(notifs);
        if (u && u.length > 0) setUsers(u);
        setAuditLogs(logs);
        setDismissedAlerts(da);
        setSupabaseError(null);
      } catch (error: any) {
        console.error('Error loading data from Supabase:', error);
        setSupabaseError(error.message || 'Failed to connect to Supabase');
        
        // Fallback to local storage if Supabase fails
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          const data = JSON.parse(saved);
          const p = data.projects || [];
          const projectsWithCoords = p.map((project: Project, index: number) => {
            if (project.latitude && project.longitude) return project;
            const sampleCoords = [
              { lat: 26.6406, lng: -81.8723 },
              { lat: 26.5629, lng: -81.9495 },
              { lat: 26.6042, lng: -81.8374 },
              { lat: 26.7056, lng: -81.7681 },
              { lat: 26.5012, lng: -81.8012 }
            ];
            const coords = sampleCoords[index % sampleCoords.length];
            return { ...project, latitude: coords.lat, longitude: coords.lng };
          });
          setProjects(projectsWithCoords);
          setPermits(data.permits || []);
          setTasks(data.tasks || []);
          setNotes(data.notes || []);
          setDismissedAlerts(data.dismissedAlerts || []);
          setNotifications(data.notifications || []);
        }
      }
    };

    loadData();
  }, [session]);

  const saveData = (p: Project[], per: Permit[], t: Task[], n: Note[], d: string[], notifs: AppNotification[]) => {
    // We still keep local storage as a backup/cache
    const data = { 
      projects: p, 
      permits: per, 
      tasks: t, 
      notes: n, 
      dismissedAlerts: d,
      notifications: notifs
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  };

  const handleUpdateProjects = async (newProjects: Project[]) => { 
    const oldProjects = [...projects];
    
    // Enrich projects with user info if they are new or modified
    const enrichedProjects = newProjects.map(p => {
      const oldP = oldProjects.find(op => op.id === p.id);
      if (!oldP) {
        logChange(p.id, 'project', p.name, 'create');
        return { 
          ...p, 
          created_by: currentUser.name, 
          created_at: new Date().toISOString().split('T')[0],
          last_updated_by: currentUser.name,
          last_updated_date: new Date().toISOString().split('T')[0]
        };
      }
      if (JSON.stringify(oldP) !== JSON.stringify(p)) {
        // Log specific field changes
        Object.keys(p).forEach(key => {
          const k = key as keyof Project;
          if (oldP[k] !== p[k] && !['last_updated_by', 'last_updated_date'].includes(k)) {
            logChange(p.id, 'project', p.name, 'update', k, String(oldP[k]), String(p[k]));
          }
        });
        return { 
          ...p, 
          last_updated_by: currentUser.name, 
          last_updated_date: new Date().toISOString().split('T')[0] 
        };
      }
      return p;
    });

    setProjects(enrichedProjects); 
    saveData(enrichedProjects, permits, tasks, notes, dismissedAlerts, notifications); 
    
    // 1. Handle Deletions
    if (newProjects.length < oldProjects.length) {
      const deletedProjects = oldProjects.filter(op => !newProjects.find(np => np.id === op.id));
      for (const dp of deletedProjects) {
        logChange(dp.id, 'project', dp.name, 'delete');
        await supabaseService.deleteProject(dp.id).catch(err => console.error('Failed to delete project from Supabase', err));
      }
    }

    // 2. Handle Creations and Updates
    for (const p of enrichedProjects) {
      const oldP = oldProjects.find(op => op.id === p.id);
      if (!oldP || JSON.stringify(oldP) !== JSON.stringify(p)) {
        await supabaseService.saveProject(p);
      }
    }
  };

  const handleUpdatePermits = async (newPermits: Permit[]) => { 
    const oldPermits = [...permits];
    setPermits(newPermits); 
    saveData(projects, newPermits, tasks, notes, dismissedAlerts, notifications); 
    
    // 1. Handle Deletions
    if (newPermits.length < oldPermits.length) {
      const deletedPermits = oldPermits.filter(op => !newPermits.find(np => np.id === op.id));
      for (const dp of deletedPermits) {
        logChange(dp.id, 'permit', dp.type, 'delete');
        await supabaseService.deletePermit(dp.id).catch(err => console.error('Failed to delete permit from Supabase', err));
      }
    }

    // 2. Handle Creations and Updates
    for (const p of newPermits) {
      const oldP = oldPermits.find(op => op.id === p.id);
      const hasChanged = !oldP || JSON.stringify(oldP) !== JSON.stringify(p);

      if (hasChanged) {
        if (!oldP) {
          logChange(p.id, 'permit', p.type, 'create');
        } else {
          Object.keys(p).forEach(key => {
            const k = key as keyof Permit;
            if (oldP[k] !== p[k]) {
              logChange(p.id, 'permit', p.type, 'update', k, String(oldP[k]), String(p[k]));
            }
          });
        }

        // Ensure project_id is the actual UUID, not the project number
        let actualProjectId = p.project_id;
        const matchedProject = projects.find(proj => proj.id === p.project_id || proj.number === p.project_id);
        if (matchedProject) {
          actualProjectId = matchedProject.id;
        }
        
        console.log(`App: Saving permit ${p.id} for project ${actualProjectId}`);
        await supabaseService.savePermit({ ...p, project_id: actualProjectId }).catch(err => {
          console.error(`Failed to save permit ${p.id} to Supabase`, err);
        });
      }
    }
  };
  
  const handleUpdateTasks = async (newTasks: Task[]) => { 
    console.log('App: handleUpdateTasks called with', newTasks.length, 'tasks');
    const oldTasks = [...tasks];
    setTasks(newTasks);
    
    // 1. Handle Deletions
    if (newTasks.length < oldTasks.length) {
      const deletedTasks = oldTasks.filter(ot => !newTasks.find(nt => nt.id === ot.id));
      console.log('App: Detected', deletedTasks.length, 'task deletions');
      for (const dt of deletedTasks) {
        logChange(dt.id, 'task', dt.name, 'delete');
        await supabaseService.deleteTask(dt.id).catch(err => console.error('Failed to delete task from Supabase', err));
      }
    }

    // 2. Handle Creations and Updates
    let updatedNotifs = [...notifications];
    let newNotifsToSave: AppNotification[] = [];

    for (const newTask of newTasks) {
      const oldTask = oldTasks.find(ot => ot.id === newTask.id);
      const hasChanged = !oldTask || JSON.stringify(oldTask) !== JSON.stringify(newTask);

      if (hasChanged) {
        console.log('App: Task changed or new:', newTask.name, newTask.id);
        let taskToSave = { ...newTask };

        if (!oldTask) {
          // New Task Logic
          taskToSave.assigned_by = currentUser.name;
          logChange(newTask.id, 'task', newTask.name, 'create');

          // Create notification for assignee
          const newNotif: AppNotification = {
            id: crypto.randomUUID(),
            title: 'New Task Assigned',
            message: `${newTask.name} has been assigned to you by ${currentUser.name}.`,
            timestamp: new Date().toISOString(),
            read: false,
            type: 'task',
            recipient: newTask.assigned_to,
            link: newTask.project_id === '00000000-0000-0000-0000-000000000000' ? '/tasks' : `/project/${newTask.project_id}?tab=tasks`
          };
          newNotifsToSave.push(newNotif);
        } else {
          // Update Task Logic
          Object.keys(newTask).forEach(key => {
            const k = key as keyof Task;
            if (JSON.stringify(oldTask[k]) !== JSON.stringify(newTask[k])) {
              logChange(newTask.id, 'task', newTask.name, 'update', k, String(oldTask[k]), String(newTask[k]));
            }
          });

          // Check for new comments
          if ((newTask.comments?.length || 0) > (oldTask.comments?.length || 0)) {
            const newComment = newTask.comments![newTask.comments!.length - 1];
            
            // 1. Check for @mentions in the comment text
            const mentionRegex = /@(\w+)/g;
            const mentions = new Set<string>();
            let match;
            while ((match = mentionRegex.exec(newComment.text)) !== null) {
              mentions.add(match[1].toLowerCase());
            }

            // Find users that match the mentions
            const mentionedUsers = users.filter(u => {
              if (!u.name) return false;
              const firstName = u.name.split(' ')[0].toLowerCase();
              const fullNameNoSpace = u.name.replace(/\s+/g, '').toLowerCase();
              return mentions.has(firstName) || mentions.has(fullNameNoSpace);
            });

            mentionedUsers.forEach(user => {
              const mentionNotif: AppNotification = {
                id: crypto.randomUUID(),
                title: 'You were mentioned',
                message: `${newComment.author} mentioned you in "${newTask.name}"`,
                timestamp: new Date().toISOString(),
                read: false,
                type: 'task',
                recipient: user.name,
                link: newTask.project_id === '00000000-0000-0000-0000-000000000000' ? '/tasks' : `/project/${newTask.project_id}?tab=tasks`
              };
              newNotifsToSave.push(mentionNotif);
            });

            // 2. Send notification to assignee
            if (newTask.assigned_to && newTask.assigned_to !== newComment.author) {
              const isAssigneeMentioned = mentionedUsers.some(u => u.name === newTask.assigned_to);
              if (!isAssigneeMentioned) {
                const newNotif: AppNotification = {
                  id: crypto.randomUUID(),
                  title: 'New Task Comment',
                  message: `${newComment.author} commented on "${newTask.name}"`,
                  timestamp: new Date().toISOString(),
                  read: false,
                  type: 'task',
                  recipient: newTask.assigned_to,
                  link: newTask.project_id === '00000000-0000-0000-0000-000000000000' ? '/tasks' : `/project/${newTask.project_id}?tab=tasks`
                };
                newNotifsToSave.push(newNotif);
              }
            }
          }
        }

        // Ensure project_id is the actual UUID
        let actualProjectId = taskToSave.project_id;
        const matchedProject = projects.find(proj => proj.id === taskToSave.project_id || proj.number === taskToSave.project_id);
        if (matchedProject) {
          actualProjectId = matchedProject.id;
        }
        
        console.log(`App: Saving task ${taskToSave.id} for project ${actualProjectId}`);
        await supabaseService.saveTask({ ...taskToSave, project_id: actualProjectId }).then(() => {
          console.log('App: Task saved successfully', taskToSave.id);
        }).catch(err => {
          console.error(`Failed to save task ${taskToSave.id} to Supabase`, err);
        });
      }
    }

    if (newNotifsToSave.length > 0) {
      updatedNotifs = [...newNotifsToSave, ...updatedNotifs].slice(0, 100);
      setNotifications(updatedNotifs);
      newNotifsToSave.forEach(n => supabaseService.saveNotification(n).catch(err => console.error('Failed to save notif', err)));
    }
    
    saveData(projects, permits, newTasks, notes, dismissedAlerts, updatedNotifs); 
  };
  
  const handleUpdateNotes = async (newNotes: Note[]) => { 
    const oldNotes = [...notes];
    
    // Enrich notes with author info
    const enrichedNotes = newNotes.map(n => {
      const oldN = oldNotes.find(on => on.id === n.id);
      if (!oldN) {
        return { ...n, author: currentUser.name, date: new Date().toISOString().split('T')[0] };
      }
      return n;
    });

    setNotes(enrichedNotes); 
    saveData(projects, permits, tasks, enrichedNotes, dismissedAlerts, notifications); 
    
    // 1. Handle Deletions
    if (enrichedNotes.length < oldNotes.length) {
      const deletedNotes = oldNotes.filter(on => !enrichedNotes.find(nn => nn.id === on.id));
      for (const dn of deletedNotes) {
        await supabaseService.deleteNote(dn.id).catch(err => console.error('Failed to delete note', err));
      }
    }

    // 2. Handle Creations and Updates
    for (const n of enrichedNotes) {
      const oldN = oldNotes.find(on => on.id === n.id);
      if (!oldN || JSON.stringify(oldN) !== JSON.stringify(n)) {
        let actualProjectId = n.project_id;
        const matchedProject = projects.find(proj => proj.id === n.project_id || proj.number === n.project_id);
        if (matchedProject) {
          actualProjectId = matchedProject.id;
        }
        
        console.log(`App: Saving note ${n.id} for project ${actualProjectId}`);
        await supabaseService.saveNote({ ...n, project_id: actualProjectId }).catch(err => {
          console.error(`Failed to save note ${n.id} to Supabase`, err);
        });
      }
    }
  };

  const handleDismissAlert = async (alertKey: string) => { 
    if (!['Application Owner', 'Administrator Full Access'].includes(currentUser.role)) {
      alert('Access Denied: Only Owners and Full Administrators can dismiss global alerts.');
      return;
    }
    console.log('App: Dismissing alert', alertKey);
    const updated = [...dismissedAlerts, alertKey]; 
    setDismissedAlerts(updated); 
    saveData(projects, permits, tasks, notes, updated, notifications); 
    try {
      await supabaseService.saveDismissedAlert(alertKey);
      console.log('App: Alert dismissal synced to cloud');
    } catch (error) {
      console.error('App: Failed to sync alert dismissal to cloud', error);
    }
  };

  const handleClearNotifs = async () => {
    const updated = notifications.filter(n => n.recipient !== currentUser.name);
    setNotifications(updated);
    saveData(projects, permits, tasks, notes, dismissedAlerts, updated);
    await supabaseService.clearUserNotifications(currentUser.name);
  };

  const handleClearIndividualNotif = async (id: string) => {
    const updated = notifications.filter(n => n.id !== id);
    setNotifications(updated);
    saveData(projects, permits, tasks, notes, dismissedAlerts, updated);
    await supabaseService.deleteNotification(id);
  };

  const handleSaveUser = async (user: User) => {
    const updatedUsers = users.find(u => u.id === user.id) 
      ? users.map(u => u.id === user.id ? user : u)
      : [...users, user];
    setUsers(updatedUsers);
    await supabaseService.saveUser(user);
  };

  const logChange = async (
    entity_id: string, 
    entity_type: 'project' | 'permit' | 'task', 
    entity_name: string,
    action: 'create' | 'update' | 'delete',
    field_name?: string,
    old_value?: string,
    new_value?: string
  ) => {
    const log: AuditLog = {
      id: crypto.randomUUID(),
      entity_id,
      entity_type,
      entity_name,
      action,
      field_name,
      old_value: old_value?.toString(),
      new_value: new_value?.toString(),
      user_id: currentUser.id,
      user_name: currentUser.name,
      timestamp: new Date().toISOString()
    };
    setAuditLogs(prev => [log, ...prev]);
    await supabaseService.saveAuditLog(log);
  };

  const handleBulkImport = async (data: { projects?: Project[], permits?: Permit[], tasks?: Task[], notes?: Note[] }) => {
    const updatedProjects = data.projects ? [...projects, ...data.projects] : projects;
    const updatedPermits = data.permits ? [...permits, ...data.permits] : permits;
    const updatedTasks = data.tasks ? [...tasks, ...data.tasks] : tasks;
    const updatedNotes = data.notes ? [...notes, ...data.notes] : notes;
    
    setProjects(updatedProjects);
    setPermits(updatedPermits);
    setTasks(updatedTasks);
    setNotes(updatedNotes);
    saveData(updatedProjects, updatedPermits, updatedTasks, updatedNotes, dismissedAlerts, notifications);

    // Sync to Supabase in chunks to avoid payload limits
    try {
      const CHUNK_SIZE = 100;
      
      if (data.projects) {
        for (let i = 0; i < data.projects.length; i += CHUNK_SIZE) {
          const chunk = data.projects.slice(i, i + CHUNK_SIZE);
          await supabaseService.bulkSaveProjects(chunk);
        }
      }
      if (data.permits) {
        for (let i = 0; i < data.permits.length; i += CHUNK_SIZE) {
          const chunk = data.permits.slice(i, i + CHUNK_SIZE);
          await supabaseService.bulkSavePermits(chunk);
        }
      }
      if (data.tasks) {
        for (let i = 0; i < data.tasks.length; i += CHUNK_SIZE) {
          const chunk = data.tasks.slice(i, i + CHUNK_SIZE);
          await supabaseService.bulkSaveTasks(chunk);
        }
      }
      if (data.notes) {
        for (let i = 0; i < data.notes.length; i += CHUNK_SIZE) {
          const chunk = data.notes.slice(i, i + CHUNK_SIZE);
          await supabaseService.bulkSaveNotes(chunk);
        }
      }
    } catch (error: any) {
      console.error('Error syncing imported data to Supabase:', error);
      const msg = error.message || 'Failed to sync some imported records to the cloud.';
      setSupabaseError(msg);
      throw new Error(msg);
    }
  };

  const handleResetData = async () => {
    console.log('App: Resetting all data...');
    setSupabaseError(null);
    try {
      await Promise.all([
        supabaseService.clearAllProjects(),
        supabaseService.clearAllPermits(),
        supabaseService.clearAllTasks(),
        supabaseService.clearAllNotes()
      ]);
      
      setProjects([]);
      setPermits([]);
      setTasks([]);
      setNotes([]);
      setNotifications([]);
      
      localStorage.removeItem(STORAGE_KEY);
      console.log('App: Data reset complete');
    } catch (error: any) {
      console.error('Error resetting data:', error);
      setSupabaseError(error.message || 'Failed to reset data in Supabase');
      throw error;
    }
  };

  const handleDeleteTrigger = (projectId: string) => { const proj = projects.find(p => p.id === projectId); if (proj) setProjectToDelete(proj); };
  const confirmDeleteProject = async () => { 
    if (!projectToDelete) return; 
    const projectId = projectToDelete.id; 
    const newProjects = projects.filter(p => p.id !== projectId); 
    const newPermits = permits.filter(p => p.project_id !== projectId); 
    const newTasks = tasks.filter(t => t.project_id !== projectId); 
    const newNotes = notes.filter(n => n.project_id !== projectId); 
    
    setProjects(newProjects); 
    setPermits(newPermits); 
    setTasks(newTasks); 
    setNotes(newNotes); 
    saveData(newProjects, newPermits, newTasks, newNotes, dismissedAlerts, notifications); 
    
    setProjectToDelete(null); 
    if (window.location.hash.includes(`/project/${projectId}`)) { 
      navigate('/projects'); 
    }

    try {
      await supabaseService.deleteProject(projectId);
    } catch (error) {
      console.error('Error deleting project from Supabase:', error);
    }
  };

  const expiringCount = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return permits.filter(p => {
      const key = `${p.id}-expiration`;
      if (dismissedAlerts.includes(key)) return false;
      if (!p.expiration_date) return false;
      const exp = parseDateSafe(p.expiration_date);
      if (!exp) return false;
      const diffDays = Math.ceil((exp.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return diffDays <= 90;
    }).length;
  }, [permits, dismissedAlerts]);

  const canSeeAllTasks = ['Application Owner', 'Project Manager'].includes(currentUser.role);
  const activeTasksCount = useMemo(() => {
    const baseTasks = canSeeAllTasks ? tasks : tasks.filter(t => t.assigned_to === currentUser.name);
    return baseTasks.filter(t => t.status !== 'Completed').length;
  }, [tasks, currentUser.name, canSeeAllTasks]);

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  if (!session) {
    return (
      <Routes>
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="*" element={<Login />} />
      </Routes>
    );
  }

  const isFullAdmin = ['Application Owner', 'Administrator Full Access'].includes(currentUser.role);
  const isAdmin = isFullAdmin || currentUser.role === 'Administrator';
  const isPM = currentUser.role === 'Project Manager';
  const isCadEi = ['CAD', 'EI'].includes(currentUser.role);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <aside className={`${isSidebarOpen ? 'w-64 opacity-100 border-r border-blue-900/40' : 'w-0 opacity-0'} bg-[#000066] text-white transition-all duration-300 flex flex-col z-50 shadow-2xl shrink-0 overflow-hidden print:hidden`}>
        <div className="p-4 flex items-center gap-3 border-b border-blue-900/40 min-h-[70px]">
          <div className="shrink-0 bg-white rounded-lg p-0.5 flex items-center justify-center shadow-inner overflow-hidden">
            <QALogo size={32} />
          </div>
          <div className="flex flex-col items-start gap-0 overflow-hidden select-none">
            <span className="text-[10px] font-black uppercase text-blue-300 tracking-[0.2em] whitespace-nowrap leading-tight">CIVTRACK</span>
            <span className="text-xl font-black text-white uppercase italic leading-none">PRO</span>
          </div>
        </div>
        <nav className="flex-1 px-3 py-6 space-y-1 overflow-y-auto no-scrollbar">
          <SidebarLink to="/" icon={<LayoutDashboard size={18} />} label="Dashboard" isOpen={isSidebarOpen} />
          <SidebarLink to="/projects" icon={<FolderKanban size={18} />} label="Projects" isOpen={isSidebarOpen} />
          <SidebarLink to="/calendar" icon={<CalendarDays size={18} />} label="Calendar" isOpen={isSidebarOpen} />
          <SidebarLink to="/tasks" icon={<CheckSquare size={18} />} label="Tasks" isOpen={isSidebarOpen} badge={activeTasksCount > 0 ? activeTasksCount : undefined} />
          <SidebarLink to="/alerts" icon={<Bell size={18} />} label="Alerts" isOpen={isSidebarOpen} />
          <SidebarLink to="/expiring" icon={<CalendarClock size={18} />} label="Expiring" isOpen={isSidebarOpen} badge={expiringCount > 0 ? expiringCount : undefined} />
          <SidebarLink to="/users" icon={<Users size={18} />} label="Personnel" isOpen={isSidebarOpen} />
          <SidebarLink to="/reports" icon={<BarChart3 size={18} />} label="Reports" isOpen={isSidebarOpen} />
          <SidebarLink to="/projects/new" icon={<PlusCircle size={18} />} label="New Project" isOpen={isSidebarOpen} />
          <SidebarLink to="/export" icon={<Database size={18} />} label="Data Tools" isOpen={isSidebarOpen} />
        </nav>
        
        <div className="p-4 border-t border-blue-900/50 bg-[#000044] group/user">
          <div className="relative">
            <button 
              onClick={handleLogout}
              className="flex items-center gap-3 w-full text-left hover:bg-rose-900/20 p-2 rounded-xl transition-all group"
              title="Sign Out"
            >
              <div className="w-8 h-8 rounded-xl bg-blue-500 group-hover:bg-rose-500 flex items-center justify-center text-[10px] font-bold text-white shadow-lg shrink-0 transition-colors">
                {(currentUser.name || '').split(' ').map(n => n[0]).join('')}
              </div>
              <div className="overflow-hidden flex-1">
                <p className="text-xs font-bold text-white truncate">{currentUser.name}</p>
                <p className="text-[8px] font-black uppercase text-blue-300 group-hover:text-rose-300 opacity-70 tracking-widest transition-colors">Sign Out</p>
              </div>
              <LogOut size={14} className="text-blue-300 group-hover:text-rose-300 opacity-0 group-hover:opacity-100 transition-all" />
            </button>
          </div>
        </div>
      </aside>
      <main className="flex-1 overflow-y-auto relative bg-slate-50 transition-all duration-300 print:bg-white print:overflow-visible">
        <GlobalHeader 
          searchQuery={searchQuery} 
          setSearchQuery={setSearchQuery} 
          isSidebarOpen={isSidebarOpen}
          toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
          currentUser={currentUser}
          notifications={notifications}
          onClearAll={handleClearNotifs}
          onClearNotification={handleClearIndividualNotif}
        />
        {supabaseError && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-100 rounded-xl flex items-center gap-3 text-rose-600 animate-in fade-in slide-in-from-top-2">
            <AlertTriangle size={18} />
            <div className="flex-1">
              <p className="text-[10px] font-black uppercase tracking-widest">Supabase Sync Error</p>
              <p className="text-[11px] font-medium">{supabaseError}</p>
            </div>
            <button onClick={() => window.location.reload()} className="px-3 py-1 bg-rose-600 text-white rounded-lg text-[9px] font-black uppercase tracking-widest hover:bg-rose-700">Retry</button>
          </div>
        )}
        <div className="p-6 print:p-0">
          <Routes>
            <Route path="/" element={<Dashboard projects={projects} permits={permits} searchQuery={searchQuery} tasks={tasks} onDeleteProject={handleDeleteTrigger} currentUser={currentUser} dismissedAlerts={dismissedAlerts} onDismiss={handleDismissAlert} />} />
            <Route path="/projects" element={<ProjectsList projects={projects} permits={permits} users={users} searchQuery={searchQuery} onDeleteProject={handleDeleteTrigger} currentUser={currentUser} />} />
            <Route path="/calendar" element={<MyCalendar currentUser={currentUser} users={users} tasks={tasks} projects={projects} permits={permits} onUpdateTasks={handleUpdateTasks} />} />
            <Route path="/tasks" element={<TasksList tasks={tasks} projects={projects} users={users} onUpdateTasks={handleUpdateTasks} searchQuery={searchQuery} currentUser={currentUser} />} />
            <Route path="/alerts" element={<Alerts projects={projects} permits={permits} users={users} dismissedAlerts={dismissedAlerts} onDismiss={handleDismissAlert} searchQuery={searchQuery} currentUser={currentUser} />} />
            <Route path="/expiring" element={<ExpiringPermits projects={projects} permits={permits} users={users} searchQuery={searchQuery} dismissedAlerts={dismissedAlerts} onDismiss={handleDismissAlert} currentUser={currentUser} />} />
            <Route path="/users" element={<UserDirectory users={users} onSaveUser={handleSaveUser} currentUser={currentUser} />} />
            <Route path="/reports" element={<Reports projects={projects} permits={permits} users={users} />} />
            <Route path="/project/:id" element={<ProjectDetails projects={projects} permits={permits} tasks={tasks} notes={notes} users={users} auditLogs={auditLogs} onUpdatePermits={handleUpdatePermits} onUpdateTasks={handleUpdateTasks} onUpdateNotes={handleUpdateNotes} onUpdateProjects={handleUpdateProjects} onDeleteProject={handleDeleteTrigger} currentUser={currentUser} />} />
            <Route path="/projects/new" element={<ProjectForm users={users} currentUser={currentUser} onSave={(newProject) => handleUpdateProjects([...projects, newProject])} />} />
            <Route path="/project/:id/edit" element={<ProjectForm projects={projects} users={users} currentUser={currentUser} onSave={(updatedProject) => handleUpdateProjects(projects.map(p => p.id === updatedProject.id ? updatedProject : p))} />} />
            <Route path="/export" element={<ExportData projects={projects} permits={permits} tasks={tasks} notes={notes} users={users} onImport={handleBulkImport} onReset={handleResetData} />} />
          </Routes>
        </div>
      </main>
      {projectToDelete && <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm print:hidden"><div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-100"><div className="flex flex-col items-center text-center"><div className="w-12 h-12 bg-rose-50 rounded-full flex items-center justify-center mb-4 text-rose-500"><AlertTriangle size={24} /></div><h3 className="text-lg font-black text-slate-800 uppercase tracking-tight mb-1">Confirm Deletion</h3><p className="text-[11px] font-black text-[#000066] uppercase tracking-widest mb-6">This cannot be undone!</p><div className="w-full p-3 bg-slate-50 rounded-xl border border-slate-100 mb-6"><p className="text-xs font-bold text-slate-700 truncate">{projectToDelete.name}</p></div><div className="grid grid-cols-2 gap-3 w-full"><button onClick={() => setProjectToDelete(null)} className="py-2.5 rounded-xl border border-slate-200 text-slate-600 font-black uppercase text-[10px] tracking-widest hover:bg-slate-50">Cancel</button><button onClick={confirmDeleteProject} className="py-2.5 rounded-xl bg-rose-600 text-white font-black uppercase text-[10px] tracking-widest hover:bg-rose-700">Delete</button></div></div></div></div>}
    </div>
  );
};

import { parseDateSafe } from './src/utils/dateUtils';

const App: React.FC = () => (<HashRouter><AppContent /></HashRouter>);
const SidebarLink: React.FC<{ to: string, icon: React.ReactNode, label: string, isOpen: boolean, badge?: number }> = ({ to, icon, label, isOpen, badge }) => { 
  const location = useLocation(); 
  const isActive = location.pathname === to; 
  return (
    <Link to={to} className={`flex items-center gap-3 px-3 py-2 rounded-xl transition-all relative ${isActive ? 'bg-[#A68F5B] text-white shadow-lg font-bold' : 'text-blue-100 hover:text-white hover:bg-blue-800'}`}>
      <div className="flex-shrink-0">{icon}</div>
      {isOpen && <span className="text-xs font-extrabold uppercase tracking-tight flex-1 whitespace-nowrap">{label}</span>}
      {badge !== undefined && isOpen && <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-black tracking-tight ${isActive ? 'bg-white text-[#A68F5B]' : 'bg-rose-600 text-white'}`}>{badge}</span>}
    </Link>
  ); 
};
export default App;
