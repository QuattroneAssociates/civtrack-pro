
export enum ProjectStatus {
  ACTIVE = 'Active',
  ACTIVE_PRIORITY = 'Active Priority',
  CLOSED = 'Closed',
  CONSTRUCTION = 'Construction',
  ON_HOLD = 'On Hold',
  PROPOSAL = 'Proposal',
  CO_ISSUED = 'CO Issued'
}

export enum TitlePolicyStatus {
  PENDING = 'Pending',
  RECEIVED = 'Received',
  NOT_REQUIRED = 'Not Required',
  REVIEWING = 'Reviewing'
}

export interface User {
  id: string;
  name: string;
  role: string;
  email: string;
  is_active: boolean;
  created_at?: string;
}

export interface AuditLog {
  id: string;
  entity_id: string;
  entity_type: 'project' | 'permit' | 'task';
  entity_name: string;
  action: 'create' | 'update' | 'delete';
  field_name?: string;
  old_value?: string;
  new_value?: string;
  user_id: string;
  user_name: string;
  timestamp: string;
}

export interface Project {
  id: string;
  name: string;
  number: string;
  description: string;
  status: ProjectStatus;
  project_manager_id: string;
  project_manager_name?: string;
  address: string;
  map_link?: string;
  agency: string;
  strap_number: string;
  one_drive_folder: string;
  one_drive_notes: string;
  client_name: string;
  client_email: string;
  client_mobile: string;
  client_office: string;
  architect: string;
  biologist: string;
  landscaper: string;
  surveyor: string;
  traffic_engineer: string;
  title_policy_status: TitlePolicyStatus;
  ball_in_court?: string; 
  created_at: string;
  created_by?: string;
  last_updated_date?: string;
  last_updated_by?: string;
  latitude?: number;
  longitude?: number;
}

export interface Permit {
  id: string;
  project_id: string;
  type: string;
  number: string;
  description: string;
  target_date: string;
  submittal_date: string;
  comments_1_date: string;
  resubmittal_1_date: string;
  comments_2_date: string;
  resubmittal_2_date: string;
  approval_date: string;
  expiration_date: string;
  agency?: string;
  application_status?: string;
  submittal_type?: string;
  fee_status?: string;
  fee_amount?: string;
  external_dependency?: string;
  last_action_date?: string;
  submittal_notes?: string;
}

export interface TaskComment {
  id: string;
  author: string;
  text: string;
  timestamp: string;
}

export interface Task {
  id: string;
  project_id: string;
  project_name?: string;
  name: string;
  description: string;
  assigned_by: string;
  assigned_to: string;
  date_assigned: string;
  due_date: string;
  date_completed?: string;
  status: string;
  is_important: boolean;
  notes?: string;
  tags?: string[];
  comments?: TaskComment[];
}

export interface Note {
  id: string;
  project_id: string;
  type: string;
  body: string;
  date: string;
  author: string;
}

export interface CalendarEvent {
  id: string;
  user_id: string;
  title: string;
  description: string;
  date: string; // YYYY-MM-DD
  start_time?: string;
  end_time?: string;
  type: 'personal' | 'site-visit' | 'meeting' | 'task';
  project_id?: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'task' | 'permit' | 'system';
  link?: string;
  recipient?: string; // New field for filtering
}

export interface DashboardPrefs {
  show_metric_active_projects: boolean;
  show_metric_unpaid_fees: boolean;
  show_metric_critical_tasks: boolean;
  show_metric_radar_alerts: boolean;
  show_deadline_radar: boolean;
  show_recent_submissions: boolean;
}
