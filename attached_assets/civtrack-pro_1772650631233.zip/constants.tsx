
import { ProjectStatus, TitlePolicyStatus, User } from './types';

export const USERS: User[] = [
  { id: '1', name: 'Al Quattrone', role: 'Application Owner', email: 'al@quattrone.com', is_active: true },
  { id: '12', name: 'Angelica Hoffert', role: 'Project Manager', email: 'angelica@quattrone.com', is_active: true },
  { id: '11', name: 'Carson Tucker', role: 'Engineer', email: 'carson@quattrone.com', is_active: true },
  { id: '13', name: 'David Castillo', role: 'Project Manager', email: 'david@quattrone.com', is_active: true },
  { id: '9', name: 'Erick Diaz', role: 'Engineer', email: 'erick@quattrone.com', is_active: true },
  { id: '2', name: 'Frank Feeney', role: 'Project Manager', email: 'frank@quattrone.com', is_active: true },
  { id: '14', name: 'Gabriela Rodriguez', role: 'Project Manager', email: 'gabriela@quattrone.com', is_active: true },
  { id: '15', name: 'Gary Hoffman', role: 'Project Manager', email: 'gary@quattrone.com', is_active: true },
  { id: '16', name: 'Greg Stuart', role: 'Project Manager', email: 'greg@quattrone.com', is_active: true },
  { id: '6', name: 'Jacob Soud', role: 'Engineer', email: 'jacob@quattrone.com', is_active: true },
  { id: '17', name: 'Jamie Rivera', role: 'Project Manager', email: 'jamie@quattrone.com', is_active: true },
  { id: '18', name: 'Jason White', role: 'Project Manager', email: 'jason@quattrone.com', is_active: true },
  { id: '7', name: 'Jeff Falzone', role: 'Planner', email: 'jeff@quattrone.com', is_active: true },
  { id: '5', name: 'Jhonny Foronda', role: 'Project Manager', email: 'jhonny@quattrone.com', is_active: true },
  { id: '19', name: 'Jim Rost', role: 'Project Manager', email: 'jim@quattrone.com', is_active: true },
  { id: '20', name: 'Joe Mauceri', role: 'Project Manager', email: 'joe@quattrone.com', is_active: true },
  { id: '10', name: 'John Udart', role: 'Engineer', email: 'john@quattrone.com', is_active: true },
  { id: '3', name: 'Josh Eisenoff', role: 'Associate Engineer', email: 'josh@quattrone.com', is_active: true },
  { id: '21', name: 'Leona Martin', role: 'Project Manager', email: 'leona@quattrone.com', is_active: true },
  { id: '22', name: 'Lisa Quattrone', role: 'Project Manager', email: 'lisa@quattrone.com', is_active: true },
  { id: '23', name: 'Mark Aral', role: 'Project Manager', email: 'mark@quattrone.com', is_active: true },
  { id: '24', name: 'Megan Johnson', role: 'Project Manager', email: 'megan@quattrone.com', is_active: true },
  { id: '25', name: 'Michelle Salberg', role: 'Project Manager', email: 'michelle@quattrone.com', is_active: true },
  { id: '26', name: 'Paul Torocco', role: 'Project Manager', email: 'paul@quattrone.com', is_active: true },
  { id: '27', name: 'Praneeth Akaveeti', role: 'Project Manager', email: 'praneeth@quattrone.com', is_active: true },
  { id: '28', name: 'Rich Batewell', role: 'Project Manager', email: 'rich@quattrone.com', is_active: true },
  { id: '29', name: 'Rusty O\'Neill', role: 'Project Manager', email: 'rusty@quattrone.com', is_active: true },
  { id: '30', name: 'Scott Pehlke', role: 'Project Manager', email: 'scott@quattrone.com', is_active: true },
  { id: '31', name: 'Sergio Guzman', role: 'Project Manager', email: 'sergio@quattrone.com', is_active: true },
  { id: '8', name: 'Sharon Hrabak', role: 'Designer', email: 'sharon@quattrone.com', is_active: true },
  { id: '4', name: 'Shelly Stalnos', role: 'Office Manager', email: 'shelly@quattrone.com', is_active: true },
  { id: '32', name: 'Stephanie Bagiardi', role: 'Project Manager', email: 'stephanie@quattrone.com', is_active: true },
];

export const BIC_OPTIONS = [
  'Quattrone & Associates',
  'Client / Owner',
  'Lead Agency (City/County)',
  'Architect',
  'Surveyor',
  'Biologist',
  'Traffic Engineer',
  'Landscaper',
  'Water/Sewer District',
  'Environmental Consultant'
];

export const AGENCIES = [
  'City of Fort Myers',
  'Lee County',
  'Cape Coral',
  'SFWMD',
  'FDOT',
  'Bonita Springs',
  'Charlotte County',
  'City Bonita Springs',
  'City Labelle',
  'City of Naples',
  'City Punta Gorda',
  'Collier County',
  'Desoto County',
  'Fort Myers Beach',
  'Hendry County',
  'Hillsborough County',
  'Manatee County',
  'Polk County',
  'Sarasota County',
  'St Lucie County',
  'SWFWMD',
  'Village of Estero',
  'Winter Haven',
  'Other'
];

export const SUB_CONSULTANTS = [
  'TBD',
  'N/A'
];

export const APPLICATION_STATUSES = [
  'Active',
  'Fees Posted - Unpaid',
  'Waiting on Signatures',
  'Waiting on External...'
];

export const TASK_NAMES = [
  'Final Site Certification',
  'SFWMD Certification',
  'Plan Review',
  'Submittal Preparation',
  'Agency Correspondence',
  'Field Inspection',
  'Boundary Survey Review',
  'Topographic Survey Review',
  'Landscape Plan Check',
  'Traffic Impact Study Review',
  'Drainage Calculation Review',
  'Utility Coordination',
  'Client Strategy Meeting'
];

export const TASK_STATUS_OPTIONS = [
  'Assigned',
  'In Progress',
  'Awaiting Info',
  'Pending Agency',
  'Completed',
  'Blocked'
];

export const SUBMITTAL_TYPES = [
  'Initial Submittal',
  'Resubmittal',
  'Extension',
  'Extension Requested'
];

export const FEE_STATUSES = [
  'N/A',
  'Fees Posted',
  'Paid',
  'Waiting on City'
];

export const AGENCY_DEADLINE_CONFIG: Record<string, { initial: number, resubmittal: number, extension: number }> = {
  'Lee County': { initial: 30, resubmittal: 30, extension: 30 },
  'City of Fort Myers': { initial: 30, resubmittal: 30, extension: 30 },
  'Cape Coral': { initial: 30, resubmittal: 30, extension: 30 },
  'SFWMD': { initial: 30, resubmittal: 30, extension: 30 },
  'FDOT': { initial: 30, resubmittal: 30, extension: 30 },
  'Bonita Springs': { initial: 30, resubmittal: 30, extension: 30 },
  'Other': { initial: 30, resubmittal: 30, extension: 30 }
};

export const PERMIT_TYPES = [
  'Administrative Deviation',
  'Administrative Zoning Amendment',
  'Army Corps Permitting',
  'Bonus Density',
  'Building Permitting',
  'Code Violation Hearing',
  'Comp Plan Amendment',
  'DEP 404',
  'DEP Sewer',
  'DEP Sewer Clearance',
  'DEP Site Permit',
  'DEP Water',
  'DEP Water Clearance',
  'Development Agreement',
  'FDOT Access Permitting',
  'FDOT Certification',
  'FDOT Drainage Exemption Permitting',
  'FDOT Drainage Permit',
  'FDOT General Permit',
  'FDOT Utility Permitting',
  'FPL Permitting',
  'Island Water Association',
  'LAAPZRB Meeting',
  'LAMSID Drainage Permit',
  'LCEC Permitting',
  'Limited Review Development Order',
  'Lot Combo',
  'Lot Split',
  'Map Boundry Determination',
  'Miscellaneous Permitting',
  'No Permit Required',
  'Notice of Intent (NOI)',
  'Platting Permitting',
  'Post Design Services',
  'Project Certification - Landscape',
  'Project Certification - Lighting',
  'Project Certification - Site',
  'Rezoning Conventional',
  'Rezoning Planned Development',
  'ROW Donation',
  'ROW Permit',
  'ROW Vacation',
  'Septic Permitting',
  'SFWMD 10/2',
  'SFWMD Certification',
  'SFWMD Dewatering Permitting',
  'SFWMD Drainage Permitting',
  'SFWMD Exemption',
  'SFWMD Major Modification',
  'SFWMD Minor Modification',
  'SFWMD Permit Transfer',
  'SFWMD Water Use Permitting',
  'SFWMD Water Use Transfer',
  'SFWMD Wetland JD',
  'Site Development Amendment',
  'Site Development Minor Change',
  'Site Development Permit',
  'Special Exception',
  'Stormwater Permit',
  'Submittal Waiver',
  'Surety Bonding',
  'Tall Structures Permitting - FAA',
  'Tall Structures Permitting - Port Authority',
  'Utility - Closeout',
  'Utility - Fee Quote',
  'Utility - New Project',
  'Utility Permitting',
  'Vacation Permitting',
  'Variance',
  'Veg Permit',
  'Zoning Verification Letter'
];

export const NOTE_TYPES = [
  'Client Meeting',
  'Internal Review',
  'Agency Correspondence',
  'Field Visit',
  'General Comment',
  'Imported',
  'General'
];
